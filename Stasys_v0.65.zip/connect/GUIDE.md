# Working with Stasys in this project

This project is tracked by **Stasys** - a local app that shows the project's work as a board of
cards and a timeline of sessions. The person you are working with looks at that board to see what
is planned, what is in play and what is finished, so keeping it true is part of the job.

Stasys wrote this file into `.tracker/claude/` and replaces it on every Stasys update. **Do not
edit it** - put project-specific rules in `CLAUDE.md` instead.

## Running a Stasys command

Two environment variables are set for this computer (in `.claude/settings.local.json`, under
`env`):

- `STASYS_PY` - the Python that runs Stasys
- `STASYS_HOME` - the folder Stasys is installed in

```
Git Bash:    "$STASYS_PY" "$STASYS_HOME/server.py" <door> ...
PowerShell:  & $env:STASYS_PY "$env:STASYS_HOME/server.py" <door> ...
```

If the variables are empty, read the two values out of `.claude/settings.local.json` and use them
literally. If that file has none either, this computer has not been connected yet: ask the person
to click **Connect Claude** on the Stasys board and paste what it gives them.

In everything below, `...` stands for that run prefix, and `<project>` is **this project's
folder name** - that is how Stasys knows the project, wherever on the drive it lives. Every door
works whether or not the Stasys app is open, prints JSON, and the board picks the change up
within a few seconds.

## Three rules

1. **Never edit `.tracker/state.json` by hand** - it is the board itself. The board saves the
   whole file, so a hand-edit is silently wiped by its next save, and yours wipes whatever the
   person just typed. Use the patch door (below). Leave `active.json`, `DEFERRED.md` and
   `claude/` alone too: Stasys writes them. The one file in `.tracker/` that IS edited by hand is
   `config.json` - the project's own settings (see "Lanes" below).
2. **Finished work gets a session record** (below). It is what the timeline is drawn from, and
   it is how the next session - which starts knowing nothing - finds out where things stand.
3. **Say which card you are working on.** Nothing detects it; you are the only one who knows.

## Starting a session

1. Read the **newest** file in `Documentation/SESSIONS/` (or the folder named by `sessionsDir` in
   `.tracker/config.json`). It ends with a handoff saying exactly where things stand.
2. `.tracker/DEFERRED.md` is the board as plain text. Its "Next up" line is the first card on the
   table - what an unspecified "let's continue" means. If that card is **parked**, read its resume
   note first: it says where the work was set down. (On a brand-new project the only record is
   a starter note with no handoff, and `DEFERRED.md` appears once the first card exists.)
3. Claim the card you pick up:

   ```
   ... --active <project> 14        claim card #14 (the board rings it in gold)
   ... --active <project>           show what is claimed
   ... --active <project> none      release, if you stop without finishing
   ```

   One card at a time; claiming one releases the last. The claim clears itself when the card is
   finished, parked or deleted, and never times out.

## Cards - the patch door

Write the change to a small JSON file in your scratch folder (not the project), then give its
full path:

```
... --patch <project> C:/path/to/ops.json
```

```json
{"ops": [
  {"op": "add", "item": {"title": "New card", "track": "F", "status": "table", "writeup": "Why, and what done looks like."}},
  {"op": "set", "id": 14, "fields": {"writeup": "new text"}},
  {"op": "move", "id": 14, "before": 5},
  {"op": "set", "id": 9, "fields": {"status": "cut"}}
]}
```

- **`add` takes `item`, never an `id`** - Stasys hands out the number and prints it back. `set`
  takes `id` + `fields`. A patch is all-or-nothing: if one op is wrong, nothing is written.
- `status` is `table` (planned, in priority order), `air` (an idea, not committed), `done` or
  `cut`. Prefer `cut` to `delete` - a cut card stays readable as history.
- `track` must be one of this project's lane codes (see "Lanes" below). A wrong `track` or
  `status` is **refused**, and the refusal lists the valid ones - read it, it always says which
  op was wrong and why.
- Order in the list is priority. `move` with `before` re-ranks; do not reorder the person's table
  unless they ask.
- Settable fields: `title`, `track`, `status`, `writeup`, `flag` (`true` / `false` - marks the
  card as a blocker that needs attention; say why in the write-up), `parked`, `resume`, `resumeRef`, `links`,
  and - only on a `done` card, when you close one by hand - `doneVersion` / `doneDate` (the
  version and date that shipped it). Dates like `created` and `lastTouched` are stamped by
  Stasys and cannot be set.
- **Parking.** To set a card down half-finished: `{"parked": true, "resume": "what is done, the
  very next step, what is uncertain", "resumeRef": "branch / last commit"}`. Write the note for
  someone who remembers nothing.
- **Links** connect cards: `"links": [{"to": 12, "type": "blocks"}]` - types are `blocks` (12
  cannot start until this is done), `derives-from` (this exists because of 12) and `part-of`
  (this is a slice of 12).
- When the person asks for something that is real work and has no card, add one. Refer to cards
  by number (`#14`) - numbers never change, titles get reworded.
- With the Stasys app open, `http://localhost:8787/api/help` describes the whole door.

## Lanes

Every card and every session sits in a lane. A project's lanes are the `tracks` list in
`.tracker/config.json`, in the order the board shows them. A bare letter is a built-in:
`F` Foundations, `E` Economy, `M` Movement, `P` Polish, `O` Optimisation, `C` Construction,
`U` UI / HUD. A new project starts with `F`, `O`, `P`, `U`. An entry can instead be an object
that gives the lane its own name, keeping the letter as its code:

```json
"tracks": [ { "code": "F", "name": "Engine" }, { "code": "U", "name": "Art & UI" }, "P" ]
```

A card's `track` is always the **code**. The built-in names suit a game; if they do not suit
this project, offer to rename the lanes - that is an edit to `config.json`, and the board picks
it up by itself.

## Session records

When a piece of work is finished - or the session ends with it unfinished - write one Markdown
file in the sessions folder:

```
Documentation/SESSIONS/YYYY-MM-DD_vX.Y_short-slug.md
```

The date and the `vX.Y` in the **file name** are what place it on the timeline; without them the
record has no date. Use the project's own version numbering and go up a step each record (if the
project has none yet, carry on from the newest record: `v0.1`, `v0.2`, ...).

```markdown
---
last_modified: 2026-01-31
last_verified: 2026-01-31
version: v0.7
completes: "#14, #15"
touches: "#9"
---

# v0.7 - one line saying what this was

## Why
## What changed
## Not done, and why

## HANDOFF PROMPT
Exactly where things stand and what to do next, for a session that knows nothing.
```

- `last_modified` and the file name are what matter; `version:` is optional but harmless.
- **`completes:`** lists the cards this record **finished**, by number. The board moves them to
  Done by itself - the next time it is open on this project - and releases the gold ring. You do
  not also patch their status.
- **`touches:`** lists cards the record worked on **without** finishing. It links the record to
  the card and changes nothing else.
- A number that matches no card closes nothing and shows as a red strip on the board, so check
  the numbers.
- Never rewrite an old record to change history; write a new one.

## Finishing a session

1. Write the session record, with `completes:` / `touches:`.
2. A card left half-done: **park it with a resume note**, or release the claim.
3. Tell the person, in plain words, what changed and what they should look at on the board.

## The two commands

- **`/stasys-audit`** reads the project's main documents against the newest session record and
  lists what has gone stale or contradicts itself. It changes no documents.
- **`/stasys-fix`** does the same, fixes the safe findings, and asks before touching anything
  that is a judgment call.

Both show their results in the board's Documents panel. Run them when the person asks, not on
your own initiative.

## If the board says no Claude session has reported in

The Connect Claude panel's last step should read *"a Claude session has reported in"* once a
session has started in this project after setup. If it still says none has:

1. The session hooks only load when a session **starts** - has the person started a new one?
2. Look at the three hooks in `.claude/settings.local.json`. They are written with `args` (the
   program and its argument apart, no shell). If your Claude Code's settings reference does not
   list `args` for a command hook, rewrite each as one shell command - the Python path in quotes,
   a space, then the `stasys_session.py` path in quotes - and ask the person to start a new
   session.
3. Run that same command yourself once, from the project folder. It should print nothing and
   exit 0; the panel's last step changes within a few seconds if the script itself is fine.
