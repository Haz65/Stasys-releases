#!/usr/bin/env python3
"""
audit_tool.py - deterministic mechanics for the Stasys "deep audit" loop.

Part of the Project Tracker (Stasys) engine. It is invoked OUT-OF-BAND by the
`/stasys-audit` Claude Code slash command - never by the board or by the served
runtime. Because it only ever runs where Claude Code runs (which has Python),
it deliberately has NO Node twin, unlike server.py / server.js: the twin rule is
about the *served* runtime, and this never serves anything.

It does the fiddly, error-prone parts of the loop so the model never hand-rolls
JSON or re-numbers findings:

  context [--start DIR]
      Walk up from DIR (default: cwd) to the tracked-project ROOT - the nearest
      ancestor that contains a `.tracker/` folder - and print a JSON bundle the
      auditor needs to think:
        { root, project, sessionsDir, configDocs[], sessions[], latest, priorAudit }
      configDocs[] is resolved with the SAME rules as the server's core_docs()
      (plain strings, {path,name}, or {glob,name} -> latest match).

  write [--start DIR] [--in FILE]
      Read the auditor's CURRENT findings (JSON, from FILE or stdin) and MERGE
      them with the prior `.tracker/audit.json`, then write it back in the
      board's schema. Merge rules (the whole point of "closing the loop"):
        * a current finding that carries a prior `id`        -> updates it, open
        * a current finding with no / unknown id             -> NEW finding, next id
        * a current finding with explicit "status":"resolved" -> kept, resolved
        * a prior finding NOT re-reported this pass          -> kept, flipped resolved
        * a prior finding already resolved & not re-reported -> stays resolved
      Ids are therefore stable across runs (continuity). Prints a one-line
      merge summary (total / open / resolved, new, newly resolved).

  root [--start DIR]
      Just print the resolved project root (handy for debugging / scripts).

Input shape for `write` (only `message` is really required per finding):
  a bare list of findings, OR {"findings":[...], "summary","by","method","scope"}
  finding: { "id"?, "severity", "doc", "refs"?, "message", "suggestion"?, "status"? }
    severity is normalised to the board's vocab: contradiction|staleness|drift|note
"""

import sys
import os
import re
import json
import datetime
import argparse
import glob as _glob

# Windows consoles default to cp1252, which can't encode characters like the "→"
# that legitimately appear in doc names / content (e.g. "Project → Tracker contract").
# Without this, printing the context bundle or the merge summary crashes with
# UnicodeEncodeError. Force UTF-8 on our streams so the tool is console-agnostic.
for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(encoding="utf-8")
    except Exception:
        pass

SEVERITIES = ("contradiction", "staleness", "drift", "note")
EXCLUDE = {"backup", "node_modules", ".git", "__pycache__"}
DEFAULT_SESSIONS_DIR = "Documentation/SESSIONS"
DEFAULT_METHOD = (
    "Out-of-band Claude pass via /stasys-audit (never baked into the board's "
    "refresh). Reads the project's core docs + latest session record (plus any "
    "extra scope), checks them against each other for contradictions / staleness "
    "/ version drift / notes, and merge-writes findings here. The board only "
    "displays this file; re-run /stasys-audit to refresh it."
)


# ---------- locating the tracked project ----------
def find_root(start):
    """Nearest ancestor of `start` that contains a .tracker/ folder."""
    d = os.path.abspath(start or ".")
    if os.path.isfile(d):
        d = os.path.dirname(d)
    while True:
        if os.path.isdir(os.path.join(d, ".tracker")):
            return d
        parent = os.path.dirname(d)
        if parent == d:
            return None
        d = parent


def load_json(path):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None


def load_cfg(root):
    cfg = load_json(os.path.join(root, ".tracker", "config.json"))
    return cfg if isinstance(cfg, dict) else {}


# ---------- core-doc resolution (mirrors server.core_docs) ----------
def _rel_ok(rel):
    rel = (rel or "").replace("\\", "/").strip().lstrip("/")
    if not rel or os.path.isabs(rel):
        return ""
    if ".." in rel.split("/"):
        return ""
    return rel


RE_DOC_VER = re.compile(r'v(\d+)[._](\d+)([a-z]?)', re.I)
def _doc_ver_key(rel):
    """Order glob matches by NUMERIC version, so PROJECT_BIBLEv10_08 sorts AFTER
       PROJECT_BIBLEv9_99 - which a plain string sort does not, because the text '9'
       compares greater than '1'.

       MIRROR OF server.py's _doc_ver_key (v0.60, Stasys #284 / SpaceLogistics #292).
       *** THE TWO MUST MOVE TOGETHER. *** v0.60 fixed the resolver in the server and
       left this tool sorting as text, so the server's Documents panel resolved v10_67
       while `audit_tool.py context` - the engine behind /stasys-audit and /stasys-fix -
       kept answering PROJECT_BIBLEv9_99 and LABELLING IT "Project Bible (latest)".
       Found 2026-08-16, by which point every audit run since the project passed v10.00
       on 2026-08-02 had been fed a 74-version-stale Bible. It went unnoticed because
       core_docs() below claims to use the "same rules as the server", and that claim
       was true when written; the parity broke underneath it and nothing checked.

       A name carrying no version keeps a plain sort and ranks BELOW any that does:
       an unversioned file can never be "the latest" while a versioned one exists."""
    ms = RE_DOC_VER.findall(os.path.basename(rel))
    if not ms:
        return (0, 0, 0, '', rel.lower())
    maj, minor, sfx = ms[-1]
    return (1, int(maj), int(minor), sfx.lower(), rel.lower())


def _resolve_latest_glob(root, pattern):
    pat = (pattern or "").replace("\\", "/").strip().lstrip("/")
    if not pat or os.path.isabs(pat) or ".." in pat.split("/"):
        return ""
    matches = []
    for p in _glob.glob(os.path.join(root, *pat.split("/")), recursive=True):
        if not os.path.isfile(p):
            continue
        rel = os.path.relpath(p, root).replace("\\", "/")
        if any(seg in EXCLUDE for seg in rel.split("/")):
            continue
        matches.append(rel)
    matches.sort(key=_doc_ver_key)
    return matches[-1] if matches else ""


def core_docs(root, cfg):
    """Ordered [{path,name,exists}] of canonical docs, same rules as the server."""
    out, seen = [], set()
    decl = cfg.get("docs") if isinstance(cfg, dict) else None
    if isinstance(decl, list) and decl:
        for entry in decl:
            rel = name = None
            if isinstance(entry, str):
                rel = entry
            elif isinstance(entry, dict):
                name = entry.get("name")
                rel = (_resolve_latest_glob(root, entry.get("glob"))
                       if entry.get("glob") else entry.get("path"))
            if not rel:
                continue
            rel = _rel_ok(rel)
            if not rel or rel.lower() in seen:
                continue
            seen.add(rel.lower())
            out.append({
                "path": rel,
                "name": name or os.path.basename(rel),
                "exists": os.path.isfile(os.path.join(root, rel.replace("/", os.sep))),
            })
        return out
    try:
        for name in sorted(os.listdir(root)):
            if name.lower().endswith(".md") and os.path.isfile(os.path.join(root, name)):
                out.append({"path": name, "name": name, "exists": True})
    except Exception:
        pass
    out.sort(key=lambda d: (0 if d["path"].lower().startswith("readme") else 1, d["path"].lower()))
    return out


RE_SESSION_SORT = re.compile(r'^(\d{4}-\d{2}-\d{2})_v(\d+)[._](\d+)([a-z]?)', re.I)
def _session_fname_key(fname):
    """Order session files by date, then by NUMERIC version.

       MIRROR OF server.py's _session_fname_key. *** THE TWO MUST MOVE TOGETHER. ***
       This is _doc_ver_key's story repeating one function below it: v0.60 sorted the
       server numerically and left THIS file sorting as text, so the Documents panel and
       `audit_tool.py context` disagreed about which file was newest. Same fault, same
       file, second place - measured 2026-08-17 (SpaceLogistics #316).

       NOT theoretical. On a single date a text sort ranks v9_99 ABOVE v10_00, and
       SpaceLogistics really has such a date: 2026-08-02 carries v9_97, v9_99 and v10_00,
       which the old bare sort() ordered v10_00, v9_97, v9_99 - backwards. It escaped
       notice only because that date is not the newest one, so sessions[-1] stayed right
       by luck while the LIST handed to every audit was wrong in the middle.

       Unparsed names sort LAST (leading 1), exactly as the server does - a file that does
       not match the naming convention surfaces as "latest" rather than hiding at the top.
       Deliberate parity, not an oversight: diverging from the server is the whole bug class
       this comment exists to stop."""
    m = RE_SESSION_SORT.match(fname)
    if not m:
        return (1, fname.lower(), 0, 0, '')
    return (0, m.group(1), int(m.group(2)), int(m.group(3)), (m.group(4) or '').lower())


def _session_mtime(path):
    """Tiebreak ONLY - see list_sessions. Unreadable mtime sorts oldest rather than raising."""
    try:
        return os.path.getmtime(path)
    except Exception:
        return 0.0


def list_sessions(root, cfg):
    """Session files oldest -> newest, so callers can take [-1] as "latest".

       Ordered by _session_fname_key, THEN by file mtime as a pure tiebreak.

       The tiebreak is load-bearing and was a deliberate developer decision (2026-08-17,
       SpaceLogistics #316), because the key above CANNOT settle a tie: two files written
       on the same date at the same version carry identical keys, and Python's sort is
       stable, so without this they would fall back to os.listdir order - arbitrary rather
       than merely wrong. The filename simply does not hold the information; only a
       timestamp does.

       It is not a rare case. Measured over SpaceLogistics' 249 session files: 27 groups
       share a date AND a version, and in 18 of them the alphabetically-last file is NOT
       the one written last. The misses are SYSTEMATIC - 11 of those 18 are audits,
       because an audit is usually the day's last file and "audit_" sorts before most
       slugs, so the tool skipped the audit as "latest" precisely when the audit was the
       freshest thing on disk.

       WHY mtime ONLY BREAKS TIES, rather than sorting everything: Documentation/ is not in
       git and its offsite backup is a mirror, so a restore can flatten every timestamp at
       once. Confined to a tiebreak, that degrades this back to the old arbitrary order
       within a single date+version group; promoted to the primary key, it would destroy
       the chronology entirely. Fail small."""
    sdir = (cfg.get("sessionsDir") or DEFAULT_SESSIONS_DIR).rstrip("/")
    full = os.path.join(root, sdir.replace("/", os.sep))
    names = []
    try:
        for name in os.listdir(full):
            if name.lower().endswith(".md") and os.path.isfile(os.path.join(full, name)):
                names.append(name)
    except Exception:
        pass
    names.sort(key=lambda n: (_session_fname_key(n), _session_mtime(os.path.join(full, n))))
    return [sdir + "/" + n for n in names]


def read_prior(root):
    obj = load_json(os.path.join(root, ".tracker", "audit.json"))
    return obj if isinstance(obj, dict) else None


# ---------- helpers ----------
def _norm_sev(s):
    s = str(s or "note").strip().lower()
    return s if s in SEVERITIES else "note"


def _to_int(v):
    try:
        return int(v)
    except Exception:
        return 0


def read_input(infile):
    if infile and infile != "-":
        with open(infile, "r", encoding="utf-8") as f:
            return f.read()
    return sys.stdin.read()


def die(msg):
    sys.stderr.write("audit_tool: %s\n" % msg)
    sys.exit(2)


def _resolve_root_or_die(start):
    root = find_root(start)
    if not root:
        die("no .tracker/ found walking up from %s" % os.path.abspath(start or "."))
    return root


# ---------- subcommands ----------
def cmd_root(args):
    print(_resolve_root_or_die(args.start))


def cmd_context(args):
    root = _resolve_root_or_die(args.start)
    cfg = load_cfg(root)
    sessions = list_sessions(root, cfg)
    bundle = {
        "root": root,
        "project": cfg.get("name") or os.path.basename(root),
        "sessionsDir": (cfg.get("sessionsDir") or DEFAULT_SESSIONS_DIR).rstrip("/"),
        "configDocs": core_docs(root, cfg),
        "sessions": sessions,
        "latest": sessions[-1] if sessions else "",
        "priorAudit": read_prior(root),
    }
    print(json.dumps(bundle, indent=2, ensure_ascii=False))


def cmd_write(args):
    root = _resolve_root_or_die(args.start)
    cfg = load_cfg(root)
    docs = core_docs(root, cfg)
    sessions = list_sessions(root, cfg)

    try:
        incoming = json.loads(read_input(args.infile))
    except Exception as e:
        die("could not parse findings JSON: %s" % e)

    if isinstance(incoming, list):
        findings_in, meta = incoming, {}
    elif isinstance(incoming, dict):
        findings_in, meta = (incoming.get("findings") or []), incoming
    else:
        die("findings JSON must be a list or an object with a 'findings' list")
    if not isinstance(findings_in, list):
        die("'findings' must be a list")

    prior = read_prior(root) or {}
    prior_findings = [f for f in (prior.get("findings") or []) if isinstance(f, dict)]
    prior_by_id, max_id = {}, 0
    for f in prior_findings:
        fid = _to_int(f.get("id"))
        if fid > 0:
            prior_by_id[fid] = f
            max_id = max(max_id, fid)

    result, seen, added = [], set(), 0
    for cf in findings_in:
        cf = cf or {}
        rid = _to_int(cf.get("id"))
        if rid in prior_by_id and rid not in seen:
            base = dict(prior_by_id[rid])
            seen.add(rid)
        else:
            max_id += 1
            rid = max_id
            base = {"id": rid}
            added += 1
        refs = cf.get("refs")
        explicit_resolved = str(cf.get("status") or "").strip().lower() == "resolved"
        base.update({
            "id": rid,
            "severity": _norm_sev(cf.get("severity") or base.get("severity")),
            "doc": str(cf.get("doc") if cf.get("doc") is not None else base.get("doc", "")),
            "refs": refs if isinstance(refs, list) else base.get("refs", []),
            "message": str(cf.get("message") if cf.get("message") is not None else base.get("message", "")),
            "suggestion": str(cf.get("suggestion") if cf.get("suggestion") is not None else base.get("suggestion", "")),
            "status": "resolved" if explicit_resolved else "open",
        })
        result.append(base)

    resolved_now = 0
    for f in prior_findings:
        if _to_int(f.get("id")) in seen:
            continue
        g = dict(f)
        if str(g.get("status") or "open").lower() != "resolved":
            g["status"] = "resolved"
            resolved_now += 1
        result.append(g)

    result.sort(key=lambda x: _to_int(x.get("id")))
    open_n = sum(1 for f in result if str(f.get("status") or "open").lower() != "resolved")
    resolved_total = len(result) - open_n

    latest_name = sessions[-1].split("/")[-1] if sessions else "no sessions"
    summary = meta.get("summary") or (
        "%d finding%s - %d open, %d resolved. Audited %d core doc%s against the latest session (%s)."
        % (len(result), "" if len(result) == 1 else "s", open_n, resolved_total,
           len(docs), "" if len(docs) == 1 else "s", latest_name)
    )
    scope = meta.get("scope")
    if not isinstance(scope, list) or not scope:
        scope = [d["path"] for d in docs]
        if sessions:
            scope.append(sessions[-1])

    out = {
        "version": _to_int(prior.get("version")) or 1,
        "generated": datetime.date.today().isoformat(),
        "by": str(meta.get("by") or "Claude - deep audit pass (/stasys-audit)"),
        "method": str(meta.get("method") or DEFAULT_METHOD),
        "scope": scope,
        "summary": summary,
        "findings": result,
    }

    td = os.path.join(root, ".tracker")
    os.makedirs(td, exist_ok=True)
    path = os.path.join(td, "audit.json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(out, f, indent=2, ensure_ascii=False)
        f.write("\n")
    print("wrote %s" % path)
    print("  %d finding(s): %d open, %d resolved  (%d new, %d newly resolved)"
          % (len(result), open_n, resolved_total, added, resolved_now))


def main():
    ap = argparse.ArgumentParser(prog="audit_tool", description="Stasys deep-audit loop mechanics.")
    sub = ap.add_subparsers(dest="cmd", required=True)
    for name in ("context", "write", "root"):
        sp = sub.add_parser(name)
        sp.add_argument("--start", default=".", help="dir to walk up from (default: cwd)")
        if name == "write":
            sp.add_argument("--in", dest="infile", default=None,
                            help="findings JSON file (default: read stdin)")
    args = ap.parse_args()
    {"context": cmd_context, "write": cmd_write, "root": cmd_root}[args.cmd](args)


if __name__ == "__main__":
    main()
