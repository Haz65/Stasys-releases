#!/usr/bin/env python3
# Project Tracker - local engine server (Python twin of server.js)
# Standard library only. Run with:  py server.py   (or python server.py)
# Serves the board at http://localhost:<port> and reads/writes each project's
# own  .tracker/  folder. The tool only ever writes inside .tracker/.

import os
import re
import io
import sys
import gzip
import json
import hmac
import shutil
import base64
import hashlib
import time
import socket
import zipfile
import secrets
import datetime
import threading
import webbrowser
from urllib.parse import urlparse, parse_qs
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

ENGINE_DIR = os.path.dirname(os.path.abspath(__file__))   # the app/engine folder

def _settings_path():
    """Per-user settings file: %APPDATA%\\Stasys\\settings.json on Windows.
    STASYS_SETTINGS names a different file outright (v0.65) - the suites use it, because the
    settings now hold a list of project folders the engine will read AND write, and a test
    must never see or touch the real one."""
    env = os.environ.get('STASYS_SETTINGS')
    if env and env.strip():
        return os.path.abspath(env.strip())
    base = (os.environ.get('APPDATA') or os.environ.get('XDG_CONFIG_HOME')
            or os.path.join(os.path.expanduser('~'), '.config'))
    return os.path.join(base, 'Stasys', 'settings.json')

def _read_settings():
    """The whole per-user settings dict (BOM-tolerant), {} on any problem."""
    try:
        with open(_settings_path(), 'r', encoding='utf-8-sig') as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}

def _write_settings(d):
    """Persist the settings dict (UTF-8, no BOM, preserving other keys). The engine
    writes here only for its OWN config (e.g. the host-mode access token) — never a
    tracked project."""
    try:
        os.makedirs(os.path.dirname(_settings_path()), exist_ok=True)
        with open(_settings_path(), 'w', encoding='utf-8') as f:
            json.dump(d, f, indent=4)
        return True
    except Exception:
        return False

def _saved_projects_root():
    r = _read_settings().get('projectsRoot')
    return r if isinstance(r, str) and r.strip() else None

# ---- host mode (live multi-board sync, backlog #16/#18) -------------------------
# OFF by default: the server binds 127.0.0.1 and needs no auth (the safe local app).
# When ON (opt-in), it binds the network so other devices (reached privately via
# Tailscale) can share this one board, behind a mandatory access token. The host
# machine itself (loopback) stays trusted/unauthenticated; only REMOTE requests need
# the token, and they can only read/write the backlog - never apply updates or
# scaffold projects (those are loopback-only). See the v0.31 session record.
def _host_mode_enabled():
    env = os.environ.get('STASYS_HOST')
    if env is not None:
        return env.strip().lower() not in ('', '0', 'false', 'no', 'off')
    return bool(_read_settings().get('hostMode'))

def _resolve_access_token():
    """The shared secret remote devices must present. Precedence: STASYS_HOST_TOKEN
    env -> settings.json 'accessToken' -> generate a strong one and persist it."""
    env = os.environ.get('STASYS_HOST_TOKEN')
    if env and env.strip():
        return env.strip()
    s = _read_settings()
    tok = s.get('accessToken')
    if isinstance(tok, str) and tok.strip():
        return tok.strip()
    tok = secrets.token_urlsafe(32)
    s['accessToken'] = tok
    _write_settings(s)
    return tok

def _own_ipv4s():
    """Best-effort set of this machine's own IPv4 addresses (incl. the Tailscale
    100.64.0.0/10 one and the LAN IP) — used to display the connect link and to
    allowlist the Host header against DNS-rebind."""
    ips = set()
    try:
        for ip in socket.gethostbyname_ex(socket.gethostname())[2]:
            ips.add(ip)
    except Exception:
        pass
    return ips

def _tailscale_ip(ips=None):
    """A 100.64.0.0/10 address among our own IPs (the Tailscale tailnet IP), or None."""
    for ip in (ips if ips is not None else _own_ipv4s()):
        o = ip.split('.')
        if len(o) == 4 and o[0] == '100' and o[1].isdigit() and 64 <= int(o[1]) <= 127:
            return ip
    return None

def host_info(port):
    """Connect details for the board's Share panel. Served loopback-only, so the
    token is never handed to a remote device."""
    return {
        'hostMode': HOST_MODE,
        'tailscaleIp': TAILSCALE_IP or '',
        'port': port,
        'token': ACCESS_TOKEN,
        'connectUrl': ('http://%s:%d/?token=%s' % (TAILSCALE_IP, port, ACCESS_TOKEN))
                      if (HOST_MODE and TAILSCALE_IP) else '',
        'hasTailscale': bool(TAILSCALE_IP),
    }

def get_projects_root():
    """Where to look for tracked projects (cartridges). Precedence:
    1) STASYS_PROJECTS_ROOT env var, 2) the saved per-user setting,
    3) fallback: the engine folder's parent (the original in-folder behaviour).
    This lets the app be installed anywhere yet still point at your projects."""
    env = os.environ.get('STASYS_PROJECTS_ROOT')
    if env and os.path.isdir(env):
        return os.path.abspath(env)
    saved = _saved_projects_root()
    if saved and os.path.isdir(saved):
        return os.path.abspath(saved)
    return os.path.dirname(ENGINE_DIR)

def _read_app_version():
    """The engine/build version this app reports — single source of truth in the
    root VERSION file (stamped by the release process). Read by /api/version and,
    later, the auto-updater (compares this against the latest published release)."""
    try:
        with open(os.path.join(ENGINE_DIR, 'VERSION'), 'r', encoding='utf-8-sig') as f:
            return f.read().strip()
    except Exception:
        return ''

ROOT = get_projects_root()                                # the projects parent
ENGINE_NAME = os.path.basename(ENGINE_DIR)
APP_NAME = 'Stasys'
APP_VERSION = _read_app_version()                         # e.g. 'v0.22' (root VERSION file)
DEFAULT_SESSIONS_DIR = os.path.join('Documentation', 'SESSIONS')
EXCLUDE = {'backup', 'node_modules', '.git'}  # engine folder NOT excluded: the tracker tracks itself
PORTS = [8787, 8788, 8789, 8790, 8791]

# Host-mode state, resolved once at startup (a UI toggle would need a restart; not this phase).
HOST_MODE = _host_mode_enabled()
ACCESS_TOKEN = _resolve_access_token() if HOST_MODE else ''
OWN_IPS = _own_ipv4s()
TAILSCALE_IP = _tailscale_ip(OWN_IPS)
# Host header allowlist (anti-DNS-rebind): our own addresses + the loopback names.
HOST_ALLOW = {'127.0.0.1', 'localhost', '::1'} | OWN_IPS

# ---- auto-updater: version compare + release-manifest check (board item #21) ----
# Phase 2: compare the installed VERSION against the latest published release.
# The release feed is a separate PUBLIC channel (repo/bucket) serving a small
# manifest:  { "latest": "v0.23", "url": "...zip", "notes": "...", "sig": "..." }.
# Verifying the signature ("sig") happens later, at download/apply time — this
# phase only *detects* that a newer version exists. No source is exposed here.

def _version_key(s):
    """Parse 'v0.10' / 'v1.2.3' / 'v0.5a' into a comparable (nums, letter) so that
    v0.10 sorts ABOVE v0.9 (numeric, not lexical). Returns None if no version found."""
    m = re.search(r'v?\s*([0-9]+(?:\.[0-9]+)*)\s*([a-z]?)', str(s or ''), re.I)
    if not m:
        return None
    return ([int(x) for x in m.group(1).split('.')], m.group(2).lower())

def _version_cmp(a, b):
    """-1 / 0 / 1 comparing two version strings; an unparseable version sorts lowest."""
    ka, kb = _version_key(a), _version_key(b)
    if ka is None and kb is None:
        return 0
    if ka is None:
        return -1
    if kb is None:
        return 1
    na, nb = ka[0], kb[0]
    n = max(len(na), len(nb))
    na = na + [0] * (n - len(na))
    nb = nb + [0] * (n - len(nb))
    if na != nb:
        return -1 if na < nb else 1
    if ka[1] != kb[1]:
        return -1 if ka[1] < kb[1] else 1
    return 0

# The public releases feed, baked in so a fresh install auto-checks for updates with
# ZERO config (the real end-user experience - no settings file to hand-edit). An env
# var or settings.json 'updateFeedUrl' still overrides it (for testing / a custom feed).
DEFAULT_UPDATE_FEED = 'https://raw.githubusercontent.com/Haz65/Stasys-releases/main/manifest.json'

def _update_feed_url():
    """Where the release manifest lives. Precedence: STASYS_UPDATE_FEED env ->
    settings.json 'updateFeedUrl' -> the baked-in DEFAULT_UPDATE_FEED. Config-only and
    never client-supplied, so it can't be abused as a request-forgery (SSRF) vector."""
    env = os.environ.get('STASYS_UPDATE_FEED')
    if env and env.strip():
        return env.strip()
    try:
        with open(_settings_path(), 'r', encoding='utf-8-sig') as f:
            r = json.load(f).get('updateFeedUrl')
        if isinstance(r, str) and r.strip():
            return r.strip()
    except Exception:
        pass
    return DEFAULT_UPDATE_FEED

def _fetch_manifest(feed):
    """Read+parse the release manifest JSON from an http(s)/file URL or a local path.
    Local paths make the check testable offline (point STASYS_UPDATE_FEED at a file)."""
    if re.match(r'^(https?|file)://', feed, re.I):
        import urllib.request
        with urllib.request.urlopen(feed, timeout=5) as r:        # nosec: URL is operator config, not user input
            raw = r.read().decode('utf-8-sig')
    else:
        with open(feed, 'r', encoding='utf-8-sig') as f:
            raw = f.read()
    return json.loads(raw)

def update_check():
    """Compare the installed VERSION against the latest published release.
    Returns a dict the board renders; never raises (errors are reported in-band)."""
    feed = _update_feed_url()
    out = {'current': APP_VERSION, 'configured': bool(feed),
           'latest': '', 'updateAvailable': False, 'url': '', 'notes': ''}
    if not feed:
        return out
    try:
        m = _fetch_manifest(feed)
    except Exception as e:
        out['error'] = str(e)
        return out
    latest = str(m.get('latest') or '').strip()
    out['latest'] = latest
    out['url'] = str(m.get('url') or '')
    out['notes'] = str(m.get('notes') or '')
    out['updateAvailable'] = bool(latest) and _version_cmp(latest, APP_VERSION) > 0
    return out

# ---- auto-updater: release signature verification (board item #21, Phase 3a) ----
# The shipped app holds a PUBLIC key and only ever VERIFIES; the maintainer SIGNS
# offline (OpenSSL) with the matching private key. This is what makes a downloaded
# package trustworthy — not repo privacy. Scheme: RSASSA-PKCS#1 v1.5 over SHA-256
# (RSA-2048). The signature is over the package's raw bytes and rides in the
# manifest's "sig" field (base64). Python's stdlib has no public-key verify, so we
# do RSA verification by hand (modular exponentiation + PKCS#1 padding check) — the
# Node twin uses its built-in crypto.verify, which is the same scheme.
#
# Trust anchor: the public key, baked in below. SHIPPED EMPTY = fail-closed (every
# verification rejected) until the maintainer generates the real keypair and pastes
# its PEM here (must match server.js's RELEASE_PUBLIC_KEY_PEM exactly).
RELEASE_PUBLIC_KEY_PEM = """-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAyxBUwqnwv4eOGKsXQYzs
9N5IW/wg4sE+7rOrMf4f4l3fQFgD6H2aeXtXhVsJcsQHzsTFwUxVXKSr4O5G3/QA
IMEEi+X/R6yFuuEt3sHYxuZp5gCgwJPJ14MG0cp2KHg5x68oMjkZapIhCVvYKs9V
rWni4wCdASnXZ+qo5ojxrKdOCBtQ+Htng7+EPtW2JSAFSY6DJZov26lMdJ+5VFxr
HY2mZVC0L0VJolJr+6VtyQf0n9qQCip6B6dPTz4KAhQ2OAHUuqQPA1Nrca7W1WwN
kMjMZr1KB5lY7twg2vP1n7YT+lRTHaOfk3lYiZ7xYDpfAYav6KoiLrlcgflR6DMI
jwIDAQAB
-----END PUBLIC KEY-----
"""

# DigestInfo prefix for SHA-256 (RFC 8017 / PKCS#1 v1.5, EMSA-PKCS1-v1_5).
_SHA256_DIGEST_INFO = bytes.fromhex('3031300d060960864801650304020105000420')

def _der_tlv(buf, i):
    """Read one ASN.1 DER tag-length-value at offset i. Returns (tag, value_bytes,
    next_index). Handles short- and long-form lengths. Raises on malformed input."""
    tag = buf[i]
    n = buf[i + 1]
    i += 2
    if n & 0x80:                          # long form: low 7 bits = number of length bytes
        k = n & 0x7f
        n = int.from_bytes(buf[i:i + k], 'big')
        i += k
    return tag, buf[i:i + n], i + n

def _rsa_pubkey_from_pem(pem):
    """Extract (n, e) from an RSA public key in SubjectPublicKeyInfo PEM (the default
    `openssl rsa -pubout` format). Returns None on any parse failure (fail-closed)."""
    try:
        b64 = ''.join(ln for ln in pem.splitlines() if ln and not ln.startswith('-----'))
        der = base64.b64decode(b64)
        _, spki, _ = _der_tlv(der, 0)             # outer SEQUENCE
        # spki = SEQUENCE{algo} BITSTRING{ subjectPublicKey }
        _, _algo, j = _der_tlv(spki, 0)           # skip AlgorithmIdentifier
        tag, bitstr, _ = _der_tlv(spki, j)        # BIT STRING
        if tag != 0x03:
            return None
        inner = bitstr[1:]                        # drop the "unused bits" count byte
        _, rsakey, _ = _der_tlv(inner, 0)         # SEQUENCE{ INTEGER n, INTEGER e }
        tn, nval, k = _der_tlv(rsakey, 0)
        te, eval_, _ = _der_tlv(rsakey, k)
        if tn != 0x02 or te != 0x02:
            return None
        n = int.from_bytes(nval, 'big')
        e = int.from_bytes(eval_, 'big')
        if n <= 0 or e <= 0:
            return None
        return n, e
    except Exception:
        return None

def _rsa_verify_pkcs1_sha256(data, sig, n, e):
    """Verify an RSASSA-PKCS#1 v1.5 / SHA-256 signature over `data` against key (n, e)."""
    k = (n.bit_length() + 7) // 8
    if len(sig) != k:
        return False
    s = int.from_bytes(sig, 'big')
    if s >= n:
        return False
    em = pow(s, e, n).to_bytes(k, 'big')
    t = _SHA256_DIGEST_INFO + hashlib.sha256(data).digest()
    ps_len = k - len(t) - 3
    if ps_len < 8:                                # PKCS#1 mandates >= 8 padding bytes
        return False
    expected = b'\x00\x01' + b'\xff' * ps_len + b'\x00' + t
    return hmac.compare_digest(em, expected)

def verify_release(data, sig_b64, key_pem=None):
    """True only if `data` (the package bytes) carries a valid signature `sig_b64`
    (base64) from the release key. `key_pem` overrides the baked-in trust anchor
    `RELEASE_PUBLIC_KEY_PEM` (used by tests to inject a throwaway key; production
    passes None). Fail-closed: empty/unparseable key, bad base64, or any error ->
    False. Never raises."""
    try:
        pem = key_pem if key_pem is not None else RELEASE_PUBLIC_KEY_PEM
        if not pem.strip():
            return False
        key = _rsa_pubkey_from_pem(pem)
        if not key:
            return False
        sig = base64.b64decode(sig_b64, validate=True)
        return _rsa_verify_pkcs1_sha256(data, sig, key[0], key[1])
    except Exception:
        return False

# ---- auto-updater: download -> verify -> apply (board item #21, Phase 3b) ----
# Fetch the package named in the manifest, VERIFY its signature (verify_release —
# fail-closed), then atomically swap the engine's own text files. Python-only by
# design: the shipped runtime is Python and the stdlib has zipfile, whereas Node has
# no built-in zip extraction (the security-critical verify lives in both twins). Runs
# as a separate CLI process (`py server.py --apply-update <manifest>`), NOT an HTTP
# route — a file-overwriting endpoint would be needless attack surface, and a separate
# process matches the future "spawn updater, then restart" flow. Writing into the
# engine's OWN install dir is the updater's purpose; the "only write inside .tracker/"
# rule guards tracked projects, which this never touches.
UPDATE_FILES = ('server.py', 'server.js', 'board.html', 'VERSION')  # what an update replaces
UPDATE_CORE = ('server.py', 'board.html', 'VERSION')                # a package missing any of these is rejected
# The app SHELL - the native window, its WebView2 dlls, the icons and launchers. All
# optional in a package (most releases are engine-only), and all of them may be LOCKED
# while Stasys is running, which is what _replace_or_stage exists for.
UPDATE_SHELL = ('StasysApp.exe', 'Microsoft.Web.WebView2.Core.dll',
                'Microsoft.Web.WebView2.WinForms.dll', 'WebView2Loader.dll',
                'Stasys.ico', 'Stasys_Icon.png', 'Stasys_App.vbs', 'stasys_app.ps1',
                'Stop_Stasys.bat', 'Stasys.bat', 'Set_Projects_Folder.bat',
                'set_projects_folder.ps1')
# The HELPERS (v0.64) - the files Claude Code needs beside the engine: the audit tool, the
# session hook, the two command bodies and the guide. Optional in a package for the same
# reason the shell is (a package built before v0.64 has none), plain files that are never
# locked, and the only members that live in SUBFOLDERS - so the applier makes the folder.
# An updater older than v0.64 does not know these names and skips them, which is exactly
# why ensure_helpers() exists: the engine that arrives by such an update fetches them itself.
HELPER_FILES = ('audit_tool.py', 'hooks/stasys_session.py', 'commands/stasys-audit.md',
                'commands/stasys-fix.md', 'connect/GUIDE.md')
UPDATE_BACKUP_DIR = '.update-backup'
STALE_SUFFIX = '.stasys-old'        # a running image renamed aside by an update

def _fetch_bytes(src):
    """Raw download of a package from an http(s)/file URL or a local path. Byte-level
    sibling of _fetch_manifest. Operator/manifest-supplied source, not client input."""
    if re.match(r'^(https?|file)://', src, re.I):
        import urllib.request
        with urllib.request.urlopen(src, timeout=30) as r:        # nosec: source is signed-package URL, verified after
            return r.read()
    with open(src, 'rb') as f:
        return f.read()

def _stale_path(dst):
    """A free <name>.stasys-old path to park a running image at. Normally there's only
    one; a numbered variant is used if an earlier one is still locked (Stasys was
    updated twice without ever being closed)."""
    stale = dst + STALE_SUFFIX
    if os.path.exists(stale):
        try:
            os.remove(stale)                   # a previous update's leftover, now free
        except OSError:
            n = 1
            while os.path.exists('%s.%d%s' % (dst, n, STALE_SUFFIX)):
                n += 1
            stale = '%s.%d%s' % (dst, n, STALE_SUFFIX)
    return stale


def _replace_or_stage(dst, data):
    """Write `data` to `dst`. Returns ('replaced'|'staged', stale_path_or_None).

    Plain files are swapped atomically (temp + os.replace). But the app shell can be
    IN USE: Windows refuses to overwrite or delete a running .exe or a loaded .dll -
    while still allowing it to be RENAMED. So on a lock we move the running image aside
    to <name>.stasys-old and drop the new file at the real path: the running Stasys
    keeps executing from the renamed image, the shortcut still points at the real path,
    and the new shell takes over the next time Stasys is opened. The leftover is deleted
    by sweep_stale_updates() on a later start, once nothing holds it."""
    tmp = dst + '.update-tmp'
    with open(tmp, 'wb') as f:
        f.write(data)
        f.flush()
        os.fsync(f.fileno())
    try:
        os.replace(tmp, dst)
        return 'replaced', None
    except OSError:
        pass                                   # in use - fall through to the rename path
    stale = _stale_path(dst)
    os.rename(dst, stale)                      # allowed even while running
    try:
        os.replace(tmp, dst)
    except Exception:
        os.rename(stale, dst)                  # put the running image back where it was
        raise
    return 'staged', stale


def sweep_stale_updates(target_dir=None):
    """Delete the <name>.stasys-old images a shell update left behind, once the process
    that held them has exited. Called at startup. Best-effort by design: anything still
    locked (Stasys reopened before the old window closed) is left for the next start."""
    target_dir = target_dir or ENGINE_DIR
    removed = []
    try:
        for fn in os.listdir(target_dir):
            if not fn.endswith(STALE_SUFFIX):
                continue
            try:
                os.remove(os.path.join(target_dir, fn))
                removed.append(fn)
            except OSError:
                pass                           # still in use - try again next time
    except Exception:
        pass
    return removed


def apply_update(manifest_src, target_dir=None, key_pem=None):
    """Download, verify, and apply the release named in the manifest. Returns a result
    dict and NEVER raises. Fail-closed: a bad/absent signature (against the baked-in
    release key) aborts without touching a single file. Atomic per-file with a full
    rollback if any write fails.

    manifest_src: manifest URL/path, or '' to use the configured update feed.
    target_dir:   install dir to update (defaults to this engine's own dir).
    key_pem:      override the trust anchor (tests inject a throwaway key)."""
    target_dir = target_dir or ENGINE_DIR
    try:
        feed = manifest_src or _update_feed_url()
        if not feed:
            return {'applied': False, 'reason': 'no manifest / update feed configured'}
        m = _fetch_manifest(feed)
        latest = str(m.get('latest') or '').strip()
        url = str(m.get('url') or '').strip()
        sig = str(m.get('sig') or '').strip()
        if not (latest and url and sig):
            return {'applied': False, 'reason': 'manifest missing latest/url/sig'}
        if _version_cmp(latest, APP_VERSION) <= 0:
            return {'applied': False, 'reason': 'not newer', 'current': APP_VERSION, 'latest': latest}

        pkg = _fetch_bytes(url)
        # THE trust gate — only a package signed by the baked-in release key proceeds.
        if not verify_release(pkg, sig, key_pem):
            return {'applied': False, 'reason': 'signature invalid'}

        # Read the allowlisted members out of the verified zip (never arbitrary extraction).
        try:
            zf = zipfile.ZipFile(io.BytesIO(pkg))
        except Exception:
            return {'applied': False, 'reason': 'package is not a valid zip'}
        names = set(zf.namelist())
        new_bytes = {}
        for fn in UPDATE_FILES + UPDATE_SHELL + HELPER_FILES:   # shell + helper members are
            if fn in names:                      # optional: a package may not carry them
                new_bytes[fn] = zf.read(fn)
        missing = [fn for fn in UPDATE_CORE if fn not in new_bytes]
        if missing:
            return {'applied': False, 'reason': 'package missing core files: ' + ', '.join(missing)}
        pkg_ver = new_bytes['VERSION'].decode('utf-8-sig').strip()
        if pkg_ver != latest:
            return {'applied': False, 'reason': "package VERSION %r != manifest latest %r" % (pkg_ver, latest)}

        # Atomic apply with backup + rollback.
        backup = os.path.join(target_dir, UPDATE_BACKUP_DIR)
        if os.path.isdir(backup):
            shutil.rmtree(backup, ignore_errors=True)
        os.makedirs(backup, exist_ok=True)
        written = []                                                  # (name, mode, stale_path)
        try:
            for fn, data in new_bytes.items():
                dst = os.path.join(target_dir, *fn.split('/'))
                bak = os.path.join(backup, *fn.split('/'))
                os.makedirs(os.path.dirname(dst), exist_ok=True)     # a helper lives in a subfolder
                os.makedirs(os.path.dirname(bak), exist_ok=True)
                if os.path.exists(dst):
                    shutil.copy2(dst, bak)                           # back up the current file
                                                                     # (reading a running exe is allowed)
                mode, stale = _replace_or_stage(dst, data)
                written.append((fn, mode, stale))
        except Exception as e:
            for fn, mode, stale in written:
                dst = os.path.join(target_dir, fn)
                try:
                    if mode == 'staged' and stale and os.path.exists(stale):
                        # the file now at dst is the NEW one and nothing is running it,
                        # so it can go; then the running image returns to its real path
                        if os.path.exists(dst):
                            os.remove(dst)
                        os.rename(stale, dst)
                    else:
                        b = os.path.join(backup, fn)
                        if os.path.exists(b):
                            shutil.copy2(b, dst)
                except Exception:
                    pass
            return {'applied': False, 'reason': 'write failed, rolled back: ' + str(e), 'rolledBack': True}

        staged = [fn for fn, mode, _ in written if mode == 'staged']
        return {'applied': True, 'from': APP_VERSION, 'to': latest,
                'files': [fn for fn, _, _ in written], 'staged': staged,
                # the engine reloads on the server restart; a staged shell only takes
                # over when Stasys itself is next opened - the board says so
                'appRestartRequired': bool(staged),
                'backup': backup, 'notes': str(m.get('notes') or '')}
    except Exception as e:
        return {'applied': False, 'reason': str(e)}


def helpers_missing(target_dir=None):
    """The HELPER_FILES that are not beside this engine. Empty on a healthy install."""
    target_dir = target_dir or ENGINE_DIR
    return [fn for fn in HELPER_FILES
            if not os.path.isfile(os.path.join(target_dir, *fn.split('/')))]


def ensure_helpers(target_dir=None, manifest_src=None, key_pem=None):
    """Fetch the helper files this engine is missing out of ITS OWN signed release package.

    Why this exists (v0.64): the updater that installs a new engine is the OLD engine, and an
    updater from before v0.64 has never heard of HELPER_FILES - it swaps the four engine files
    and skips the rest. So the first engine that knows about helpers arrives without them. It
    cannot ask to be updated again (it is already the newest), so it takes them from the same
    package it was just installed from: same feed, same signature gate, same allowlist.

    Deliberately narrow. It only ever runs when something is missing; it writes ONLY the
    missing files, never over one that is there (a dev copy's working files are never
    touched); and it refuses any package that is not this exact version - if the feed has
    moved on, the ordinary update will bring the helpers, because from v0.64 the applier
    carries them. Fail-closed and never raises. Python-only, like apply_update, and for the
    same reason (the shipped runtime is Python; Node has no built-in zip reader)."""
    target_dir = target_dir or ENGINE_DIR
    missing = helpers_missing(target_dir)
    if not missing:
        return {'ok': True, 'fetched': [], 'missing': []}
    try:
        feed = manifest_src or _update_feed_url()
        if not feed:
            return {'ok': False, 'missing': missing, 'reason': 'no update feed configured'}
        m = _fetch_manifest(feed)
        latest = str(m.get('latest') or '').strip()
        url = str(m.get('url') or '').strip()
        sig = str(m.get('sig') or '').strip()
        if not (latest and url and sig):
            return {'ok': False, 'missing': missing, 'reason': 'manifest missing latest/url/sig'}
        cmp_ = _version_cmp(latest, APP_VERSION)
        if cmp_ > 0:
            return {'ok': False, 'missing': missing, 'reason': 'update-first', 'latest': latest}
        if cmp_ < 0:
            return {'ok': False, 'missing': missing, 'reason': 'this build is newer than the published release'}
        pkg = _fetch_bytes(url)
        if not verify_release(pkg, sig, key_pem):
            return {'ok': False, 'missing': missing, 'reason': 'signature invalid'}
        try:
            zf = zipfile.ZipFile(io.BytesIO(pkg))
        except Exception:
            return {'ok': False, 'missing': missing, 'reason': 'package is not a valid zip'}
        names = set(zf.namelist())
        if 'VERSION' not in names or zf.read('VERSION').decode('utf-8-sig').strip() != APP_VERSION:
            return {'ok': False, 'missing': missing, 'reason': 'package is not this version'}
        fetched = []
        for fn in missing:
            if fn not in names:
                continue
            dst = os.path.join(target_dir, *fn.split('/'))
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            tmp = dst + '.update-tmp'
            with open(tmp, 'wb') as f:
                f.write(zf.read(fn))
            os.replace(tmp, dst)
            fetched.append(fn)
        still = helpers_missing(target_dir)
        out = {'ok': not still, 'fetched': fetched, 'missing': still}
        if still:
            out['reason'] = 'the release package does not carry: ' + ', '.join(still)
        return out
    except Exception as e:
        return {'ok': False, 'missing': helpers_missing(target_dir), 'reason': str(e)}

# ---- track palette (display order + colours); tracks are inferred, tune freely ----
TRACKS = {
    'F': {'name': 'Foundations & diagnostics', 'short': 'Foundations',  'color': '#8b8f9a'},
    'E': {'name': 'Economy & sim',             'short': 'Economy',      'color': '#2bb89a'},
    'M': {'name': 'Movement & physics',        'short': 'Movement',     'color': '#3f8ae0'},
    'P': {'name': 'Polish & FX',               'short': 'Polish',       'color': '#d56aa0'},
    'O': {'name': 'Optimisation & scale',      'short': 'Optimisation', 'color': '#8a7fe0'},
    'C': {'name': 'Construction',              'short': 'Construction', 'color': '#e0a23f'},
    'U': {'name': 'UI / HUD',                  'short': 'UI / HUD',     'color': '#e0673f'},
}
TRACK_ORDER = ['F', 'E', 'M', 'P', 'O', 'C', 'U']
# Per-card field ceilings applied on save. These are runaway guards (a bad paste, a
# client bug) - NOT design limits - so they sit far above real use. The write-up was
# capped at 5000 from the first commit with no rationale, and real cards reached it;
# v0.37 raised it to 100k (~16,000 words), and by v0.61 a real card had reached 95k
# (SpaceLogistics #197), so it doubled to 200k (~32,000 words). v0.62 raised it to 1M
# (~160,000 words) when #197 reached 178k a day later - past where any honest card goes,
# which is the whole point of a runaway guard. A cap this high only works because
# BODY_MAX (below) was raised with it: the board saves the WHOLE file in one request.
WRITEUP_MAX = 1000000
TITLE_MAX = 500
# The resume note is *meant* to be short - it is the "where does this stand" line a
# picked-up card is read for, not a second write-up (that's `writeup`, above). But 4000
# was a style rule wearing a runaway guard's clothes, and real notes reached it: v0.42
# found SpaceLogistics #206 sitting at exactly 4000 chars, cut mid-word, and #215 at
# 3947. Truncation is silent (no `maxlength` on the board's textarea, and `doSave`
# discards the response), so the note simply lost its tail. Matched to WRITEUP_MAX for
# the same reason v0.37 raised that one: keep a guard, put it far above honest use.
RESUME_MAX = 1000000
RESUME_REF_MAX = 200      # the free-text "branch / last commit" the note was written against
RESUME_AT_MAX = 40        # when the note was last edited (ISO), stamped by the board
# Largest request body a write endpoint accepts (bytes). The board's save is the WHOLE
# state.json in one PUT, so this is the real ceiling on a project's size - hit it and the
# save is refused outright, every card with it, which is far worse than one field being
# truncated. It sat at 5 MB (a bare literal in two places) while SpaceLogistics's file
# was already 2.3 MB; v0.62's 1M-char cards would have walked straight into it. 50 MB
# holds ten cards filled to the cap even in 3-byte UTF-8, with room to spare.
BODY_MAX = 50000000
# The free-text fields a person types, and the ceiling each is held to, in the order a
# refusal reports them. Since v0.62 the engine NEVER CUTS one of these: a save carrying a
# value over its ceiling is refused whole, naming the card, the field, its length and the
# limit. Cutting was silent - no counter on the board, and `doSave` never showed the reply -
# and it took the END of the text, which in a write-up is the newest part. That is how #206's
# note lost its tail at v0.42, and raising a ceiling only ever moved the loss later.
FIELD_LIMITS = (('title', TITLE_MAX), ('writeup', WRITEUP_MAX),
                ('resume', RESUME_MAX), ('resumeRef', RESUME_REF_MAX))


def _count(n):
    """1000001 -> '1,000,001'. The Node twin hand-rolls the same thing rather than use
    toLocaleString, whose output depends on the runtime's locale data."""
    return format(n, ',')


def field_overflow(item, prev=None):
    """The first limited field of `item` over its ceiling, as {field, length, limit}, or None.

    The pure core of the v0.62 refusal, machine-checked against the Node twin. Length is in
    CHARACTERS - Unicode code points, which is what len() counts here. Node's .length counts
    UTF-16 units (an emoji is two), so the twin counts code points explicitly; without that the
    same note could pass one engine and be refused by the other.

    `prev` is the card as it stands on disk. A value over its ceiling but IDENTICAL to the disk
    copy is let through: it can only exist if a ceiling was lowered after it was written, and
    refusing it would leave the whole board unable to save over text nobody is touching. It is
    not cut either - the engine keeps what it has."""
    if not isinstance(item, dict):
        return None
    for name, limit in FIELD_LIMITS:
        s = str(item.get(name) or '')
        n = len(s)
        if n <= limit:
            continue
        if isinstance(prev, dict) and s == str(prev.get(name) or ''):
            continue
        return {'field': name, 'length': n, 'limit': limit}
    return None


def overflow_text(who, ov):
    """The one sentence every door uses for an over-long field. The board prints it verbatim,
    so it is compared as text across the twins - two runtimes must not word one refusal two ways."""
    return ("%s's %s is %s characters - %s over the %s limit. Nothing was saved: "
            'shorten it and save again') % (
        who, ov['field'], _count(ov['length']), _count(ov['length'] - ov['limit']),
        _count(ov['limit']))


class FieldTooLong(ValueError):
    """Raised by write_state BEFORE anything is written, when a card carries a field over its
    ceiling. Every caller turns it into a 400 `field-too-long`; nothing is ever trimmed."""

    def __init__(self, card_id, ov):
        self.card_id, self.ov = card_id, ov
        ValueError.__init__(self, overflow_text('card #%d' % card_id, ov))

    def body(self):
        return {'error': 'field-too-long', 'detail': str(self), 'id': self.card_id,
                'field': self.ov['field'], 'length': self.ov['length'],
                'limit': self.ov['limit'], 'help': '/api/help'}
TRACK_KEYWORDS = [
    ('U', re.compile(r'\b(ui|hud|panel|theme|style-guide|world-layer|markers?|2d-migration|watch-panels?)\b', re.I)),
    ('C', re.compile(r'\b(construction|shipyard|station-construction|buildable|logistics-centre|dockyard|warehouse)\b', re.I)),
    ('O', re.compile(r'\b(optimi[sz]ation|optimi[sz]e|scale|throttle|cache|stress)\b', re.I)),
    ('M', re.compile(r'\b(two-body|2-body|traversal|interplanetary|avoidance|movement)\b', re.I)),
    ('E', re.compile(r'\b(economy|track[1-6]|recipe|happiness|currency|maintenance|manifests?|storage|prioritisation|governors?|consumption|resupply|crew|resident|tug|moon-station|dispatch|water-recycling|ownership)\b', re.I)),
    ('P', re.compile(r'\b(polish|fx|material|time-dilation|orientation|engine-fx|invisible|clipping)\b', re.I)),
    ('F', re.compile(r'\b(doc|diagnostics?|audit|cleanup|planning|world-model|refactor|decomposition|recipe-pattern|phase)\b', re.I)),
]

# ---- precompiled patterns for the parser ----
RE_MD = re.compile(r'\.md$', re.I)
# A record's version may be written v0.37 or v9_71 - projects differ, and a filename this
# didn't match cost the record BOTH its date and its version (its "version" came out as the
# whole filename). 74 of SpaceLogistics' 143 records parsed that way before v0.38. A trailing
# -suffix (v9.64-wip) is kept; the separator is normalised to a dot by parse_session.
RE_FNAME = re.compile(r'^(\d{4}-\d{2}-\d{2})_v([0-9]+[._][0-9]+[a-z]?(?:-[A-Za-z0-9]+)?)_(.+)$', re.I)
# The value is OPTIONAL: a bare `completes:` introduces an indented YAML list on the lines
# below it, which is how records have actually been written since ~2026-07-24.
RE_FRONT = re.compile(r'^([\w-]+):\s*(.*)$')
RE_FRONT_ITEM = re.compile(r'^\s+-\s*(.*)$')
RE_DATE = re.compile(r'\d{4}-\d{2}-\d{2}')
RE_H1 = re.compile(r'^#\s+\S')
RE_SUB = re.compile(r'^###\s+v?[0-9]')
RE_TRACK_SUFFIX = re.compile(r'·\s*([A-Za-z][\w/ ]*?)\s*track\b', re.I)
RE_VER_PREFIX = re.compile(r'^v?[0-9.]+[a-z]?(\s+baseline)?\s*·?\s*', re.I)
RE_TRACK_STRIP = re.compile(r'·\s*[A-Za-z][\w/ ]*?\s*track\b', re.I)
RE_BRANCH_WORD = re.compile(r'^branch[:\s]+', re.I)
RE_HEADER = re.compile(r'^#{2,3}\s')
RE_BQ = re.compile(r'^>\s?')
RE_COMMIT = re.compile(r'^[-*]\s+\*\*(.+?)\*\*\s*\(`?([0-9a-f]{6,40})`?\)', re.I)
RE_NEXT = re.compile(r'^(?:\d+\.|[-*])\s+(.+)$')
RE_COMMIT_HDR = re.compile(r'^#{2,3}.*\bcommits?\b.*$', re.I)
RE_NEXT_HDR = re.compile(r'^#{2,3}.*\bnext steps?\b.*$', re.I)
RE_FLAG_HDR = re.compile(r'^#{2,3}.*\b(bug|blocker)\b', re.I)
# ---- audit / Truth-layer patterns ----
RE_VER_TOKEN = re.compile(r'\bv([0-9]+(?:\.[0-9]+){0,2}[a-z]?)\b', re.I)
# A doc's version counts only when *positively declared*: a "version" label
# immediately followed by a token (RE_VER_DECL), or a single token at the END
# of a heading/title (RE_HEADING + RE_TITLE_TAIL — only trailing emphasis or
# closing punctuation after it). A token buried mid-heading ("(do not use the
# v7.00 wording)"), an incidental prose mention, or a range is provenance.
RE_VER_DECL = re.compile(r'\bversion\b[\s:*\-—]*v[0-9]', re.I)
RE_HEADING = re.compile(r'^\s{0,3}#{1,6}\s')
RE_TITLE_TAIL = re.compile(r'^[\s*_~`)\].]*$')
# ...and a token at the end of a heading is STILL provenance when a preposition
# says so. "## Host mode (shared boards / live sync, since v0.31)" sits at a
# title's end and is not a declaration - it dates a feature. That heading really
# did make CONTRACT.md report itself as v0.31 while the engine was at v0.59
# (v0.60), which was harmless as a panel chip and is not harmless now that a
# version drives a warning: a staleness detector reading the WRONG version is
# worse than none.
RE_VER_PROV = re.compile(r'\b(?:since|from|as\s+of|until|through|before|after|'
                         r'introduced\s+in|added\s+in|removed\s+in|present\s+in|in)'
                         r'[\s,:*\-—(\[]*$', re.I)


def infer_track(slug):
    for k, rx in TRACK_KEYWORDS:
        if rx.search(slug):
            return k
    return 'F'


def track_from_header(txt):
    t = (txt or '').strip().lower()
    for k in TRACK_ORDER:
        tr = TRACKS[k]
        if t in (tr['short'].lower(), tr['name'].lower(), k.lower()):
            return k
    if t.startswith('ui'): return 'U'
    if t.startswith('econ'): return 'E'
    if t.startswith('const'): return 'C'
    if t.startswith('move') or t.startswith('phys'): return 'M'
    if t.startswith('opt'): return 'O'
    if t.startswith('pol'): return 'P'
    if t.startswith('found') or t.startswith('diag'): return 'F'
    return None


# Fallback colours for declared track codes with no built-in match (cycled by order).
FALLBACK_COLORS = ['#8b8f9a', '#2bb89a', '#3f8ae0', '#d56aa0', '#8a7fe0', '#e0a23f', '#e0673f']


def resolve_tracks(cfg):
    """Resolve a project's lane palette from cfg['tracks'].

    Honors two forms (and a mix of both):
      - a code string  ("F")                       -> built-in defaults for that code
      - an object      {code,name,short,color}     -> custom lane; omitted fields fall
                                                       back to the built-in for that code
    Returns (tracks_map, order). When cfg declares no usable tracks, falls back to the
    full built-in palette (the historical behaviour), so undeclared projects are unchanged.
    """
    decl = cfg.get('tracks') if isinstance(cfg, dict) else None
    if not isinstance(decl, list) or not decl:
        return dict(TRACKS), list(TRACK_ORDER)
    tracks, order = {}, []
    for entry in decl:
        if isinstance(entry, str):
            code, custom = entry.strip(), {}
        elif isinstance(entry, dict):
            code = str(entry.get('code') or entry.get('key') or '').strip()
            custom = entry
        else:
            continue
        if not code or code in tracks:
            continue
        base = TRACKS.get(code, {})
        name = custom.get('name') or base.get('name') or code
        short = custom.get('short') or base.get('short') or name
        color = custom.get('color') or base.get('color') or FALLBACK_COLORS[len(order) % len(FALLBACK_COLORS)]
        tracks[code] = {'name': name, 'short': short, 'color': color}
        order.append(code)
    if not order:
        return dict(TRACKS), list(TRACK_ORDER)
    return tracks, order


def constrain_tracks(sessions, order):
    """Snap any session whose track is outside the project's declared set onto the first
    declared lane, so every dot has a lane to sit in (inference is built-in/global)."""
    valid = set(order)
    fb = order[0] if order else 'F'
    for s in sessions:
        if s.get('track') not in valid:
            s['track'] = fb
    return sessions


def section_body(lines, header_rx):
    idx = -1
    for i, l in enumerate(lines):
        if header_rx.search(l):
            idx = i
            break
    if idx < 0:
        return []
    body = []
    for i in range(idx + 1, len(lines)):
        if RE_HEADER.match(lines[i]):
            break
        body.append(lines[i])
    return body


def _strip_quotes(s):
    """Trim a claim and drop one matched pair of surrounding quotes, so `- "a title"`
    and `- a title` mean the same thing."""
    s = (s or '').strip()
    if len(s) >= 2 and s[0] == s[-1] and s[0] in '"\'':
        s = s[1:-1].strip()
    return s


def _claims_from_value(raw):
    """The claims named by ONE inline `completes:` value.

    Splits on commas, but NEVER inside quotes - card titles are prose and commas in them
    are normal ("Rocky maria - artifacts at fill_iters around 340 (dev-observed,
    undiagnosed)" is one card, not two). Also accepts a bracketed list, so the `[]` that
    records use to mean "this one completed nothing" reads as empty rather than as a card
    titled '[]'."""
    s = (raw or '').strip()
    if s.startswith('[') and s.endswith(']'):
        s = s[1:-1].strip()
    out, buf, quote = [], [], ''
    for ch in s:
        if quote:
            if ch == quote:
                quote = ''
            else:
                buf.append(ch)
        elif ch in '"\'':
            quote = ch
        elif ch == ',':
            out.append(''.join(buf))
            buf = []
        else:
            buf.append(ch)
    out.append(''.join(buf))
    return [t for t in (x.strip() for x in out) if t]


def parse_session(filename, text):
    base = RE_MD.sub('', filename)
    m = RE_FNAME.match(base)
    date = m.group(1) if m else ''
    version = ('v' + m.group(2).replace('_', '.')) if m else base
    slug = m.group(3) if m else base
    out = {
        'file': filename, 'date': date, 'version': version, 'slug': slug,
        'title': slug.replace('-', ' '),
        'track': 'F', 'summary': '', 'branch': '',
        'lastModified': '', 'lastVerified': '',
        'commits': [], 'next': [], 'flag': None, 'rich': False, 'completes': [],
        # `touches:` is `completes:`'s sibling - the SAME claim syntax and the same
        # number-first matching - but it only LINKS a record to a card. It never
        # changes the card's status, so a record can say "I worked on #206" without
        # claiming to have finished it.
        'touches': [],
    }
    lines = text.replace('\r\n', '\n').replace('\r', '\n').split('\n')

    # frontmatter
    if lines and lines[0].strip() == '---':
        i = 1
        while i < len(lines) and lines[i].strip() != '---':
            fm = RE_FRONT.match(lines[i])
            if fm:
                key = fm.group(1).lower()
                if key in ('completes', 'touches'):
                    # ONE parser for both keys, deliberately: `touches:` differs from
                    # `completes:` only in what the board does with the result, so any
                    # future fix to claim syntax lands on both at once.
                    raw = fm.group(2).strip()
                    claims = _claims_from_value(raw)
                    if not raw:
                        # bare `completes:` - the claims are the indented "- item" lines
                        # under it. This form was silently invisible before v0.38: the
                        # key matched nothing, the items weren't keys, and the whole
                        # list evaporated with no error anywhere.
                        while i + 1 < len(lines) and lines[i + 1].strip() != '---':
                            if not lines[i + 1].strip():   # blank lines inside a YAML list are
                                i += 1                     # legal - stopping here would drop
                                continue                   # every claim below them, silently
                            item = RE_FRONT_ITEM.match(lines[i + 1])
                            if not item:
                                break
                            v = _strip_quotes(item.group(1))
                            if v:
                                claims.append(v)
                            i += 1
                    out[key] = claims
                else:
                    dm = RE_DATE.search(fm.group(2))
                    val = dm.group(0) if dm else fm.group(2).strip()
                    if key == 'last_modified':
                        out['lastModified'] = val
                    elif key == 'last_verified':
                        out['lastVerified'] = val
            i += 1

    # H1 title
    for l in lines:
        if RE_H1.match(l):
            out['title'] = re.sub(r'^#\s+', '', l).strip()
            break

    # ### version - branch/merge - track
    track_explicit = False
    sub = None
    for l in lines:
        if RE_SUB.match(l):
            sub = l
            break
    if sub:
        s = re.sub(r'^###\s+', '', sub).strip()
        tk = RE_TRACK_SUFFIX.search(s)
        if tk:
            k = track_from_header(tk.group(1))
            if k:
                out['track'] = k
                track_explicit = True
        branch = RE_VER_PREFIX.sub('', s)
        branch = RE_TRACK_STRIP.sub('', branch).replace('`', '').strip()
        branch = RE_BRANCH_WORD.sub('', branch).strip()
        out['branch'] = branch
        out['rich'] = True
    if not track_explicit:
        out['track'] = infer_track(slug)
    if out['track'] not in TRACKS:
        out['track'] = 'F'

    # summary: first contiguous '>' blockquote run
    sum_lines = []
    started = False
    for l in lines:
        if RE_BQ.match(l):
            started = True
            sum_lines.append(RE_BQ.sub('', l))
        elif started:
            break
    if sum_lines:
        out['summary'] = re.sub(r'\s+', ' ', ' '.join(sum_lines).replace('**', '').replace('`', '')).strip()

    # commits (top-level bullets only)
    for l in section_body(lines, RE_COMMIT_HDR):
        cm = RE_COMMIT.match(l)
        if cm:
            out['commits'].append({'name': cm.group(1).strip(), 'hash': cm.group(2)})
    if out['commits']:
        out['rich'] = True

    # next steps (top-level items only)
    for l in section_body(lines, RE_NEXT_HDR):
        nm = RE_NEXT.match(l)
        if not nm:
            continue
        item = nm.group(1).replace('**', '').replace('`', '').strip()
        if len(item) > 160:
            item = item[:157].strip() + '…'
        if item:
            out['next'].append(item)
        if len(out['next']) >= 5:
            break

    # flag: first content line under a BUG/BLOCKER header
    for i, l in enumerate(lines):
        if RE_FLAG_HDR.match(l):
            for j in range(i + 1, len(lines)):
                t = lines[j].strip()
                if not t:
                    continue
                if RE_HEADER.match(t):
                    break
                t = re.sub(r'^[-*]\s+', '', t).replace('**', '').replace('`', '')
                out['flag'] = t[:220]
                break
            break
    return out


# ---- project helpers ----
def safe_name(pid):
    return bool(pid) and isinstance(pid, str) and '/' not in pid and '\\' not in pid \
        and '..' not in pid and not pid.startswith('.')


# ---- projects anywhere (v0.65) -------------------------------------------------------
# Until v0.65 a project existed for Stasys only if its folder sat DIRECTLY inside the one
# projects folder. That enforces a layout on someone else's computer, and the developer's
# ruling was plain: "we dont want to enforce how a user chooses where a project lives".
# So a project folder anywhere on the drive can be REGISTERED: its path is kept in this
# computer's own settings.json under "projects", it is listed beside the others, and every
# door finds it by its folder name exactly as before - which is the point: project_dir is
# the one place an id becomes a path, so nothing downstream had to change.
#
#   * The projects folder stays: it is the default location and it still auto-discovers
#     what is inside it. Nobody's existing layout moves.
#   * A project is known by its FOLDER NAME, so two cannot share one. A folder inside the
#     projects folder always wins the name; a second registration of a name is refused
#     before anything is created, in a sentence a person can act on.
#   * Per machine, by nature: where a project lives on THIS computer is not shared state.
#   * Nothing is ever deleted. "Forget" drops a path from the list and touches no folder.
#
# THE SANDBOX RULE, and it is the load-bearing one. Every suite, and every by-hand trial,
# points the engine at a scratch projects folder with STASYS_PROJECTS_ROOT and trusts that
# nothing outside it can be reached. A list of real project folders read out of the real
# settings would walk straight through that wall - a test PUT naming a real project would
# land on it. So when STASYS_PROJECTS_ROOT is set, registered projects are OFF unless
# STASYS_SETTINGS names the settings file to use: a sandbox gets them only by bringing its
# own. extras_index / extra_id / is_abs_path are the pure core (twin-parity fixtures).
FOLD_NAMES = os.name == 'nt'            # Windows folder names are case-insensitive
RE_ABS_DRIVE = re.compile(r'^[A-Za-z]:[\\/]')


def is_abs_path(p):
    """Absolute on Windows OR on POSIX - judged from the text alone, so both twins and
    both platforms give one answer for one string."""
    p = str(p or '')
    return bool(RE_ABS_DRIVE.match(p)) or p.startswith('/') or p.startswith('\\\\')


def extra_id(p):
    """The id a registered project is known by: its folder's own name."""
    s = str(p or '').replace('\\', '/').rstrip('/')
    return s.rsplit('/', 1)[-1] if s else ''


def extras_index(paths, taken, fold):
    """Turn the saved list of project folders into the projects it names. Pure.

    paths: whatever is under "projects" in settings.json - junk tolerated, never raised on.
    taken: names of the folders inside the projects folder; they always win a name.
    fold:  True where folder names are case-insensitive.
    Returns {'projects': [{id, path}], 'dropped': [{path, why}]} in the saved order. The
    FIRST entry to claim a name keeps it; nothing is dropped silently."""
    def key(s):
        return s.lower() if fold else s
    seen = set(key(t) for t in (taken if isinstance(taken, list) else []) if isinstance(t, str))
    mine = set()
    out, dropped = [], []
    for p in (paths if isinstance(paths, list) else []):
        if not isinstance(p, str) or not p.strip():
            continue
        p = p.strip()
        pid = extra_id(p)
        if not is_abs_path(p):
            dropped.append({'path': p, 'why': 'not a full path'})
        elif not pid or '..' in pid or pid.startswith('.') or ':' in pid:   # ':' = a bare drive
            dropped.append({'path': p, 'why': 'not a usable folder name'})
        elif key(pid) in mine:
            dropped.append({'path': p, 'why': 'another listed project is already called ' + pid})
        elif key(pid) in seen:
            dropped.append({'path': p, 'why': 'a folder called ' + pid + ' is already in the projects folder'})
        else:
            mine.add(key(pid))
            out.append({'id': pid, 'path': p})
    return {'projects': out, 'dropped': dropped}


def extras_enabled():
    """The sandbox rule above: off under STASYS_PROJECTS_ROOT unless the sandbox brought
    its own settings file."""
    if (os.environ.get('STASYS_PROJECTS_ROOT') or '').strip():
        return bool((os.environ.get('STASYS_SETTINGS') or '').strip())
    return True


_EXTRAS_CACHE = {'key': None, 'val': []}

def saved_extras():
    """The raw saved list of project folders. Read per request, so it is cached on the
    settings file's own stamp - a change made by another copy of Stasys is seen at once."""
    if not extras_enabled():
        return []
    try:
        st = os.stat(_settings_path())
        key = (st.st_mtime_ns, st.st_size)
    except OSError:
        return []
    if _EXTRAS_CACHE['key'] != key:
        v = _read_settings().get('projects')
        _EXTRAS_CACHE['val'] = [x for x in v if isinstance(x, str)] if isinstance(v, list) else []
        _EXTRAS_CACHE['key'] = key
    return list(_EXTRAS_CACHE['val'])


def extra_project_dir(pid):
    """The registered folder known by this id, or None."""
    idx = extras_index(saved_extras(), [], FOLD_NAMES)['projects']
    for e in idx:
        if e['id'] == pid:
            return e['path']
    if FOLD_NAMES:
        low = str(pid).lower()
        for e in idx:
            if e['id'].lower() == low:
                return e['path']
    return None


def _same_path(a, b):
    return os.path.normcase(os.path.abspath(a)) == os.path.normcase(os.path.abspath(b))


def register_extra(path):
    """Add a project folder to this computer's list (idempotent). True if it is listed."""
    if not extras_enabled():
        return False
    cfg = _read_settings()
    cur = [x for x in cfg.get('projects') if isinstance(x, str)] if isinstance(cfg.get('projects'), list) else []
    if any(_same_path(x, path) for x in cur if is_abs_path(x)):
        return True
    cfg['projects'] = cur + [os.path.abspath(path)]
    return _write_settings(cfg)


def forget_extra(path):
    """Drop a folder from the list. The folder itself is NEVER touched. Returns how many
    entries went."""
    if not extras_enabled():
        return 0
    cfg = _read_settings()
    cur = [x for x in cfg.get('projects') if isinstance(x, str)] if isinstance(cfg.get('projects'), list) else []
    keep = [x for x in cur if not (x.strip() == str(path).strip()
                                   or (is_abs_path(x) and is_abs_path(path) and _same_path(x, path)))]
    if len(keep) == len(cur):
        return 0
    cfg['projects'] = keep
    return (len(cur) - len(keep)) if _write_settings(cfg) else 0


def project_dir(pid):
    if not safe_name(pid):
        return None
    d = os.path.abspath(os.path.join(ROOT, pid))
    if d != os.path.join(os.path.abspath(ROOT), pid):
        return None
    if not os.path.isdir(d):
        # not a folder in the projects folder: it may be a project registered from
        # elsewhere (v0.65). A folder that IS there always wins the name.
        x = extra_project_dir(pid)
        if x:
            return os.path.abspath(x)
    return d


def tracked_project_dir(pid):
    """Like project_dir, but the project must ALREADY EXIST and be trackable.

    project_dir only sanitises the name - it happily returns a path for a folder that isn't
    there, and write_state would then create it. That's tolerable for the board, whose project
    names come from a dropdown this server filled in, but not for the patch door, whose name is
    typed by a person or an agent: a typo has to be an error, never a brand-new folder with a
    backlog inside it. Same trackable test list_projects uses, so the two can't disagree."""
    d = project_dir(pid)
    if not d or pid in EXCLUDE or not os.path.isdir(d):
        return None
    if not os.path.isdir(sessions_dir_of(d, read_config(d))):
        return None
    return d


def read_config(dirpath):
    try:
        with open(os.path.join(dirpath, '.tracker', 'config.json'), 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return None


def sessions_dir_of(dirpath, cfg):
    rel = (cfg.get('sessionsDir') if isinstance(cfg, dict) else None) or DEFAULT_SESSIONS_DIR
    rel = rel.replace('/', os.sep).replace('\\', os.sep)
    return os.path.join(dirpath, rel)


def survey_projects():
    """(the projects to list, the registered folders that could NOT be listed and why).

    Folders in the projects folder are discovered, as always. Registered folders from
    elsewhere (v0.65) are added - and one that cannot be shown is REPORTED, never just
    left out: a project that silently vanishes from the dropdown because its drive is
    unplugged looks exactly like a project that was deleted."""
    out, names, unlisted = [], [], []
    try:
        entries = os.listdir(ROOT)
    except Exception:
        entries = []
    for name in entries:
        full = os.path.join(ROOT, name)
        if not os.path.isdir(full):
            continue
        names.append(name)                       # every folder there holds its name
        if name in EXCLUDE or name.startswith('.'):
            continue
        cfg = read_config(full)
        if os.path.isdir(sessions_dir_of(full, cfg)):
            disp = cfg.get('name') if isinstance(cfg, dict) and cfg.get('name') else name
            out.append({'id': name, 'name': disp, 'path': full, 'outside': False})
    idx = extras_index(saved_extras(), names, FOLD_NAMES)
    for e in idx['dropped']:
        unlisted.append({'path': e['path'], 'why': e['why']})
    for e in idx['projects']:
        full = os.path.abspath(e['path'])
        if e['id'] in EXCLUDE:
            unlisted.append({'path': e['path'], 'why': 'not a usable folder name'})
        elif not os.path.isdir(full):
            unlisted.append({'path': e['path'], 'why': 'the folder is not there (moved, renamed, or on a drive that is not connected)'})
        else:
            cfg = read_config(full)
            if not os.path.isdir(sessions_dir_of(full, cfg)):
                unlisted.append({'path': e['path'], 'why': 'the folder has no session records folder any more'})
            else:
                disp = cfg.get('name') if isinstance(cfg, dict) and cfg.get('name') else e['id']
                out.append({'id': e['id'], 'name': disp, 'path': full, 'outside': True})
    out.sort(key=lambda x: x['name'].lower())
    return out, unlisted


def list_projects():
    return survey_projects()[0]


def browse_dirs(path):
    """The folders inside `path`, for the board's "Select project location" (v0.65).
    Folder NAMES only - never a file, never anything's contents - and only ever asked for
    by the board on this machine (the route is loopback-only and origin-guarded)."""
    home = os.path.expanduser('~')
    starts = [{'label': 'Projects folder', 'path': os.path.abspath(ROOT)}]
    for label, sub in (('Documents', 'Documents'), ('Desktop', 'Desktop')):
        if os.path.isdir(os.path.join(home, sub)):
            starts.append({'label': label, 'path': os.path.join(home, sub)})
    if os.path.isdir(home):
        starts.append({'label': 'Home', 'path': home})
    if os.name == 'nt':
        # C: onwards - asking A: or B: can stall on a machine that still has a floppy stub
        roots = [c + ':\\' for c in 'CDEFGHIJKLMNOPQRSTUVWXYZ' if os.path.isdir(c + ':\\')]
    else:
        roots = ['/']
    p = str(path or '').strip() or os.path.abspath(ROOT)
    base = {'path': p, 'parent': '', 'dirs': [], 'tracked': [], 'isProject': False,
            'roots': roots, 'starts': starts}
    if not is_abs_path(p) or not os.path.isdir(p):
        return dict(base, error='That is not a folder on this computer.')
    p = os.path.abspath(p)
    dirs = []
    try:
        with os.scandir(p) as it:
            for e in it:
                try:
                    if e.is_dir() and not e.name.startswith('.') and not e.name.startswith('$'):
                        dirs.append(e.name)
                except OSError:
                    pass
    except OSError:
        return dict(base, path=p, error='Stasys is not allowed to look inside that folder.')
    dirs.sort(key=lambda s: s.lower())
    dirs = dirs[:3000]
    parent = os.path.dirname(p)
    # Which of these ALREADY are Stasys projects - and is this folder one itself. The box
    # says so before OK is pressed, because "set this folder up" is an alarming thing to read
    # about a folder that holds a year of cards: someone reinstalling Stasys, or adding a
    # project they copied from another machine, must be told their board is kept, not left
    # to hope. Same test discovery uses (a session-records folder), gated on a .tracker/
    # folder so that looking at a big directory costs one stat per entry.
    tracked = [d for d in dirs if is_stasys_project(os.path.join(p, d))]
    return dict(base, path=p, parent='' if parent == p else parent, dirs=dirs,
                tracked=tracked, isProject=is_stasys_project(p))


# ---- the Windows "Select folder" window (v0.65) ---------------------------------------
# The first New project box had its own folder list, with two buttons that only existed
# because a home-made picker could not tell "put it in here" from "this one". The developer,
# having tested it: "using windows existing windows explorer would be better than our own
# version." So the box opens the REAL window, and the folder picked there IS the project -
# a new one is made with the window's own New folder button.
#
# The engine shows it: a script handed to powershell.exe -EncodedCommand, which opens the
# Explorer-style picker on top of everything and prints one line. The script travels INSIDE
# this file (generated from build/pick_folder.ps1), not beside it, so an update that swaps
# only the four engine files still delivers it. Only the machine the engine runs on can be
# shown a window, so the route is loopback-only and origin-guarded like the listing door.
#
# STASYS_FAKE_PICK is for the suites: a test must never put a window on someone's screen.
# The harness sets it for every suite. pick_parse is the pure half (twin-parity fixtures).
# >>> PICK_FOLDER_B64 - generated by build/gen_pick_script.py, do not edit
PICK_FOLDER_B64 = (
    'IwAgAFQAaABlACAAVwBpAG4AZABvAHcAcwAgACIAUwBlAGwAZQBjAHQAIABmAG8AbABkAGUAcgAiACAAdwBpAG4AZABvAHcALAAg'
    'AGYAbwByACAAdABoAGUAIABiAG8AYQByAGQAJwBzACAATgBlAHcAIABwAHIAbwBqAGUAYwB0ACAAYgBvAHgAIAAoAHYAMAAuADYA'
    'NQApAC4ACgAjAAoAIwAgAFQAaABpAHMAIABmAGkAbABlACAAaQBzACAAdABoAGUAIABTAE8AVQBSAEMARQAuACAASQB0ACAAaQBz'
    'ACAAbgBvAHQAIABzAGgAaQBwAHAAZQBkACAAYQBuAGQAIABuAG8AdAAgAHIAdQBuACAAZgByAG8AbQAgAGgAZQByAGUAOgAgAGIA'
    'dQBpAGwAZABcAGcAZQBuAF8AcABpAGMAawBfAHMAYwByAGkAcAB0AC4AcAB5AAoAIwAgAGUAbgBjAG8AZABlAHMAIABpAHQAIABp'
    'AG4AdABvACAAYgBvAHQAaAAgAGUAbgBnAGkAbgBlACAAdAB3AGkAbgBzACAAYQBzACAAUABJAEMASwBfAEYATwBMAEQARQBSAF8A'
    'QgA2ADQALAAgAGEAbgBkACAAdABoAGUAIABlAG4AZwBpAG4AZQAgAGgAYQBuAGQAcwAgAHQAaABhAHQAIAB0AG8ACgAjACAAcABv'
    'AHcAZQByAHMAaABlAGwAbAAuAGUAeABlACAALQBFAG4AYwBvAGQAZQBkAEMAbwBtAG0AYQBuAGQALgAgAFMAbwAgAHQAaABlACAA'
    'ZQBuAGcAaQBuAGUAIABuAGUAZQBkAHMAIABuAG8AIABlAHgAdAByAGEAIABmAGkAbABlACAAYgBlAHMAaQBkAGUAIABpAHQAIAAt'
    'ACAAYQBuACAAdQBwAGQAYQB0AGUAIAB0AGgAYQB0AAoAIwAgAHIAZQBwAGwAYQBjAGUAcwAgAG8AbgBsAHkAIAB0AGgAZQAgAGYA'
    'bwB1AHIAIABlAG4AZwBpAG4AZQAgAGYAaQBsAGUAcwAgAHMAdABpAGwAbAAgAGQAZQBsAGkAdgBlAHIAcwAgAHQAaABpAHMALgAK'
    'ACMACgAjACAASQBuADoAIAAgACAAJABlAG4AdgA6AFMAVABBAFMAWQBTAF8AUABJAEMASwBfAFMAVABBAFIAVAAgACAAIAB0AGgA'
    'ZQAgAGYAbwBsAGQAZQByACAAdABvACAAbwBwAGUAbgAgAGkAbgAgACgAbwBwAHQAaQBvAG4AYQBsACkACgAjACAAIAAgACAAIAAg'
    'ACAAJABlAG4AdgA6AFMAVABBAFMAWQBTAF8AUABJAEMASwBfAEQAUgBZACAAIAAgACAAIABzAGUAdAAgAD0AIABsAG8AYQBkACAA'
    'ZQB2AGUAcgB5AHQAaABpAG4AZwAsACAAYgB1AGkAbABkACAAdABoAGUAIABkAGkAYQBsAG8AZwAsACAARABPACAATgBPAFQAIABz'
    'AGgAbwB3ACAAaQB0AAoAIwAgAE8AdQB0ADoAIAAgAG8AbgBlACAAbABpAG4AZQAgAG8AbgAgAHMAdABkAG8AdQB0ADoAIAAgAFAA'
    'SQBDAEsARQBEADoAPABmAHUAbABsACAAcABhAHQAaAA+ACAAIAB8ACAAIABDAEEATgBDAEUATABMAEUARAAgACAAfAAgACAARABS'
    'AFkAOgA8AHMAdABhAHIAdAA+ACAAIAB8ACAAIABGAEEASQBMAEUARAA6ADwAdwBoAHkAPgAKACMACgAjACAASQB0ACAAaQBzACAA'
    'dABoAGUAIABtAG8AZABlAHIAbgAgAEUAeABwAGwAbwByAGUAcgAtAHMAdAB5AGwAZQAgAHcAaQBuAGQAbwB3ACAAKABJAEYAaQBs'
    'AGUATwBwAGUAbgBEAGkAYQBsAG8AZwAgAHcAaQB0AGgAIABGAE8AUwBfAFAASQBDAEsARgBPAEwARABFAFIAUwApACAALQAgAHQA'
    'aABlACAAbwBuAGUAIAB3AGkAdABoAAoAIwAgAHQAaABlACAAYQBkAGQAcgBlAHMAcwAgAGIAYQByACwAIAB0AGgAZQAgAHMAaQBk'
    'AGUAYgBhAHIAIABhAG4AZAAgAGEAIAAiAE4AZQB3ACAAZgBvAGwAZABlAHIAIgAgAGIAdQB0AHQAbwBuACAALQAgAGEAbgBkACAA'
    'ZgBhAGwAbABzACAAYgBhAGMAawAgAHQAbwAgAHQAaABlACAAbwBsAGQAZQByACAAdAByAGUAZQAKACMAIAB3AGkAbgBkAG8AdwAg'
    'AGkAZgAgAHQAaABhAHQAIABjAGEAbgBuAG8AdAAgAGIAZQAgAGMAcgBlAGEAdABlAGQALgAgAEEAIABwAGUAcgBzAG8AbgAgAG0A'
    'YQBrAGUAcwAgAGEAIABuAGUAdwAgAHAAcgBvAGoAZQBjAHQAIABiAHkAIABtAGEAawBpAG4AZwAgAGEAIABuAGUAdwAgAGYAbwBs'
    'AGQAZQByACAAcgBpAGcAaAB0AAoAIwAgAHQAaABlAHIAZQAgAGEAbgBkACAAcwBlAGwAZQBjAHQAaQBuAGcAIABpAHQALgAKACQA'
    'RQByAHIAbwByAEEAYwB0AGkAbwBuAFAAcgBlAGYAZQByAGUAbgBjAGUAIAA9ACAAJwBTAHQAbwBwACcACgAkAFAAcgBvAGcAcgBl'
    'AHMAcwBQAHIAZQBmAGUAcgBlAG4AYwBlACAAPQAgACcAUwBpAGwAZQBuAHQAbAB5AEMAbwBuAHQAaQBuAHUAZQAnAAoAdAByAHkA'
    'IAB7ACAAWwBDAG8AbgBzAG8AbABlAF0AOgA6AE8AdQB0AHAAdQB0AEUAbgBjAG8AZABpAG4AZwAgAD0AIABOAGUAdwAtAE8AYgBq'
    'AGUAYwB0ACAAUwB5AHMAdABlAG0ALgBUAGUAeAB0AC4AVQBUAEYAOABFAG4AYwBvAGQAaQBuAGcAKAAkAGYAYQBsAHMAZQApACAA'
    'fQAgAGMAYQB0AGMAaAAgAHsAfQAKACQAcwB0AGEAcgB0ACAAPQAgAFsAcwB0AHIAaQBuAGcAXQAkAGUAbgB2ADoAUwBUAEEAUwBZ'
    'AFMAXwBQAEkAQwBLAF8AUwBUAEEAUgBUAAoAJAB0AGkAdABsAGUAIAA9ACAAJwBTAGUAbABlAGMAdAAgAHQAaABlACAAcAByAG8A'
    'agBlAGMAdAAgAGYAbwBsAGQAZQByACcACgAKAHQAcgB5ACAAewAKACAAIABBAGQAZAAtAFQAeQBwAGUAIAAtAEEAcwBzAGUAbQBi'
    'AGwAeQBOAGEAbQBlACAAUwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAAoAIAAgAEEAZABkAC0AVAB5AHAA'
    'ZQAgAC0AVAB5AHAAZQBEAGUAZgBpAG4AaQB0AGkAbwBuACAAQAAnAAoAdQBzAGkAbgBnACAAUwB5AHMAdABlAG0AOwAKAHUAcwBp'
    'AG4AZwAgAFMAeQBzAHQAZQBtAC4AUgB1AG4AdABpAG0AZQAuAEkAbgB0AGUAcgBvAHAAUwBlAHIAdgBpAGMAZQBzADsACgBuAGEA'
    'bQBlAHMAcABhAGMAZQAgAFMAdABhAHMAeQBzAFAAaQBjAGsAIAB7AAoAIAAgAFsAQwBvAG0ASQBtAHAAbwByAHQALAAgAEcAdQBp'
    'AGQAKAAiAEQAQwAxAEMANQBBADkAQwAtAEUAOAA4AEEALQA0AGQAZABlAC0AQQA1AEEAMQAtADYAMABGADgAMgBBADIAMABBAEUA'
    'RgA3ACIAKQBdAAoAIAAgAHAAdQBiAGwAaQBjACAAYwBsAGEAcwBzACAARgBpAGwAZQBPAHAAZQBuAEQAaQBhAGwAbwBnAFIAQwBX'
    'ACAAewAgAH0ACgAKACAAIABbAEMAbwBtAEkAbQBwAG8AcgB0ACwAIABHAHUAaQBkACgAIgA0ADMAOAAyADYARAAxAEUALQBFADcA'
    'MQA4AC0ANAAyAEUARQAtAEIAQwA1ADUALQBBADEARQAyADYAMQBDADMANwBCAEYARQAiACkALAAgAEkAbgB0AGUAcgBmAGEAYwBl'
    'AFQAeQBwAGUAKABDAG8AbQBJAG4AdABlAHIAZgBhAGMAZQBUAHkAcABlAC4ASQBuAHQAZQByAGYAYQBjAGUASQBzAEkAVQBuAGsA'
    'bgBvAHcAbgApAF0ACgAgACAAcAB1AGIAbABpAGMAIABpAG4AdABlAHIAZgBhAGMAZQAgAEkAUwBoAGUAbABsAEkAdABlAG0AIAB7'
    'AAoAIAAgACAAIAB2AG8AaQBkACAAQgBpAG4AZABUAG8ASABhAG4AZABsAGUAcgAoACkAOwAKACAAIAAgACAAdgBvAGkAZAAgAEcA'
    'ZQB0AFAAYQByAGUAbgB0ACgAKQA7AAoAIAAgACAAIABbAFAAcgBlAHMAZQByAHYAZQBTAGkAZwBdACAAaQBuAHQAIABHAGUAdABE'
    'AGkAcwBwAGwAYQB5AE4AYQBtAGUAKAB1AGkAbgB0ACAAcwBpAGcAZABuAE4AYQBtAGUALAAgAG8AdQB0ACAASQBuAHQAUAB0AHIA'
    'IABwAHAAcwB6AE4AYQBtAGUAKQA7AAoAIAAgACAAIAB2AG8AaQBkACAARwBlAHQAQQB0AHQAcgBpAGIAdQB0AGUAcwAoACkAOwAK'
    'ACAAIAAgACAAdgBvAGkAZAAgAEMAbwBtAHAAYQByAGUAKAApADsACgAgACAAfQAKAAoAIAAgAC8ALwAgAEkATQBvAGQAYQBsAFcA'
    'aQBuAGQAbwB3ADoAOgBTAGgAbwB3ACwAIAB0AGgAZQBuACAASQBGAGkAbABlAEQAaQBhAGwAbwBnACAAaQBuACAAdgB0AGEAYgBs'
    'AGUAIABvAHIAZABlAHIALgAgAFMAbABvAHQAcwAgAHQAaABhAHQAIABhAHIAZQAgAG4AZQB2AGUAcgAgAGMAYQBsAGwAZQBkACAA'
    'YQByAGUACgAgACAALwAvACAAZABlAGMAbABhAHIAZQBkACAAYgBhAHIAZQA6ACAAdwBoAGEAdAAgAG0AYQB0AHQAZQByAHMAIABp'
    'AHMAIAB0AGgAYQB0ACAAZQBhAGMAaAAgAG8AbgBlACAAaABvAGwAZABzACAAaQB0AHMAIABwAGwAYQBjAGUALgAKACAAIABbAEMA'
    'bwBtAEkAbQBwAG8AcgB0ACwAIABHAHUAaQBkACgAIgA0ADIAZgA4ADUAMQAzADYALQBkAGIANwBlAC0ANAAzADkAYwAtADgANQBm'
    'ADEALQBlADQAMAA3ADUAZAAxADMANQBmAGMAOAAiACkALAAgAEkAbgB0AGUAcgBmAGEAYwBlAFQAeQBwAGUAKABDAG8AbQBJAG4A'
    'dABlAHIAZgBhAGMAZQBUAHkAcABlAC4ASQBuAHQAZQByAGYAYQBjAGUASQBzAEkAVQBuAGsAbgBvAHcAbgApAF0ACgAgACAAcAB1'
    'AGIAbABpAGMAIABpAG4AdABlAHIAZgBhAGMAZQAgAEkARgBpAGwAZQBEAGkAYQBsAG8AZwAgAHsACgAgACAAIAAgAFsAUAByAGUA'
    'cwBlAHIAdgBlAFMAaQBnAF0AIABpAG4AdAAgAFMAaABvAHcAKABJAG4AdABQAHQAcgAgAHAAYQByAGUAbgB0ACkAOwAKACAAIAAg'
    'ACAAdgBvAGkAZAAgAFMAZQB0AEYAaQBsAGUAVAB5AHAAZQBzACgAKQA7AAoAIAAgACAAIAB2AG8AaQBkACAAUwBlAHQARgBpAGwA'
    'ZQBUAHkAcABlAEkAbgBkAGUAeAAoACkAOwAKACAAIAAgACAAdgBvAGkAZAAgAEcAZQB0AEYAaQBsAGUAVAB5AHAAZQBJAG4AZABl'
    'AHgAKAApADsACgAgACAAIAAgAHYAbwBpAGQAIABBAGQAdgBpAHMAZQAoACkAOwAKACAAIAAgACAAdgBvAGkAZAAgAFUAbgBhAGQA'
    'dgBpAHMAZQAoACkAOwAKACAAIAAgACAAWwBQAHIAZQBzAGUAcgB2AGUAUwBpAGcAXQAgAGkAbgB0ACAAUwBlAHQATwBwAHQAaQBv'
    'AG4AcwAoAHUAaQBuAHQAIABmAG8AcwApADsACgAgACAAIAAgAFsAUAByAGUAcwBlAHIAdgBlAFMAaQBnAF0AIABpAG4AdAAgAEcA'
    'ZQB0AE8AcAB0AGkAbwBuAHMAKABvAHUAdAAgAHUAaQBuAHQAIABmAG8AcwApADsACgAgACAAIAAgAHYAbwBpAGQAIABTAGUAdABE'
    'AGUAZgBhAHUAbAB0AEYAbwBsAGQAZQByACgAKQA7AAoAIAAgACAAIABbAFAAcgBlAHMAZQByAHYAZQBTAGkAZwBdACAAaQBuAHQA'
    'IABTAGUAdABGAG8AbABkAGUAcgAoAEkAUwBoAGUAbABsAEkAdABlAG0AIABwAHMAaQApADsACgAgACAAIAAgAHYAbwBpAGQAIABH'
    'AGUAdABGAG8AbABkAGUAcgAoACkAOwAKACAAIAAgACAAdgBvAGkAZAAgAEcAZQB0AEMAdQByAHIAZQBuAHQAUwBlAGwAZQBjAHQA'
    'aQBvAG4AKAApADsACgAgACAAIAAgAHYAbwBpAGQAIABTAGUAdABGAGkAbABlAE4AYQBtAGUAKAApADsACgAgACAAIAAgAHYAbwBp'
    'AGQAIABHAGUAdABGAGkAbABlAE4AYQBtAGUAKAApADsACgAgACAAIAAgAFsAUAByAGUAcwBlAHIAdgBlAFMAaQBnAF0AIABpAG4A'
    'dAAgAFMAZQB0AFQAaQB0AGwAZQAoAFsATQBhAHIAcwBoAGEAbABBAHMAKABVAG4AbQBhAG4AYQBnAGUAZABUAHkAcABlAC4ATABQ'
    'AFcAUwB0AHIAKQBdACAAcwB0AHIAaQBuAGcAIABwAHMAegBUAGkAdABsAGUAKQA7AAoAIAAgACAAIABbAFAAcgBlAHMAZQByAHYA'
    'ZQBTAGkAZwBdACAAaQBuAHQAIABTAGUAdABPAGsAQgB1AHQAdABvAG4ATABhAGIAZQBsACgAWwBNAGEAcgBzAGgAYQBsAEEAcwAo'
    'AFUAbgBtAGEAbgBhAGcAZQBkAFQAeQBwAGUALgBMAFAAVwBTAHQAcgApAF0AIABzAHQAcgBpAG4AZwAgAHAAcwB6AFQAZQB4AHQA'
    'KQA7AAoAIAAgACAAIAB2AG8AaQBkACAAUwBlAHQARgBpAGwAZQBOAGEAbQBlAEwAYQBiAGUAbAAoACkAOwAKACAAIAAgACAAWwBQ'
    'AHIAZQBzAGUAcgB2AGUAUwBpAGcAXQAgAGkAbgB0ACAARwBlAHQAUgBlAHMAdQBsAHQAKABvAHUAdAAgAEkAUwBoAGUAbABsAEkA'
    'dABlAG0AIABwAHAAcwBpACkAOwAKACAAIAB9AAoACgAgACAAcAB1AGIAbABpAGMAIABzAHQAYQB0AGkAYwAgAGMAbABhAHMAcwAg'
    'AFAAaQBjAGsAZQByACAAewAKACAAIAAgACAAWwBEAGwAbABJAG0AcABvAHIAdAAoACIAcwBoAGUAbABsADMAMgAuAGQAbABsACIA'
    'LAAgAEMAaABhAHIAUwBlAHQAIAA9ACAAQwBoAGEAcgBTAGUAdAAuAFUAbgBpAGMAbwBkAGUALAAgAFAAcgBlAHMAZQByAHYAZQBT'
    'AGkAZwAgAD0AIAB0AHIAdQBlACkAXQAKACAAIAAgACAAcwB0AGEAdABpAGMAIABlAHgAdABlAHIAbgAgAGkAbgB0ACAAUwBIAEMA'
    'cgBlAGEAdABlAEkAdABlAG0ARgByAG8AbQBQAGEAcgBzAGkAbgBnAE4AYQBtAGUAKABzAHQAcgBpAG4AZwAgAHAAcwB6AFAAYQB0'
    'AGgALAAgAEkAbgB0AFAAdAByACAAcABiAGMALAAgAHIAZQBmACAARwB1AGkAZAAgAHIAaQBpAGQALAAgAG8AdQB0ACAASQBTAGgA'
    'ZQBsAGwASQB0AGUAbQAgAHAAcAB2ACkAOwAKAAoAIAAgACAAIABjAG8AbgBzAHQAIAB1AGkAbgB0ACAARgBPAFMAXwBQAEkAQwBL'
    'AEYATwBMAEQARQBSAFMAIAA9ACAAMAB4ADIAMAAsACAARgBPAFMAXwBGAE8AUgBDAEUARgBJAEwARQBTAFkAUwBUAEUATQAgAD0A'
    'IAAwAHgANAAwACwAIABGAE8AUwBfAFAAQQBUAEgATQBVAFMAVABFAFgASQBTAFQAIAA9ACAAMAB4ADgAMAAwADsACgAgACAAIAAg'
    'AGMAbwBuAHMAdAAgAHUAaQBuAHQAIABTAEkARwBEAE4AXwBGAEkATABFAFMAWQBTAFAAQQBUAEgAIAA9ACAAMAB4ADgAMAAwADUA'
    'OAAwADAAMAA7AAoACgAgACAAIAAgAC8ALwAgAFIAZQB0AHUAcgBuAHMAIAB0AGgAZQAgAGMAaABvAHMAZQBuACAAcABhAHQAaAAs'
    'ACAAIgAiACAAaQBmACAAdABoAGUAIABwAGUAcgBzAG8AbgAgAGMAYQBuAGMAZQBsAGwAZQBkAC4AIABkAHIAeQAgAD0AIABiAHUA'
    'aQBsAGQAIABpAHQALAAgAG4AZQB2AGUAcgAgAHMAaABvAHcAIABpAHQALgAKACAAIAAgACAAcAB1AGIAbABpAGMAIABzAHQAYQB0'
    'AGkAYwAgAHMAdAByAGkAbgBnACAAUABpAGMAawAoAEkAbgB0AFAAdAByACAAbwB3AG4AZQByACwAIABzAHQAcgBpAG4AZwAgAHQA'
    'aQB0AGwAZQAsACAAcwB0AHIAaQBuAGcAIABzAHQAYQByAHQALAAgAGIAbwBvAGwAIABkAHIAeQApACAAewAKACAAIAAgACAAIAAg'
    'AEkARgBpAGwAZQBEAGkAYQBsAG8AZwAgAGQAbABnACAAPQAgACgASQBGAGkAbABlAEQAaQBhAGwAbwBnACkAbgBlAHcAIABGAGkA'
    'bABlAE8AcABlAG4ARABpAGEAbABvAGcAUgBDAFcAKAApADsACgAgACAAIAAgACAAIAB0AHIAeQAgAHsACgAgACAAIAAgACAAIAAg'
    'ACAAdQBpAG4AdAAgAG8AcAB0AHMAOwAKACAAIAAgACAAIAAgACAAIABkAGwAZwAuAEcAZQB0AE8AcAB0AGkAbwBuAHMAKABvAHUA'
    'dAAgAG8AcAB0AHMAKQA7AAoAIAAgACAAIAAgACAAIAAgAGQAbABnAC4AUwBlAHQATwBwAHQAaQBvAG4AcwAoAG8AcAB0AHMAIAB8'
    'ACAARgBPAFMAXwBQAEkAQwBLAEYATwBMAEQARQBSAFMAIAB8ACAARgBPAFMAXwBGAE8AUgBDAEUARgBJAEwARQBTAFkAUwBUAEUA'
    'TQAgAHwAIABGAE8AUwBfAFAAQQBUAEgATQBVAFMAVABFAFgASQBTAFQAKQA7AAoAIAAgACAAIAAgACAAIAAgAGQAbABnAC4AUwBl'
    'AHQAVABpAHQAbABlACgAdABpAHQAbABlACkAOwAKACAAIAAgACAAIAAgACAAIABkAGwAZwAuAFMAZQB0AE8AawBCAHUAdAB0AG8A'
    'bgBMAGEAYgBlAGwAKAAiAFMAZQBsAGUAYwB0ACAAdABoAGkAcwAgAGYAbwBsAGQAZQByACIAKQA7AAoAIAAgACAAIAAgACAAIAAg'
    'AGkAZgAgACgAIQBTAHQAcgBpAG4AZwAuAEkAcwBOAHUAbABsAE8AcgBFAG0AcAB0AHkAKABzAHQAYQByAHQAKQApACAAewAKACAA'
    'IAAgACAAIAAgACAAIAAgACAARwB1AGkAZAAgAGkAaQBkACAAPQAgAHQAeQBwAGUAbwBmACgASQBTAGgAZQBsAGwASQB0AGUAbQAp'
    'AC4ARwBVAEkARAA7AAoAIAAgACAAIAAgACAAIAAgACAAIABJAFMAaABlAGwAbABJAHQAZQBtACAAaQB0AGUAbQA7AAoAIAAgACAA'
    'IAAgACAAIAAgACAAIABpAGYAIAAoAFMASABDAHIAZQBhAHQAZQBJAHQAZQBtAEYAcgBvAG0AUABhAHIAcwBpAG4AZwBOAGEAbQBl'
    'ACgAcwB0AGEAcgB0ACwAIABJAG4AdABQAHQAcgAuAFoAZQByAG8ALAAgAHIAZQBmACAAaQBpAGQALAAgAG8AdQB0ACAAaQB0AGUA'
    'bQApACAAPQA9ACAAMAAgACYAJgAgAGkAdABlAG0AIAAhAD0AIABuAHUAbABsACkAIABkAGwAZwAuAFMAZQB0AEYAbwBsAGQAZQBy'
    'ACgAaQB0AGUAbQApADsACgAgACAAIAAgACAAIAAgACAAfQAKACAAIAAgACAAIAAgACAAIABpAGYAIAAoAGQAcgB5ACkAIAByAGUA'
    'dAB1AHIAbgAgACIAIgA7AAoAIAAgACAAIAAgACAAIAAgAGkAZgAgACgAZABsAGcALgBTAGgAbwB3ACgAbwB3AG4AZQByACkAIAAh'
    'AD0AIAAwACkAIAByAGUAdAB1AHIAbgAgACIAIgA7ACAAIAAgACAAIAAgACAAIAAgACAAIAAgAC8ALwAgAGMAYQBuAGMAZQBsAGwA'
    'ZQBkACAAKABvAHIAIABjAGwAbwBzAGUAZAApAAoAIAAgACAAIAAgACAAIAAgAEkAUwBoAGUAbABsAEkAdABlAG0AIAByAGUAcwA7'
    'AAoAIAAgACAAIAAgACAAIAAgAGkAZgAgACgAZABsAGcALgBHAGUAdABSAGUAcwB1AGwAdAAoAG8AdQB0ACAAcgBlAHMAKQAgACEA'
    'PQAgADAAIAB8AHwAIAByAGUAcwAgAD0APQAgAG4AdQBsAGwAKQAgAHIAZQB0AHUAcgBuACAAIgAiADsACgAgACAAIAAgACAAIAAg'
    'ACAASQBuAHQAUAB0AHIAIABwADsACgAgACAAIAAgACAAIAAgACAAaQBmACAAKAByAGUAcwAuAEcAZQB0AEQAaQBzAHAAbABhAHkA'
    'TgBhAG0AZQAoAFMASQBHAEQATgBfAEYASQBMAEUAUwBZAFMAUABBAFQASAAsACAAbwB1AHQAIABwACkAIAAhAD0AIAAwACAAfAB8'
    'ACAAcAAgAD0APQAgAEkAbgB0AFAAdAByAC4AWgBlAHIAbwApACAAcgBlAHQAdQByAG4AIAAiACIAOwAKACAAIAAgACAAIAAgACAA'
    'IAB0AHIAeQAgAHsAIAByAGUAdAB1AHIAbgAgAE0AYQByAHMAaABhAGwALgBQAHQAcgBUAG8AUwB0AHIAaQBuAGcAVQBuAGkAKABw'
    'ACkAOwAgAH0AIABmAGkAbgBhAGwAbAB5ACAAewAgAE0AYQByAHMAaABhAGwALgBGAHIAZQBlAEMAbwBUAGEAcwBrAE0AZQBtACgA'
    'cAApADsAIAB9AAoAIAAgACAAIAAgACAAfQAgAGYAaQBuAGEAbABsAHkAIAB7ACAATQBhAHIAcwBoAGEAbAAuAFIAZQBsAGUAYQBz'
    'AGUAQwBvAG0ATwBiAGoAZQBjAHQAKABkAGwAZwApADsAIAB9AAoAIAAgACAAIAB9AAoAIAAgAH0ACgB9AAoAJwBAAAoAfQAgAGMA'
    'YQB0AGMAaAAgAHsACgAgACAAVwByAGkAdABlAC0ATwB1AHQAcAB1AHQAIAAoACcARgBBAEkATABFAEQAOgBjAG8AdQBsAGQAIABu'
    'AG8AdAAgAGwAbwBhAGQAIAB0AGgAZQAgAGYAbwBsAGQAZQByACAAdwBpAG4AZABvAHcAIAAoACcAIAArACAAJABfAC4ARQB4AGMA'
    'ZQBwAHQAaQBvAG4ALgBNAGUAcwBzAGEAZwBlACAAKwAgACcAKQAnACkACgAgACAAZQB4AGkAdAAgADAACgB9AAoACgBpAGYAIAAo'
    'ACQAcwB0AGEAcgB0ACAALQBhAG4AZAAgAC0AbgBvAHQAIAAoAFQAZQBzAHQALQBQAGEAdABoACAALQBMAGkAdABlAHIAYQBsAFAA'
    'YQB0AGgAIAAkAHMAdABhAHIAdAAgAC0AUABhAHQAaABUAHkAcABlACAAQwBvAG4AdABhAGkAbgBlAHIAKQApACAAewAgACQAcwB0'
    'AGEAcgB0ACAAPQAgACcAJwAgAH0ACgAKACMAIABBAG4AIABpAG4AdgBpAHMAaQBiAGwAZQAgAGEAbAB3AGEAeQBzAC0AbwBuAC0A'
    'dABvAHAAIABvAHcAbgBlAHIAOgAgAHQAaABpAHMAIABwAHIAbwBjAGUAcwBzACAAdwBhAHMAIABzAHQAYQByAHQAZQBkACAAYgB5'
    'ACAAYQAgAHcAaQBuAGQAbwB3AGwAZQBzAHMAIABzAGUAcgB2AGUAcgAsACAAYQBuAGQACgAjACAAdwBpAHQAaABvAHUAdAAgAGEA'
    'bgAgAG8AdwBuAGUAcgAgAHQAaABhAHQAIABpAG4AcwBpAHMAdABzACAAbwBuACAAdABoAGUAIABmAHIAbwBuAHQAIAB0AGgAZQAg'
    'AHcAaQBuAGQAbwB3ACAAYwBhAG4AIABvAHAAZQBuACAAQgBFAEgASQBOAEQAIAB0AGgAZQAgAGIAbwBhAHIAZAAuAAoAJABvAHcA'
    'bgBlAHIAIAA9ACAATgBlAHcALQBPAGIAagBlAGMAdAAgAFMAeQBzAHQAZQBtAC4AVwBpAG4AZABvAHcAcwAuAEYAbwByAG0AcwAu'
    'AEYAbwByAG0ACgAkAG8AdwBuAGUAcgAuAFQAbwBwAE0AbwBzAHQAIAA9ACAAJAB0AHIAdQBlAAoAJABvAHcAbgBlAHIALgBTAGgA'
    'bwB3AEkAbgBUAGEAcwBrAGIAYQByACAAPQAgACQAZgBhAGwAcwBlAAoAJABvAHcAbgBlAHIALgBGAG8AcgBtAEIAbwByAGQAZQBy'
    'AFMAdAB5AGwAZQAgAD0AIAAnAE4AbwBuAGUAJwAKACQAbwB3AG4AZQByAC4AUwB0AGEAcgB0AFAAbwBzAGkAdABpAG8AbgAgAD0A'
    'IAAnAEMAZQBuAHQAZQByAFMAYwByAGUAZQBuACcACgAkAG8AdwBuAGUAcgAuAFMAaQB6AGUAIAA9ACAATgBlAHcALQBPAGIAagBl'
    'AGMAdAAgAFMAeQBzAHQAZQBtAC4ARAByAGEAdwBpAG4AZwAuAFMAaQB6AGUAKAAxACwAIAAxACkACgAkAG8AdwBuAGUAcgAuAE8A'
    'cABhAGMAaQB0AHkAIAA9ACAAMAAKAAoAJABkAHIAeQAgAD0AIABbAGIAbwBvAGwAXQAkAGUAbgB2ADoAUwBUAEEAUwBZAFMAXwBQ'
    'AEkAQwBLAF8ARABSAFkACgAkAHAAaQBjAGsAZQBkACAAPQAgACcAJwAKAHQAcgB5ACAAewAKACAAIABpAGYAIAAoAC0AbgBvAHQA'
    'IAAkAGQAcgB5ACkAIAB7ACAAJABvAHcAbgBlAHIALgBTAGgAbwB3ACgAKQA7ACAAJABvAHcAbgBlAHIALgBBAGMAdABpAHYAYQB0'
    'AGUAKAApACAAfQAKACAAIAB0AHIAeQAgAHsACgAgACAAIAAgACQAcABpAGMAawBlAGQAIAA9ACAAWwBTAHQAYQBzAHkAcwBQAGkA'
    'YwBrAC4AUABpAGMAawBlAHIAXQA6ADoAUABpAGMAawAoACQAbwB3AG4AZQByAC4ASABhAG4AZABsAGUALAAgACQAdABpAHQAbABl'
    'ACwAIAAkAHMAdABhAHIAdAAsACAAJABkAHIAeQApAAoAIAAgAH0AIABjAGEAdABjAGgAIAB7AAoAIAAgACAAIABpAGYAIAAoACQA'
    'ZAByAHkAKQAgAHsAIAB0AGgAcgBvAHcAIAB9AAoAIAAgACAAIAAjACAAdABoAGUAIABtAG8AZABlAHIAbgAgAHcAaQBuAGQAbwB3'
    'ACAAYwBvAHUAbABkACAAbgBvAHQAIABiAGUAIABtAGEAZABlACAALQAgAHUAcwBlACAAdABoAGUAIABvAGwAZABlAHIAIAB0AHIA'
    'ZQBlACAAdwBpAG4AZABvAHcAIAByAGEAdABoAGUAcgAgAHQAaABhAG4AIABuAG8AdABoAGkAbgBnAAoAIAAgACAAIAAkAGYAYgAg'
    'AD0AIABOAGUAdwAtAE8AYgBqAGUAYwB0ACAAUwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4ARgBvAGwA'
    'ZABlAHIAQgByAG8AdwBzAGUAcgBEAGkAYQBsAG8AZwAKACAAIAAgACAAJABmAGIALgBEAGUAcwBjAHIAaQBwAHQAaQBvAG4AIAA9'
    'ACAAJAB0AGkAdABsAGUACgAgACAAIAAgACQAZgBiAC4AUwBoAG8AdwBOAGUAdwBGAG8AbABkAGUAcgBCAHUAdAB0AG8AbgAgAD0A'
    'IAAkAHQAcgB1AGUACgAgACAAIAAgAGkAZgAgACgAJABzAHQAYQByAHQAKQAgAHsAIAAkAGYAYgAuAFMAZQBsAGUAYwB0AGUAZABQ'
    'AGEAdABoACAAPQAgACQAcwB0AGEAcgB0ACAAfQAKACAAIAAgACAAaQBmACAAKAAkAGYAYgAuAFMAaABvAHcARABpAGEAbABvAGcA'
    'KAAkAG8AdwBuAGUAcgApACAALQBlAHEAIABbAFMAeQBzAHQAZQBtAC4AVwBpAG4AZABvAHcAcwAuAEYAbwByAG0AcwAuAEQAaQBh'
    'AGwAbwBnAFIAZQBzAHUAbAB0AF0AOgA6AE8ASwApACAAewAgACQAcABpAGMAawBlAGQAIAA9ACAAJABmAGIALgBTAGUAbABlAGMA'
    'dABlAGQAUABhAHQAaAAgAH0ACgAgACAAfQAKAH0AIABjAGEAdABjAGgAIAB7AAoAIAAgAFcAcgBpAHQAZQAtAE8AdQB0AHAAdQB0'
    'ACAAKAAnAEYAQQBJAEwARQBEADoAJwAgACsAIAAkAF8ALgBFAHgAYwBlAHAAdABpAG8AbgAuAE0AZQBzAHMAYQBnAGUAKQAKACAA'
    'IABlAHgAaQB0ACAAMAAKAH0AIABmAGkAbgBhAGwAbAB5ACAAewAKACAAIAB0AHIAeQAgAHsAIAAkAG8AdwBuAGUAcgAuAEMAbABv'
    'AHMAZQAoACkAOwAgACQAbwB3AG4AZQByAC4ARABpAHMAcABvAHMAZQAoACkAIAB9ACAAYwBhAHQAYwBoACAAewB9AAoAfQAKAAoA'
    'aQBmACAAKAAkAGQAcgB5ACkAIAB7ACAAVwByAGkAdABlAC0ATwB1AHQAcAB1AHQAIAAoACcARABSAFkAOgAnACAAKwAgACQAcwB0'
    'AGEAcgB0ACkAIAB9AAoAZQBsAHMAZQBpAGYAIAAoACQAcABpAGMAawBlAGQAKQAgAHsAIABXAHIAaQB0AGUALQBPAHUAdABwAHUA'
    'dAAgACgAJwBQAEkAQwBLAEUARAA6ACcAIAArACAAJABwAGkAYwBrAGUAZAApACAAfQAKAGUAbABzAGUAIAB7ACAAVwByAGkAdABl'
    'AC0ATwB1AHQAcAB1AHQAIAAnAEMAQQBOAEMARQBMAEwARQBEACcAIAB9AAoAZQB4AGkAdAAgADAACgA='
)
# <<< PICK_FOLDER_B64
PICK_TIMEOUT = 15 * 60        # a window left open and forgotten is closed after this
_PICK_LOCK = threading.Lock()


def pick_parse(text):
    """What the folder window said, from its one line of output. Pure."""
    line = ''
    for l in str(text or '').replace('\r', '\n').split('\n'):
        if l.strip():
            line = l.strip()
    if line.startswith('PICKED:') and line[7:].strip():
        return {'ok': True, 'path': line[7:].strip()}
    if line == 'CANCELLED':
        return {'ok': True, 'cancelled': True}
    if line.startswith('DRY:'):
        return {'ok': True, 'dry': True, 'start': line[4:].strip()}
    if line.startswith('FAILED:'):
        return {'ok': False, 'unavailable': True, 'reason': line[7:].strip() or 'the folder window failed'}
    return {'ok': False, 'unavailable': True, 'reason': 'the folder window gave no answer'}


def pick_folder(start=''):
    """Show the Windows folder window and wait for the answer. Never raises.
    {'ok', 'path'} | {'ok', 'cancelled'} | {'ok': False, 'unavailable'|'busy', 'reason'}"""
    fake = os.environ.get('STASYS_FAKE_PICK')
    if fake is not None:
        fake = fake.strip()
        if not fake or fake.lower() == 'cancel':
            return {'ok': True, 'cancelled': True}
        if fake.lower() == 'unavailable':
            return {'ok': False, 'unavailable': True, 'reason': 'not available here'}
        return {'ok': True, 'path': fake}
    if os.name != 'nt':
        return {'ok': False, 'unavailable': True, 'reason': 'the Windows folder window is only on Windows'}
    if not _PICK_LOCK.acquire(False):
        return {'ok': False, 'busy': True,
                'reason': 'The folder window is already open - look for it on the taskbar.'}
    try:
        import subprocess
        env = dict(os.environ)
        ok_start = isinstance(start, str) and is_abs_path(start) and os.path.isdir(start)
        env['STASYS_PICK_START'] = os.path.abspath(start) if ok_start else ''
        p = subprocess.run(['powershell.exe', '-NoProfile', '-NonInteractive', '-STA',
                            '-ExecutionPolicy', 'Bypass', '-EncodedCommand', PICK_FOLDER_B64],
                           capture_output=True, env=env, timeout=PICK_TIMEOUT,
                           creationflags=0x08000000)          # CREATE_NO_WINDOW: no console flash
        return pick_parse(p.stdout.decode('utf-8', 'replace'))
    except Exception as e:
        if e.__class__.__name__ == 'TimeoutExpired':
            return {'ok': True, 'cancelled': True}
        return {'ok': False, 'unavailable': True, 'reason': str(e)}
    finally:
        _PICK_LOCK.release()


def new_project_at(path):
    """Make the folder at `path` a project: the folder the person picked IS the project
    (v0.65). Its name is the project's name and the folder above it is the location."""
    p = str(path or '').strip()
    if not is_abs_path(p) or not os.path.isdir(p):
        return {'error': 'bad location', 'detail': 'That folder is not on this computer.'}
    p = os.path.abspath(p)
    parent, name = os.path.dirname(p), os.path.basename(p)
    if not name or parent == p:
        return {'error': 'bad location',
                'detail': 'That is a whole drive, not a folder. Pick (or make) a folder for the project.'}
    if _safe_folder(name) != name:
        return {'error': 'bad name',
                'detail': 'Stasys cannot use a folder called "%s". Rename it so it does not start with a '
                          'full stop, or end with a full stop or a space.' % name}
    return new_project(name, parent)


def is_stasys_project(folder):
    """Has this folder been set up as a Stasys project before? Read-only."""
    try:
        if not os.path.isdir(os.path.join(folder, '.tracker')):
            return False
        return os.path.isdir(sessions_dir_of(folder, read_config(folder)))
    except Exception:
        return False


# ---- scaffolding: set up a new project's structure (idempotent - only adds what's missing) ----
def _safe_folder(name):
    name = (name or '').strip()
    if not name:
        return None
    cleaned = re.sub(r'[<>:"/\\|?*\x00-\x1f]', '', name).strip().rstrip('. ')
    if not cleaned or '..' in cleaned or cleaned.startswith('.'):
        return None
    return cleaned

def _starter_session(name, today):
    return (
        "---\n"
        "last_modified: %s\n"
        "last_verified: %s\n"
        "---\n\n"
        "# Getting started — %s\n\n"
        "### v0.1\n\n"
        "> Starter entry created by Stasys. Files in Documentation/SESSIONS named like\n"
        "> `YYYY-MM-DD_vX.Y_slug.md` become points on the timeline. Edit or delete this and add your own.\n\n"
        "## What this is\n"
        "- Stasys builds the timeline from these session write-ups.\n"
        "- Add backlog items (the cards) directly in the board.\n"
        "- Delete this file once you have real sessions.\n"
    ) % (today, today, name)

def new_project(name, location=None):
    """Set up a project folder called `name` inside `location` - the projects folder when
    none is given, anywhere on the drive when one is (v0.65). Every refusal happens BEFORE
    anything is created, and carries a `detail` sentence the board shows as it stands."""
    folder = _safe_folder(name)
    if not folder:
        return {'error': 'bad name',
                'detail': 'That name cannot be used for a folder. Avoid < > : " / \\ | ? * and a leading full stop.'}
    root = os.path.abspath(ROOT)
    base = root
    if isinstance(location, str) and location.strip():
        loc = location.strip()
        if not is_abs_path(loc) or not os.path.isdir(loc):
            return {'error': 'bad location', 'detail': 'That location is not a folder on this computer.'}
        base = os.path.abspath(loc)
    proj = os.path.abspath(os.path.join(base, folder))
    if os.path.dirname(proj) != base:                    # no traversal out of the location
        return {'error': 'bad name', 'detail': 'That name cannot be used for a folder.'}
    outside = os.path.normcase(base) != os.path.normcase(root)
    if not outside and not os.path.isdir(proj):
        # a NEW folder in the projects folder would take the name away from a project
        # already listed from elsewhere (the folder that is there always wins)
        other = extra_project_dir(folder)
        if other:
            return {'error': 'name-taken',
                    'detail': 'A project called "%s" is already on your list (at %s). Stasys knows a project '
                              'by its folder name, so two cannot share one - choose another name.'
                              % (folder, os.path.abspath(other))}
    if outside:
        if not extras_enabled():
            return {'error': 'bad location',
                    'detail': 'This copy of Stasys is running on a fixed projects folder and cannot add projects from elsewhere.'}
        # A project is known by its folder's name, so the name has to be free.
        if os.path.isdir(os.path.join(root, folder)):
            return {'error': 'name-taken',
                    'detail': 'A folder called "%s" is already in your projects folder (%s). Stasys knows a '
                              'project by its folder name, so two cannot share one - choose another name.'
                              % (folder, root)}
        other = extra_project_dir(folder)
        if other and not _same_path(other, proj):
            return {'error': 'name-taken',
                    'detail': 'A project called "%s" is already on your list (at %s). Stasys knows a project '
                              'by its folder name, so two cannot share one - choose another name.'
                              % (folder, os.path.abspath(other))}
    tracker = os.path.join(proj, '.tracker')
    cfg_path = os.path.join(tracker, 'config.json')
    already = os.path.exists(cfg_path)
    sessions = os.path.join(proj, DEFAULT_SESSIONS_DIR)
    os.makedirs(sessions, exist_ok=True)
    os.makedirs(tracker, exist_ok=True)
    if not os.path.exists(cfg_path):   # never overwrite an existing config
        with open(cfg_path, 'w', encoding='utf-8') as f:
            json.dump({'name': name.strip(), 'tracks': ['F', 'O', 'P', 'U']}, f, indent=2)
    state_path = os.path.join(tracker, 'state.json')
    if not os.path.exists(state_path):
        with open(state_path, 'w', encoding='utf-8') as f:
            json.dump({'version': 1, 'items': []}, f, indent=2)
    try:
        has_md = any(fn.lower().endswith('.md') for fn in os.listdir(sessions))
    except Exception:
        has_md = False
    if not has_md:   # a starter entry so the timeline isn't bare (and self-documents the format)
        today = datetime.date.today().isoformat()
        with open(os.path.join(sessions, '%s_v0.1_getting-started.md' % today), 'w', encoding='utf-8') as f:
            f.write(_starter_session(name.strip(), today))
    try:
        connect_write(proj)   # the guide for Claude goes in with the rest (v0.64) - inside
    except Exception:         # .tracker/, best-effort, and never a reason to fail the scaffold
        pass
    if outside and not register_extra(proj):
        # The folder is set up (and setting it up again is harmless), but Stasys could not
        # remember where it is - say so rather than report a project that will not appear.
        return {'error': 'not-saved',
                'detail': 'The project folder is ready at %s, but Stasys could not save it to its list '
                          '(%s). Try again.' % (proj, _settings_path())}
    return {'ok': True, 'id': folder, 'name': name.strip(), 'alreadyExisted': already,
            'path': proj, 'outside': outside}


RE_SESSION_SORT = re.compile(r'^(\d{4}-\d{2}-\d{2})_v(\d+)[._](\d+)([a-z]?)', re.I)
def _session_fname_key(fname):
    """Order session files chronologically, then by NUMERIC version, so v0.10 sorts
    AFTER v0.9 (a plain string sort put 'v0.10' between 'v0.1' and 'v0.2', because the
    text '0.10' compares less than '0.2')."""
    m = RE_SESSION_SORT.match(fname)
    if not m:
        return (1, fname.lower(), 0, 0, '')
    return (0, m.group(1), int(m.group(2)), int(m.group(3)), (m.group(4) or '').lower())


def read_sessions(dirpath, cfg):
    sd = sessions_dir_of(dirpath, cfg)
    try:
        files = [f for f in os.listdir(sd) if f.lower().endswith('.md')]
    except Exception:
        return []
    files.sort(key=_session_fname_key)
    out = []
    for f in files:
        try:
            with open(os.path.join(sd, f), 'r', encoding='utf-8', errors='replace') as fh:
                out.append(parse_session(f, fh.read()))
        except Exception as e:
            out.append({'file': f, 'date': '', 'version': f, 'slug': f, 'title': f, 'track': 'F',
                        'summary': '', 'branch': '', 'commits': [], 'next': [], 'flag': None,
                        'rich': False, 'error': str(e)})
    return out


def _write_atomic(path, text):
    """Write via a temp file + os.replace so an interrupted write can never leave a
    truncated file behind. state.json IS the backlog - a half-written one reads as
    damage (and used to render as an empty board), so it's never written in place."""
    tmp = path + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as f:
        f.write(text)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, path)


# The revision a client must quote to save the whole backlog. NOT a field in state.json -
# it is computed from the file's own text every time it is read, so it costs no schema
# change (an older Stasys reads and writes the same file unchanged) and, unlike a counter,
# it cannot be fooled by a writer that edits the file without bumping anything.
REV_NONE = 'none'          # there is no state.json yet - a distinct value, never the empty string,
                           # so "I loaded a project with no backlog" is still something to compare


def _state_rev(text):
    """Revision token for a backlog file: a short hash of its text.

    Hashes the DECODED TEXT with newlines normalised, not the raw bytes, and that is
    deliberate. Python writes state.json through a text-mode handle, so on Windows it
    lands with CRLF; Node writes the same string with LF. Hashing bytes would give the
    two twins different revisions for a file whose content is identical - a spurious
    conflict on the first save after switching runtime. Same content, same rev, either
    twin."""
    return hashlib.sha256(text.replace('\r\n', '\n').encode('utf-8')).hexdigest()[:16]


def read_state(dirpath):
    """Read a project's backlog, telling 'legitimately empty' apart from 'damaged'.

    Returns (state, error). error is None on success - including a genuinely ABSENT
    state.json, which means a project with no backlog yet, not damage. When the file
    exists but can't be trusted (invalid JSON, truncated, wrong shape), state is None
    and error is a short human-readable reason.

    The returned state carries a 'rev' the file itself does not: see _state_rev. It is
    added on the way OUT and is never written back - write_state builds the saved object
    field by field, so state.json's shape is unchanged by this.

    Callers must NOT substitute an empty backlog on error. That was the old behaviour
    and it was silent data loss: an empty state renders as a blank board, then gets
    written straight over DEFERRED.md and state.json - indistinguishable from the real
    backlog having been deleted."""
    p = os.path.join(dirpath, '.tracker', 'state.json')
    if not os.path.exists(p):
        # no backlog yet - legitimately empty
        return {'version': 1, 'items': [], 'rev': REV_NONE}, None
    try:
        with open(p, 'r', encoding='utf-8') as f:
            raw = f.read()
    except Exception as e:
        return None, 'could not be opened (%s)' % e.__class__.__name__
    if not raw.strip():
        return None, 'is empty (0 bytes) - most likely truncated by an interrupted write'
    try:
        obj = json.loads(raw)
    except ValueError as e:
        return None, 'is not valid JSON (%s)' % e
    if not isinstance(obj, dict) or not isinstance(obj.get('items'), list):
        return None, "is valid JSON but not a backlog (no 'items' list)"
    obj['rev'] = _state_rev(raw)
    return obj, None


def state_error_body(dirpath, reason):
    """The body every endpoint returns when a project's state.json can't be trusted.
    Deliberately NOT an empty backlog: the board shows a read-only banner instead of a
    blank one, and no write path touches the file until it's fixed."""
    td = os.path.join(dirpath, '.tracker')
    bak = os.path.join(td, 'state.json.bak')
    return {'error': 'state-unreadable', 'detail': reason,
            'path': os.path.join(td, 'state.json'),
            'backup': bak if os.path.exists(bak) else ''}


# ---------------------------------------------------------------------------
# Rolling dated snapshots of state.json (v0.57, card #262).
#
# state.json.bak keeps the PREVIOUS SAVE. That answers "undo the last thing",
# and nothing else: the offsite backup is a robocopy /MIR mirror, so a card
# quietly emptied on Tuesday is mirrored over the good copy long before anyone
# looks, and "what did the board look like on the 4th?" has no answer at all.
# A mirror is not a history.
#
# So: one gzipped copy per project per DAY, kept in the project's own
# .tracker/snapshots/ - which means the existing nightly backup carries them
# offsite with no change to it at all, the developer's stated constraint.
SNAP_DIR = 'snapshots'
SNAP_RE = re.compile(r'^state-(\d{4}-\d{2}-\d{2})\.json\.gz$')
# The budget is the developer's constraint stated as the RULE, rather than a
# file count that has to be re-derived every time a project grows. Measured
# 2026-08-12: SpaceLogistics' state.json is 830 KB and gzips 2.7:1 to 319 KB
# (the card's 6:1 estimate was optimistic by more than double), so 2 MB buys
# it ~6 snapshots; Project_Tracker's own 47 KB file gzips to 17 KB, so the
# same budget buys it over a hundred and the age cap is what binds instead.
SNAP_BUDGET = 2 * 1024 * 1024
SNAP_KEEP_MIN = 3            # a budget is a target, never a licence to delete the last copies
SNAP_MAX_AGE_DAYS = 120      # the window ROLLS - nothing is kept for ever
# The newest few are never thinned. Coverage-thinning on its own spreads the survivors EVENLY,
# and measuring it on SpaceLogistics' real size showed why that is not good enough: 120 days at
# a 6-snapshot budget came out ~18 days apart, so recovering Tuesday's damage on the following
# Tuesday would have cost about nine days of legitimate work as well. The card names that
# latency - "nobody looked for a week" - as the thing to design for, and the recent end is
# where it is paid. Three exact steps back, then spread.
SNAP_KEEP_FRESH = 3


def _days_between(a, b):
    """Whole days from date string a to date string b (negative if b is earlier)."""
    try:
        da = datetime.date(int(a[0:4]), int(a[5:7]), int(a[8:10]))
        db = datetime.date(int(b[0:4]), int(b[5:7]), int(b[8:10]))
    except Exception:
        return 0
    return (db - da).days


def snap_plan(entries, today, budget=None, max_age=None, keep_min=None):
    """Decide which snapshots survive. PURE - no I/O, so this is the part the twins
    can be machine-diffed on (the compressed bytes cannot be: gzip headers differ
    between runtimes, and comparing them would prove nothing about the rule).

    `entries` is [{'date': 'YYYY-MM-DD', 'size': int}] in any order. Returns
    {'keep': [date...], 'drop': [date...]}, both oldest-first.

    Two rules, in order:

      1. Age out anything past `max_age`.
      2. While over budget, drop the snapshot whose loss costs the least COVERAGE -
         the interior one with the smallest gap between its neighbours - never
         touching the newest SNAP_KEEP_FRESH until there is nothing else to give.

    Rule 2 is the whole design. The obvious rule - drop the oldest - shrinks how far
    back you can reach every time the project grows, which is exactly backwards: the
    reach is the thing the mirror doesn't have. Thinning the middle instead keeps the
    oldest and the newest pinned, so a tightening budget costs you RESOLUTION and
    never REACH. Ten consecutive days at a 6-snapshot budget thin to days 1, 3, 5, 8,
    9, 10: full span, and the last three exact.

    Neither rule may take the pile below `keep_min`."""
    budget = SNAP_BUDGET if budget is None else budget
    max_age = SNAP_MAX_AGE_DAYS if max_age is None else max_age
    keep_min = SNAP_KEEP_MIN if keep_min is None else keep_min
    keep = sorted([dict(e) for e in entries], key=lambda e: e['date'])
    drop = []

    def cheapest(lo, hi):
        """The interior index in [lo, hi] whose neighbours sit closest together, or -1."""
        best_i, best_gap = -1, None
        for i in range(lo, hi + 1):
            gap = _days_between(keep[i - 1]['date'], keep[i + 1]['date'])
            if best_gap is None or gap < best_gap:   # first minimum wins, so a tie drops
                best_i, best_gap = i, gap            # the OLDER of two equally cheap days
        return best_i

    while len(keep) > keep_min and _days_between(keep[0]['date'], today) > max_age:
        drop.append(keep.pop(0))
    while len(keep) > keep_min and sum(_to_int(e['size']) for e in keep) > budget:
        n = len(keep)
        i = cheapest(1, min(n - 2, n - SNAP_KEEP_FRESH - 1))
        if i < 0:                       # nothing but the oldest and the fresh window is left,
            i = cheapest(1, n - 2)      # and still over budget: the window is not sacred
        if i < 0:
            break
        drop.append(keep.pop(i))
    drop.sort(key=lambda e: e['date'])
    return {'keep': [e['date'] for e in keep], 'drop': [e['date'] for e in drop]}


def snap_opts(cfg):
    """Per-project snapshot settings from .tracker/config.json, e.g.
    "snapshots": {"enabled": true, "budgetMB": 2}."""
    o = (cfg or {}).get('snapshots') if isinstance(cfg, dict) else None
    if o is False:
        return {'enabled': False, 'budget': SNAP_BUDGET}
    if not isinstance(o, dict):
        o = {}
    budget = o.get('budgetMB')
    try:
        budget = int(float(budget) * 1024 * 1024) if budget is not None else SNAP_BUDGET
    except Exception:
        budget = SNAP_BUDGET
    return {'enabled': o.get('enabled', True) is not False, 'budget': max(budget, 0)}


def snap_dir(dirpath):
    return os.path.join(dirpath, '.tracker', SNAP_DIR)


def snap_list(dirpath):
    """Every well-formed snapshot, oldest first: [{'date','file','size'}]. A file whose
    name doesn't match is ignored entirely - never listed, never counted, never pruned.
    It isn't ours, so it isn't ours to delete."""
    sd = snap_dir(dirpath)
    out = []
    try:
        names = os.listdir(sd)
    except Exception:
        return out
    for n in names:
        m = SNAP_RE.match(n)
        if not m:
            continue
        try:
            size = os.path.getsize(os.path.join(sd, n))
        except Exception:
            continue
        out.append({'date': m.group(1), 'file': n, 'size': size})
    out.sort(key=lambda e: e['date'])
    return out


def snap_read(dirpath, date):
    """The text of one snapshot, or None if it can't be read back."""
    p = os.path.join(snap_dir(dirpath), 'state-%s.json.gz' % date)
    try:
        with gzip.open(p, 'rb') as f:
            return f.read().decode('utf-8')
    except Exception:
        return None


def snap_prune(dirpath, budget=None):
    """Apply snap_plan to what's on disk. Returns the dates removed."""
    entries = snap_list(dirpath)
    plan = snap_plan(entries, _today(), budget)
    gone = []
    for e in entries:
        if e['date'] in plan['drop']:
            try:
                os.remove(os.path.join(snap_dir(dirpath), e['file']))
                gone.append(e['date'])
            except Exception:
                pass
    return gone


def snap_take(dirpath, prev_bytes):
    """Put the state.json we are about to replace aside, once a day. Returns the path
    written, or '' for any of the several good reasons not to.

    It snapshots the OLD bytes, not the new ones, and that is the point: the file
    lands under today's date holding the board as it stood BEFORE anything changed
    today. If today's first save is the one that eats a card, today's snapshot is
    already the copy from before it.

    Three things it refuses to do, all of them lessons from the 111-file .bak pile
    this replaces (three of which were not valid JSON, and nothing ever said so):
    it never snapshots a state.json it cannot parse, it never writes a snapshot it
    cannot immediately read back, and it never spends the budget on a second copy
    of a state it already holds."""
    if not (prev_bytes or b'').strip():
        return ''                                  # first ever save - nothing to put aside
    sd = snap_dir(dirpath)
    today = _today()
    dest = os.path.join(sd, 'state-%s.json.gz' % today)
    if os.path.exists(dest):
        return ''                                  # already have today's
    opts = snap_opts(read_config(dirpath))
    if not opts['enabled']:
        return ''
    try:
        text = prev_bytes.decode('utf-8')
        obj = json.loads(text)
    except Exception:
        return ''                                  # never snapshot damage
    if not isinstance(obj, dict) or not isinstance(obj.get('items'), list):
        return ''
    have = snap_list(dirpath)
    if have:
        newest = snap_read(dirpath, have[-1]['date'])
        if newest is not None and _state_rev(newest) == _state_rev(text):
            return ''                              # nothing has changed since the last one
    blob = gzip.compress(prev_bytes, 9, mtime=0)   # mtime=0 so the same content gzips the same
    try:                                           # a snapshot that can't be read back is not
        if gzip.decompress(blob) != prev_bytes:    # a snapshot - it's the .bak pile's mistake
            return ''
    except Exception:
        return ''
    os.makedirs(sd, exist_ok=True)
    tmp = dest + '.tmp'
    with open(tmp, 'wb') as f:
        f.write(blob)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, dest)
    snap_prune(dirpath, opts['budget'])
    return dest


def restore_snapshot(dirpath, date, tracks=None, order=None):
    """Put a dated snapshot back, through write_state - so DEFERRED.md is regenerated,
    every normaliser still runs, and the content being replaced lands in state.json.bak
    exactly as any other save. Returns (state, error).

    Note what this deliberately does NOT do: it does not restore the cards' `created` /
    `lastTouched` stamps over the live ones. write_state's rule is that for a card already
    on disk the disk value wins, and a restore is a content change like any other, so a
    card whose text comes back different is stamped as touched today. That is the honest
    reading - the card did just change."""
    text = snap_read(dirpath, date)
    if text is None:
        return None, 'no snapshot for %s' % date
    try:
        obj = json.loads(text)
    except ValueError as e:
        return None, 'snapshot for %s is not valid JSON (%s)' % (date, e)
    if not isinstance(obj, dict) or not isinstance(obj.get('items'), list):
        return None, "snapshot for %s is not a backlog (no 'items' list)" % date
    try:
        return write_state(dirpath, obj, tracks, order), None
    except FieldTooLong as e:
        return None, 'snapshot for %s: %s' % (date, e)


def _to_int(v):
    try:
        return int(v)
    except Exception:
        return 0


def _today():
    return datetime.date.today().isoformat()


def _clean_links(val, own_id):
    """Normalise a card's links: keep well-formed {to, type} entries, drop the rest,
    dedupe, cap. Lenient BY DESIGN - this also runs on the board's whole-file PUT,
    where refusing would leave the board unable to save at all; the strict checks
    live on the patch door (bad_links), the same split track/status got in v0.44.
    A link to an id that no longer exists is KEPT: pruning it here would silently
    destroy data, and a dangling link is the board's to report, not ours to eat."""
    out = []
    seen = set()
    for e in (val if isinstance(val, list) else []):
        if len(out) >= LINKS_MAX:
            break
        if not isinstance(e, dict):
            continue
        to = _to_int(e.get('to'))
        t = e.get('type')
        if to <= 0 or to == own_id or not (isinstance(t, str) and t in LINK_TYPES):
            continue
        if (to, t) in seen:
            continue
        seen.add((to, t))
        out.append({'to': to, 'type': t})
    return out


def _touch_sig(it, links):
    """The parts of a card that count as CONTENT for the lastTouched stamp.
    Deliberately absent: list position (dragging a card around must not make stale
    work look fresh), the stamps themselves, and resumeAt (a stamp that counted as
    content would re-stamp forever). `links` is passed in already-cleaned so both
    sides of the comparison see one canonical form."""
    return json.dumps([
        str(it.get('title') or ''), str(it.get('track') or ''),
        str(it.get('status') or ''), str(it.get('writeup') or ''),
        bool(it.get('flag')), bool(it.get('parked')),
        str(it.get('resume') or ''), str(it.get('resumeRef') or ''),
        str(it.get('doneVersion') or ''), str(it.get('doneDate') or ''),
        links,
    ])


def _date_only(s):
    """`YYYY-MM-DD` out of either form the field has held. The board stamped a plain date,
    but two notes on a live board carry a full ISO timestamp from a hand-written splice.
    Both parse, so nothing was broken - but one field holding two formats is a comparison
    waiting to go wrong, and the note's *second* was never meaningful."""
    s = str(s or '').strip()[:RESUME_AT_MAX]
    if len(s) > 10 and s[4] == '-' and s[7] == '-' and s[:10].replace('-', '').isdigit():
        return s[:10]
    return s


def _stamp_resume_at(it, prev, resume, resume_ref):
    """The resume note's date - STAMPED here from v0.56, not typed.

    It used to be written by board.html's drawer and by nothing else, so a note written
    through the patch door carried no date at all - and an undated note rendered as
    SILENCE rather than as a warning: no age chip, and a staleness test of
    `(age || 0) >= 14` that an undated note can never fail, so it read slightly *cleaner*
    than one written today. 23 of the 40 notes on a live board were in that state. Same
    principle as `created`/`lastTouched`: a date that depends on someone remembering it is
    missing on exactly the cards that matter.

    It is deliberately NOT in STAMPED_FIELDS - the board's own whole-file PUT sends this
    field, and write_state serves that path too, so refusing it at the door would break the
    ordinary save. Stamping *here* covers both doors at once, which is the whole point.

    Nothing is ever back-filled: an old note that arrives undated and unchanged stays
    undated, because unknown must read as unknown. And resumeAt stays out of `_touch_sig`
    (a stamp that counted as content would re-stamp forever)."""
    at = _date_only(it.get('resumeAt'))
    if not resume:
        return ''                     # no note, no date - the stamp describes prose that isn't there
    prev = prev or {}
    prev_at = _date_only(prev.get('resumeAt'))
    if (resume, resume_ref) != (str(prev.get('resume') or ''), str(prev.get('resumeRef') or '')):
        # The note moved. An explicitly supplied NEW date is a deliberate backfill and is
        # kept (that is what lets a restored history stay true); an empty one, or a mere
        # echo of what was already there, means the writer didn't set it - so today is it.
        return at if (at and at != prev_at) else _today()
    return at or prev_at              # unchanged note keeps its date; an empty echo can't clear one


# ---- the in-progress marker (v0.58): which ONE card is being worked on right now ----
#
# Deliberately NOT a field in state.json. "Who is at the desk right now" is not board
# content: it must never bump the rev, never land in a snapshot, never appear in
# DEFERRED.md, and never be dragged through the board's three-way merge. It lives in its
# own .tracker/active.json - and because that file holds ONE id, "only one card is
# highlighted at a time" is STRUCTURAL rather than a rule somebody has to remember to
# enforce on every write path.
#
# TWO FACTS, KEPT SEPARATE, because conflating them was the first design of this feature
# and it was wrong:
#
#   the CLAIM   which card is in play. PERSISTENT, and it deliberately does NOT expire.
#               A card claimed last night is still the card you are on when you sit down
#               in the morning, so an ageing-out claim would delete the answer at exactly
#               the moment the question finally gets asked. It is released by events that
#               actually mean the work stopped - see active_sync - never by the clock.
#
#   LIVENESS    whether a Claude session is running THIS SECOND. Ephemeral, heartbeated by
#               the session hooks (hooks/stasys_session.py), and stale after
#               ACTIVE_LIVE_MS with no beat.
#
# The board draws the claim as a gold border and liveness as a pulse on it. So a session
# that dies without ever reaching SessionEnd stops pulsing within the half hour, while the
# claim - which is still perfectly true - survives it. That split is the whole design.
ACTIVE_LIVE_MS = 30 * 60 * 1000


def _now_ms():
    return int(time.time() * 1000)


def active_path(dirpath):
    return os.path.join(dirpath, '.tracker', 'active.json')


def read_active(dirpath):
    """The raw marker, or {} when there isn't one. Never raises: a missing or damaged
    marker means 'nothing is claimed', which is the honest answer and also the safe one -
    unlike state.json, there is nothing here to lose, so refusing to read is pointless."""
    try:
        with open(active_path(dirpath), 'r', encoding='utf-8') as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}


def write_active(dirpath, d):
    try:
        os.makedirs(os.path.join(dirpath, '.tracker'), exist_ok=True)
        _write_atomic(active_path(dirpath), json.dumps(d, indent=2, ensure_ascii=False))
        return True
    except Exception:
        return False


def active_state(raw, now_ms, window_ms=None):
    """PURE, and the only machine-checkable part of this feature - everything else is a
    file and a clock. Given the raw marker and the current time, this is what the board
    should draw. Times are stored as epoch MILLISECONDS and nothing else: an ISO string
    beside them would be a second source of truth for the same instant, and the twins
    would have to agree on formatting as well as on arithmetic."""
    if window_ms is None:
        window_ms = ACTIVE_LIVE_MS
    d = raw if isinstance(raw, dict) else {}
    cid = _to_int(d.get('id'))
    live = d.get('live') if isinstance(d.get('live'), dict) else {}
    seen = _to_int(live.get('at'))
    # `ever` is the beat that is NEVER cleared, and it is what separates "this project has no
    # hook" from "this project's session ended". SessionEnd deliberately wipes `at` so the pulse
    # stops at once - and wiping the only evidence a beat ever arrived would have made a
    # correctly-installed project read as an uninstalled one the moment its session closed,
    # advising an install that is already done. Found by installing the hook on SpaceLogistics
    # and ending the session: the same class of misreport this whole version exists to remove.
    ever = _to_int(live.get('ever')) or seen
    since = _to_int(d.get('since'))
    # A beat from the FUTURE is a clock change, not a live session. Clamping both
    # directions matters: a machine whose clock jumps forward once would otherwise pin the
    # pulse on permanently, and a pulse that cannot go out is exactly the lie this feature
    # is built to avoid.
    fresh = bool(seen) and abs(now_ms - seen) < window_ms
    # THREE liveness states, not two (v0.59). `live: False` used to answer both "a session was
    # here and has gone quiet" and "no session has EVER reported on this project" - and the
    # second is not idleness, it is an uninstalled hook. Folding them together made a missing
    # signal render as a healthy one, which is exactly the v0.56 resume-note fault; it recurred
    # here within a day of that lesson being written down. `live`/`sessionLive` are kept as they
    # were so nothing that reads them breaks; `pulse` is the field that can tell the difference.
    pulse = 'never' if not ever else ('live' if fresh else 'idle')
    return {
        'id': cid or None,
        'since': since,
        'heldMs': (now_ms - since) if (cid and since and now_ms > since) else 0,
        'by': str(d.get('by') or ''),
        'note': str(d.get('note') or ''),
        'live': bool(cid) and fresh,      # a claimed card with a beating session: pulse it
        'sessionLive': fresh,             # a session is running, claimed or not
        'pulse': pulse,                   # 'live' | 'idle' | 'never' - see above
        'lastSeen': seen,
        'everSeen': ever,
        'idleMs': (now_ms - seen) if (seen and now_ms > seen) else 0,
        'session': str(live.get('session') or ''),
        'windowMs': window_ms,
        'released': str(d.get('released') or ''),
    }


def active_view(dirpath):
    return active_state(read_active(dirpath), _now_ms())


def active_sync(dirpath, state):
    """Release the claim when its card stops being work in progress. Called from
    write_state, which is the ONLY place a card's status can change - so this is the one
    place the rule has to live, and it cannot be bypassed by a door that forgets it.

    The four releases, and why each one is a release rather than an expiry:
      done / cut  the work finished. This is the handoff case: a session record's
                  `completes:` line closes the card, and the marker goes out on its own
                  with nobody having to remember a second step.
      parked      parked means SET DOWN and claimed means PICKED UP; they are the two ends
                  of one axis, so a card cannot honestly be both.
      deleted     nothing left to point at.
    Liveness is deliberately NOT touched here: a session is still running even at the
    moment the card it was on closes."""
    a = read_active(dirpath)
    cid = _to_int(a.get('id'))
    if not cid:
        return None
    it = None
    for x in (state.get('items') or []):
        if isinstance(x, dict) and _to_int(x.get('id')) == cid:
            it = x
            break
    if it is None:
        why = 'deleted'
    elif it.get('status') in ('done', 'cut'):
        why = it.get('status')
    elif it.get('parked'):
        why = 'parked'
    else:
        return None
    a['id'] = None
    a['released'] = why
    a['releasedAt'] = _now_ms()
    write_active(dirpath, a)
    return why


def set_active(dirpath, card_id, by='', note='', tracks=None, order=None):
    """Claim one card, or release with card_id None/0. Returns (view, error).

    Claiming a PARKED card un-parks it, through the ordinary patch door so every
    invariant still runs. Refusing would have been the timid choice and the wrong one:
    park and claim are opposite ends of the same axis, and coming back to something you
    set down is the single most likely reason to claim it at all."""
    st, err = read_state(dirpath)
    if err:
        return None, 'cannot read the backlog: ' + str(err)
    cid = _to_int(card_id)
    if not cid:
        a = read_active(dirpath)
        a['id'] = None
        a['released'] = 'released'
        a['releasedAt'] = _now_ms()
        write_active(dirpath, a)
        return active_view(dirpath), None
    it = None
    for x in (st.get('items') or []):
        if isinstance(x, dict) and _to_int(x.get('id')) == cid:
            it = x
            break
    if it is None:
        return None, 'no card #%d on this board' % cid
    if it.get('status') in ('done', 'cut'):
        return None, ('card #%d is %s - a finished card is not work in progress'
                      % (cid, it.get('status')))
    if it.get('parked'):
        # Un-park through apply_state_patch, not by hand: same merge core, same caps, same
        # DEFERRED.md regeneration. The resume note is never deleted - it stays as history.
        try:
            _res, perr, _code = apply_state_patch(
                dirpath, [{'op': 'set', 'id': cid, 'fields': {'parked': False}}], tracks, order)
            if perr:
                return None, 'could not un-park card #%d: %s' % (cid, perr)
        except Exception as e:
            return None, 'could not un-park card #%d: %s' % (cid, e)
    a = read_active(dirpath)
    prev = _to_int(a.get('id'))
    if prev != cid:
        a['since'] = _now_ms()            # a re-claim of the SAME card keeps its original
        a['note'] = ''                    # start time, so "held 3h" doesn't reset on a beat
    a['id'] = cid
    a['by'] = str(by or 'claude')
    if note:
        a['note'] = str(note)[:200]
    a['released'] = ''
    write_active(dirpath, a)
    return active_view(dirpath), None


def touch_session(dirpath, event, session_id=''):
    """The liveness half, driven by the Claude Code session hooks. It touches ONLY the
    `live` block and never the claim - which is what makes a session ending harmless to
    the thing you actually want to see in the morning."""
    a = read_active(dirpath)
    live = a.get('live') if isinstance(a.get('live'), dict) else {}
    ev = (event or '').lower()
    if ev == 'end':
        # Only the session that owns the marker may clear it. Two sessions open on one
        # project is rare, but the first one exiting should not blank the second's pulse.
        if session_id and live.get('session') and live.get('session') != session_id:
            return active_view(dirpath)
        # `ever` survives, so the board can still tell an ended session from a hook that was
        # never installed. Everything else goes, so the pulse stops at once.
        a['live'] = {'ever': _to_int(live.get('ever')) or _to_int(live.get('at')) or _now_ms()}
    else:
        if ev == 'start' or not live.get('session') or live.get('session') != session_id:
            live = {'session': str(session_id or ''), 'startedAt': _now_ms(),
                    'ever': _to_int(live.get('ever'))}
        live['at'] = _now_ms()
        live['ever'] = _to_int(live.get('ever')) or live['at']
        a['live'] = live
    write_active(dirpath, a)
    return active_view(dirpath)


def write_state(dirpath, incoming, tracks=None, order=None):
    if not tracks:
        tracks = TRACKS
    if not order:
        order = TRACK_ORDER
    td = os.path.join(dirpath, '.tracker')
    os.makedirs(td, exist_ok=True)
    clean = {'version': 1, 'updated': datetime.datetime.now().isoformat(), 'items': []}
    items_in = incoming.get('items') if isinstance(incoming, dict) else None
    # nextId is a MONOTONIC id allocator persisted beside the items. Ids used to be
    # handed out as max(live ids)+1, which recycles a number as soon as the highest
    # card is deleted - fine while ids were invisible, wrong now that the board prints
    # them and session records cite them (a reused #25 would name two different items).
    # It only ever moves forward: never below the highest id present, and never below
    # whatever a previous save already reserved, so a deleted number is retired for good.
    next_id = _to_int(incoming.get('nextId')) if isinstance(incoming, dict) else 0
    # Floor it against what's already on disk, so the counter can't be walked backwards by a
    # client that doesn't send one (a stale browser tab, or a board older than this version).
    # The on-disk items matter too: a legacy state.json has no nextId, so deleting its highest
    # card and saving would otherwise recycle that number on the very first write.
    disk, _derr = read_state(dirpath)
    disk_by_id = {}       # the prior save's card by id - the anchor for the v0.45 stamps
    if isinstance(disk, dict):
        next_id = max(next_id, _to_int(disk.get('nextId')))
        for it in (disk.get('items') or []):
            next_id = max(next_id, _to_int((it or {}).get('id')) + 1)
            if isinstance(it, dict):
                disk_by_id[_to_int(it.get('id'))] = it
    if isinstance(items_in, list):
        used = set()
        max_id = 0
        for it in items_in:
            n = _to_int((it or {}).get('id'))
            if n > 0:
                max_id = max(max_id, n)
        next_id = max(next_id, max_id + 1)
        max_id = next_id - 1          # backfilled ids come from the allocator too
        for it in items_in:
            it = it or {}
            iid = _to_int(it.get('id'))
            if iid <= 0 or iid in used:
                max_id += 1
                iid = max_id
            used.add(iid)
            # Refuse, never cut (v0.62). Raised before a byte is written - the write happens
            # only after this loop - so a refused save leaves the file exactly as it was.
            ov = field_overflow(it, disk_by_id.get(iid))
            if ov:
                raise FieldTooLong(iid, ov)
            track = it.get('track') if it.get('track') in tracks else order[0]
            status = it.get('status') if it.get('status') in CARD_STATUSES else 'table'
            # `parked` sits ALONGSIDE status, the way `flag` does - it is not a fifth
            # lane. A parked card keeps its place in the table ordering (so it is still
            # what "let's continue" picks); it just says out loud that it was set down
            # mid-flight and that its resume note is the place to look.
            # Only a live card can be parked. Clearing it on done/cut is the backstop
            # for the failure this whole field exists to avoid: a state nobody clears
            # becomes a lie, and a "parked" Done card would make the parked count -
            # the one number you're meant to trust at a glance - meaningless.
            parked = bool(it.get('parked')) and status in ('table', 'air')
            clean_item = {
                'id': iid,
                'title': str(it.get('title') or ''),
                'track': track,
                'status': status,
                'writeup': str(it.get('writeup') or ''),
                'flag': bool(it.get('flag')),
                'parked': parked,
            }
            # The note itself is NEVER dropped, on any status - it is the writer's prose
            # and it stays readable as history after the card closes. Only the boolean
            # is cleared above. `parked` is written on every item (it mirrors `flag`,
            # which has always been); the three string fields are omitted when empty,
            # the way doneVersion/doneDate already are, so a card that never uses them
            # gains nothing but the one boolean.
            prev = disk_by_id.get(iid)    # the prior save's copy - the anchor for every stamp below
            resume = str(it.get('resume') or '')
            resume_ref = str(it.get('resumeRef') or '')
            resume_at = _stamp_resume_at(it, prev, resume, resume_ref)
            if resume:
                clean_item['resume'] = resume
            if resume_ref:
                clean_item['resumeRef'] = resume_ref
            if resume_at:
                clean_item['resumeAt'] = resume_at
            if status == 'done':
                clean_item['doneVersion'] = str(it.get('doneVersion') or '')[:40]
                clean_item['doneDate'] = str(it.get('doneDate') or '')[:20]
            # ---- lineage (v0.45): links + the two stamps ----
            prev_links = _clean_links(prev.get('links'), iid) if prev is not None else []
            # An ABSENT links key means an older client that doesn't know the field -
            # preserve what's on disk rather than letting its save wipe lineage. A
            # present-but-empty list is a current client clearing them, which is honoured.
            links = _clean_links(it.get('links'), iid) if 'links' in it else prev_links
            if links:
                clean_item['links'] = links
            # The stamps are SERVER-owned. For a card already on disk the DISK value wins
            # (a client echo can be stale, and an empty echo must never clear a stamp); a
            # client-supplied value is honoured only on a card new to this file, which is
            # what lets a restored backup keep its history. A card new to disk with no
            # dates is being born right now - stamp it, whichever door it came through.
            if prev is not None:
                created = str(prev.get('created') or '')[:20]
                touched = str(prev.get('lastTouched') or '')[:20]
                if _touch_sig(clean_item, links) != _touch_sig(prev, prev_links):
                    touched = _today()
            else:
                created = str(it.get('created') or '')[:20] or _today()
                touched = str(it.get('lastTouched') or '')[:20] or _today()
            if created:
                clean_item['created'] = created
            if touched:
                clean_item['lastTouched'] = touched
            clean['items'].append(clean_item)
        next_id = max(next_id, max_id + 1)
    clean['nextId'] = max(next_id, 1)
    sp = os.path.join(td, 'state.json')
    try:                                  # the bytes we're about to replace, for the .bak
        with open(sp, 'rb') as f:
            prev = f.read()
    except Exception:
        prev = b''
    try:                                  # ...and, once a day, the same bytes kept dated
        snap_take(dirpath, prev)          # (v0.57). Best-effort by design: a snapshot is a
    except Exception:                     # safety net, and a safety net that can break the
        pass                              # save it protects is a worse bug than having none.
    text = json.dumps(clean, indent=2, ensure_ascii=False)
    _write_atomic(sp, text)
    # The rev of what we just wrote, handed back so a caller that saved can quote it on its
    # NEXT save without re-reading. Set after the write and never before: a rev is a claim
    # about what is on disk. It goes on the returned object only - not into the file.
    clean['rev'] = _state_rev(text)
    if prev.strip():                      # keep the previous save one step behind, so a bad
        try:                              # state.json is always recoverable by hand
            with open(sp + '.bak', 'wb') as f:
                f.write(prev)
        except Exception:
            pass
    # render BEFORE opening the target: a render that raised mid-write used to leave a
    # truncated (or empty) DEFERRED.md behind, which is the same data loss one step down.
    md = render_deferred(os.path.basename(dirpath), clean, tracks)
    _write_atomic(os.path.join(td, 'DEFERRED.md'), md)
    # The in-progress claim goes out when its card does (v0.58). Best-effort and wrapped,
    # for the same reason snap_take is: a marker that can break the save it annotates is a
    # far worse bug than a marker that occasionally lingers a poll longer than it should.
    try:
        active_sync(dirpath, clean)
    except Exception:
        pass
    return clean


# Fields a patch may set on a card. Deliberately NOT `id` - an id is the one thing a
# caller must never rewrite, because session records cite it (see the v0.36 note above).
PATCH_FIELDS = ('title', 'track', 'status', 'writeup', 'flag', 'parked',
                'resume', 'resumeRef', 'resumeAt', 'doneVersion', 'doneDate', 'links')
PATCH_MAX_OPS = 200
# The four lanes a card can be in. One tuple, used by write_state's normaliser, by the
# patch door's validator, and by the help - so the three cannot disagree about what a
# valid status is.
CARD_STATUSES = ('table', 'air', 'done', 'cut')
# The three relationships a link can carry (v0.45), and no more. Each type feeds a
# different view (blocks -> order, derives-from -> threads, part-of -> grouping); a
# vague fourth ("relates-to") answers no question, feeds no view, and becomes the
# drawer everything gets tipped into - at which point the graph stops meaning anything.
LINK_TYPES = ('blocks', 'derives-from', 'part-of')
LINKS_MAX = 100        # runaway guard per card (a client bug), not a design limit
# Stamped by the server, never typed: `created` the day a card is born, `lastTouched`
# the last day its content changed. A set/add naming either is refused - a date that
# depends on someone filling it in is missing on exactly the cards that matter.
STAMPED_FIELDS = ('created', 'lastTouched')


def patch_help():
    """The patch contract, as data, served at GET /api/help (v0.43).

    Why this exists: on 2026-08-07 a session in another project spent a whole sitting
    concluding the `add` op did not exist - it had shipped in v0.40 - and fell back to
    handing card text to the developer by hand. Two things caused it and both are
    addressed here. It could not ASK (there was no discovery endpoint of any kind), and
    it could not READ THE ANSWER (its HTTP client discarded 4xx bodies, so the `detail`
    string that would have corrected it in one attempt never reached it).

    DERIVED from PATCH_FIELDS / PATCH_MAX_OPS rather than retyped, and machine-checked
    against the Node twin, because a help text that drifts from the parser is worse than
    no help text at all: it converts a caller who would have experimented into one who is
    confidently wrong. For the same reason it documents the COERCIONS below rather than
    only the happy path - `track` and `status` are silently normalised by write_state, so
    a typo there is accepted and quietly changed, which is exactly the kind of thing a
    caller has no way to discover by trying."""
    return {
        'name': APP_NAME,
        'version': APP_VERSION,
        'endpoint': '/api/state/patch?project=<id>',
        'methods': ['POST', 'PUT'],
        'body': '{"ops": [...]} - a bare array, or one bare op object, is also accepted',
        'allOrNothing': 'if any op fails, NOTHING is written; naming a card that does not '
                        'exist is a 409 error, never a silent no-op',
        'maxOps': PATCH_MAX_OPS,
        'fields': list(PATCH_FIELDS),
        'fieldsRefused': ['id'] + list(STAMPED_FIELDS),
        'limits': dict(FIELD_LIMITS, unit='characters (Unicode code points - an emoji is one)',
                       overLimit='REFUSED, never cut: the whole patch fails, naming the op, the '
                                 'card, the field, its length and the limit'),
        'stamped': {
            'created': 'the day the card was born - stamped on add, through either door',
            'lastTouched': "the last day the card's CONTENT changed - stamped on any "
                           'change; reordering alone does not count',
            'note': 'server-owned: a set/add naming either is refused, and a stale or '
                    'empty client copy can never clear one',
        },
        'links': {
            'shape': [{'to': 250, 'type': 'blocks'}],
            'types': list(LINK_TYPES),
            'meaning': 'THIS <type> TO - blocks: `to` cannot start until this card is '
                       'done; derives-from: this card exists because of `to`; part-of: '
                       'this card is a slice of `to`',
            'onSet': "a `set` REPLACES the card's whole links list - read it, edit it, "
                     'send it back',
            'refused': 'not-a-list, a link to a missing card, a self-link, an unknown '
                       'type, a duplicate, more than %d - all 400, naming links[index]'
                       % LINKS_MAX,
        },
        'ops': [
            {'op': 'add', 'takes': 'item', 'required': ['title'], 'optional': ['before'],
             'note': 'the SERVER allocates the id - never send one. It is returned in '
                     '`applied`. `before` inserts ahead of that card instead of appending.',
             'example': {'op': 'add', 'item': {'title': 'New card', 'status': 'table'}}},
            {'op': 'set', 'takes': 'fields', 'required': ['id', 'fields'], 'optional': [],
             'note': 'changes the named fields on one existing card; others are untouched',
             'example': {'op': 'set', 'id': 12, 'fields': {'writeup': 'text'}}},
            {'op': 'move', 'takes': None, 'required': ['id'], 'optional': ['before'],
             'note': 'list order IS priority on the board; omit `before` to send to the end',
             'example': {'op': 'move', 'id': 12, 'before': 5}},
            {'op': 'delete', 'takes': None, 'required': ['id'], 'optional': [],
             'note': 'prefer setting status to "cut" - a cut card stays readable as history',
             'example': {'op': 'delete', 'id': 12}},
        ],
        'statusValues': list(CARD_STATUSES),
        'trackValues': "this project's declared lanes - GET /api/sessions?project=<id> "
                       'returns them as `order`',
        'defaultsOnAdd': {
            'track': "the project's FIRST DECLARED lane (see /api/sessions?project=<id>)",
            'status': 'table', 'writeup': '', 'flag': False, 'parked': False,
            'created': 'today (stamped)', 'lastTouched': 'today (stamped)',
        },
        'rejects': [
            'an unrecognised `status` - 400, naming the op index (see statusValues)',
            'an unrecognised `track` - 400, naming the op index (see trackValues)',
            'an unknown field name - 400 (see fields)',
            'a new card with no title - 400',
            'any op naming a card that does not exist - 409',
            'a malformed `links` value - 400, naming links[index] (see links)',
            'setting `created` or `lastTouched` - 400, they are stamped (see stamped)',
            'a text field over its limit - 400, naming the op, card, field, length and limit '
            '(see limits)',
        ],
        'coercions': [
            '`parked` is forced false on a done/cut card (the `resume` note is kept)',
        ],
        'response': {
            'ok': True,
            'applied': [{'op': 'add', 'id': 240, 'title': 'New card'}],
            'note': '`applied` is in op order - a new card\'s allocated id is here',
        },
        'errors': {
            'shape': {'error': 'patch-rejected', 'detail': 'op 1: <what was wrong>'},
            'note': 'every rejection names the op index and the fault. READ THE RESPONSE '
                    "BODY. PowerShell 5.1's Invoke-WebRequest/Invoke-RestMethod throw on "
                    'any non-2xx and DRAIN the body into $_.ErrorDetails.Message - the '
                    'response stream is empty by then, so GetResponseStream() gives you '
                    'nothing. Use $_.ErrorDetails.Message (already a decoded string), or '
                    'use curl.',
            'powershell': 'catch { $_.ErrorDetails.Message }',
            # NOT keyed '400'/'403'/'409': JSON.stringify hoists integer-like keys to the
            # front of the object, so numeric names would emit in a different ORDER on the
            # Node twin for no behavioural reason - and make a byte-comparison useless.
            'code400': 'malformed or unknown op, unknown field, missing title, empty batch, '
                       'a field over its limit',
            'code403': 'cross-origin write rejected (the origin guard)',
            'code409': 'named a card that does not exist, or state.json could not be read',
        },
        'offline': 'py server.py --patch <project> ops.json   '
                   '(omit the file to read the ops on stdin) - same merge core, '
                   'for when Stasys is not running',
        'neverHandEdit': '.tracker/state.json has two writers (the board and you). The '
                         'board saves the WHOLE file, so a hand-edit is wiped by its next '
                         'save and yours wipes whatever was typed. Always use this door.',
        # The in-progress marker (v0.58) is NOT a patch op and is not in state.json at all -
        # it is described here because this is the endpoint a session is proven to read, and
        # a capability nobody can discover is one that gets reinvented. windowMs is taken
        # from the shipped constant: a retyped number here would describe an engine that
        # isn't there, which is the one thing this payload must never do.
        'inProgress': {
            'what': 'which ONE card is being worked on right now. The board draws it as a '
                    'gold ring on the card, on the thread map and on the lineage timeline.',
            'where': '.tracker/active.json - deliberately NOT state.json, so it never moves '
                     'the rev, never lands in a snapshot and never enters DEFERRED.md',
            'claim': 'POST /api/active?project=<id>  {"id": 14}   (or {"id": null} to release)',
            'offline': 'py server.py --active <project> 14   ·   ... <project> none',
            'read': 'GET /api/active?project=<id>',
            'onlyOne': 'the file holds a single id, so claiming a card releases whatever '
                       'held it - "one at a time" is structural, not a rule to remember',
            'released': 'automatically when the card goes done/cut, is parked, or is '
                        'deleted. NEVER on a timer: a card claimed last night is still the '
                        'card you are on in the morning.',
            'claimUnparks': 'claiming a parked card un-parks it (park and claim are '
                            'opposite ends of one axis). The resume note is kept.',
            'liveness': 'separate and ephemeral - the Claude Code session hooks beat '
                        'POST /api/active {"session": "<id>", "event": "start|beat|end"} '
                        '(or py server.py --session <project> start|beat|end <id>), and the '
                        'board pulses the ring while a beat is fresher than windowMs. A '
                        'session that dies stops pulsing; its claim survives.',
            'pulse': "'live' (a beat inside windowMs) | 'idle' (beaten before, quiet now) | "
                     "'never' (NO beat has ever arrived - the session hook is not installed "
                     'for this project, so the pulse can never appear). Never is not idle, and '
                     'a caller that treats them alike reports a missing signal as a healthy one.',
            'windowMs': ACTIVE_LIVE_MS,
            'rejects': [
                'claiming a done or cut card - 409, a finished card is not work in progress',
                'claiming a card that does not exist - 409, naming the id',
            ],
        },
        # The board merge (v0.63) is not a patch op either. It is described here for the
        # reason inProgress is: this is the page a caller is proven to read, and a door
        # nobody can discover is a door that gets rebuilt somewhere else. The text is
        # written ONCE and generated into both twins - never edit one copy by hand.
        'boardMerge': {
            'what': 'merges two copies of ONE board that were changed on two machines, card by card - for a board kept in a shared repository and used with no host PC switched on. Not a patch op and not an HTTP endpoint: a command, run with the app shut.',
            'command': '--merge <base.json> <mine.json> <theirs.json> [--out <merged.json>]   (py server.py ..., or node server.js ...)',
            'files': 'three WHOLE state.json files. BASE = the last version both copies agreed on, MINE = this copy, THEIRS = the copy already published.',
            'writes': "only --out (whole and atomically). It never touches a project .tracker/ by itself - where the result goes is the caller's decision. With no --out it is a dry run: the report, and nothing written.",
            'rule': "the board's own three-way merge: a card one side did not touch takes the other side's version; an EDIT always beats a DELETE, both ways; order follows THEIRS unless MINE reordered, and a card the leading list has never seen goes just above the card it sat above in its own list.",
            'bothChanged': 'a card BOTH sides changed is merged field by field (links as a set). Only the same field changed to two different values is a clash: the side whose card has the newer `lastTouched` wins it, and THEIRS wins a tie or dates that cannot be compared. Every clash is in the report with both values.',
            'sameNumber': "two NEW cards given the same id on two machines: THEIRS keeps the number, MINE's card takes a fresh one above every id ever used, links MINE wrote to it are rewritten, and `renumbered` lists from / to / title and the cards whose prose still says the old number (prose is never rewritten).",
            'report': 'printed as JSON: ok, written, out, rev, counts, nextId, order, tookTheirs, keptMine, bothChanged, clashes, revived, deleted, renumbered',
            'exit': '0 = merged · 1 = refused, nothing written · 2 = bad invocation',
            'refuses': [
                'a file that is missing, empty, or not valid JSON',
                'a board with the same id twice, an unknown status, or a card with no track',
                'a card or board carrying an entry this engine does not know - it was saved by a NEWER Stasys, and merging it here would drop that entry without a word',
                'a value of the wrong kind (an id that is not a whole number, a title that is not text, a link the engine cannot read)',
            ],
            'notHere': '.tracker/active.json - who is at the desk is per machine and is not board content. The caller decides what to do with it, using `renumbered`.',
        },
    }


def apply_state_patch(dirpath, ops, tracks=None, order=None):
    """Apply one-card edits on top of whatever is CURRENTLY on disk, then save.

    This is the merge point that makes two writers safe. PUT /api/state sends the WHOLE
    backlog, so whoever saves last wins the entire file and the other side's work vanishes
    with no warning - true whether the other writer is the board, a second tab, or an agent
    editing state.json by hand. A patch says "set #209's resume note" instead, so two
    writers touching DIFFERENT cards can never collide: neither one ever sends, or
    overwrites, the other's card.

    Ops, applied in order and ALL-OR-NOTHING (nothing is written unless every op lands):
      {"op": "set",    "id": N, "fields": {...}}       change named fields on one card
      {"op": "add",    "item": {...} [, "before": N]}  new card, appended or inserted
      {"op": "delete", "id": N}                        remove one card
      {"op": "move",   "id": N [, "before": N]}        reorder (before a card, or to the end)

    Returns (result, error, http_code). An op naming a card that isn't there is an ERROR,
    never a silent no-op: a write that quietly does nothing is the exact failure this
    whole path exists to remove.

    The save itself still goes through write_state, so every existing invariant applies
    unchanged - the parked-only-when-live backstop, the length refusal, monotonic ids, the
    .bak, and the DEFERRED.md regeneration."""
    if isinstance(ops, dict):
        ops = [ops]
    if not isinstance(ops, list) or not ops:
        return None, 'no ops given', 400
    if len(ops) > PATCH_MAX_OPS:
        return None, 'too many ops in one patch (max %d)' % PATCH_MAX_OPS, 400
    cur, serr = read_state(dirpath)
    if serr:      # same refusal as PUT: never write on top of a backlog we couldn't read
        return None, 'state.json ' + serr, 409
    items = [dict(it) for it in (cur.get('items') or []) if isinstance(it, dict)]
    next_id = max(1, _to_int(cur.get('nextId')))
    for it in items:
        next_id = max(next_id, _to_int(it.get('id')) + 1)

    def find(n):
        for i, it in enumerate(items):
            if _to_int(it.get('id')) == n:
                return i
        return -1

    def bad_fields(src, verb):
        for key in src:
            # named before the generic refusal so the caller learns the RULE, not just
            # the list: these two exist on cards but are written only by the server.
            if key in STAMPED_FIELDS:
                return "can't %s '%s' - stamped by the server, never typed" % (verb, key)
            if key not in PATCH_FIELDS:
                return "can't %s '%s' (allowed: %s)" % (verb, key, ', '.join(PATCH_FIELDS))
        return None

    # Lanes to validate `track` against. Falls back the same way write_state does, so a
    # caller that reaches the core without a resolved palette is judged by the built-ins
    # rather than having every track refused.
    lanes = tracks if tracks else TRACKS
    lane_order = order if order else TRACK_ORDER

    def bad_values(src):
        """Refuse a `track`/`status` that write_state would SILENTLY REWRITE (v0.44).

        write_state coerces an unrecognised value to the default instead of failing, and it
        must keep doing so: it also normalises the board's whole-file PUT, where a card whose
        lane was later removed from config.json would otherwise make the board unable to save
        at all. But for a patch that coercion is the one failure this door cannot report -
        the caller gets 200, `applied` names the id, the write-back reads clean, and the card
        is quietly in the wrong lane with nothing downstream able to detect it. Every other
        fault here refuses loudly and names the op index; this one now does too. Validating
        HERE and not in write_state is what keeps the board's path safe."""
        if 'status' in src and src.get('status') not in CARD_STATUSES:
            got = src.get('status')
            return 'invalid status %s (allowed: %s)' % (
                json.dumps(got if isinstance(got, str) else None), ', '.join(CARD_STATUSES))
        # `isinstance` first, deliberately: `lanes` is a dict, and `[] in {...}` raises
        # TypeError (unhashable) where the Node twin's `in` just answers false. Without
        # this, a caller sending "track": [] gets a 500 here and a 400 there.
        got = src.get('track')
        if 'track' in src and not (isinstance(got, str) and got in lanes):
            return "invalid track %s (this project's lanes: %s)" % (
                json.dumps(got if isinstance(got, str) else None), ', '.join(lane_order))
        return None

    def bad_links(src, own_id):
        """Refuse a `links` value that _clean_links would silently prune (v0.45).

        Same philosophy as bad_values: the normaliser must stay lenient because it also
        serves the board's whole-file PUT, so the strictness lives here, where a caller
        is proven to be reading the response. Checked against the working copy, so a
        link may name a card an earlier op in this same patch just added."""
        if 'links' not in src:
            return None
        val = src.get('links')
        if not isinstance(val, list):
            return 'links must be a list of {to, type} objects'
        if len(val) > LINKS_MAX:
            return 'too many links on one card (max %d)' % LINKS_MAX
        seen = set()
        for j, e in enumerate(val):
            if not isinstance(e, dict):
                return 'links[%d] is not an object' % j
            for key in e:
                if key not in ('to', 'type'):
                    return "links[%d]: a link is {to, type} - can't set '%s'" % (j, key)
            to = _to_int(e.get('to'))
            if to <= 0:
                return 'links[%d]: `to` must be a card id' % j
            if to == own_id:
                return 'links[%d]: a card cannot link to itself' % j
            if find(to) < 0:
                return 'links[%d]: there is no card #%d' % (j, to)
            t = e.get('type')
            if not (isinstance(t, str) and t in LINK_TYPES):
                return 'links[%d]: invalid type %s (allowed: %s)' % (
                    j, json.dumps(t if isinstance(t, str) else None), ', '.join(LINK_TYPES))
            if (to, t) in seen:
                return 'links[%d]: duplicate of an earlier link' % j
            seen.add((to, t))
        return None

    applied = []
    for k, op in enumerate(ops):
        at = 'op %d' % (k + 1)
        if not isinstance(op, dict):
            return None, '%s is not an object' % at, 400
        kind = op.get('op')
        if kind in ('set', 'delete', 'move'):
            # report the PARSED id, not the raw value: it keeps this message byte-identical
            # to the Node twin's, which is what makes the two machine-comparable.
            n = _to_int(op.get('id'))
            i = find(n)
            if i < 0:
                return None, '%s: there is no card #%d' % (at, n), 409
        if kind == 'set':
            fields = op.get('fields')
            if not isinstance(fields, dict) or not fields:
                return None, '%s: no fields to set' % at, 400
            msg = bad_fields(fields, 'set') or bad_values(fields) or bad_links(fields, n)
            if msg:
                return None, '%s: %s' % (at, msg), 400
            # Judged against the card as it stands before this op, so a value already over a
            # lowered ceiling that the op leaves alone is no reason to refuse (field_overflow).
            ov = field_overflow(fields, items[i])
            if ov:
                return None, '%s: %s' % (at, overflow_text('card #%d' % n, ov)), 400
            items[i].update(fields)
            applied.append({'op': 'set', 'id': n, 'fields': sorted(fields)})
        elif kind == 'add':
            src = op.get('item')
            if not isinstance(src, dict):
                return None, '%s: no item given' % at, 400
            msg = bad_fields(src, 'set')
            if msg:
                return None, '%s: %s' % (at, msg), 400
            if not str(src.get('title') or '').strip():
                return None, '%s: a new card needs a title' % at, 400
            # own_id 0 for an add: the card has no id yet, so a self-link cannot be
            # expressed - and a `to` naming the id about to be allocated fails the
            # existence check anyway.
            msg = bad_values(src) or bad_links(src, 0)
            if msg:
                return None, '%s: %s' % (at, msg), 400
            ov = field_overflow(src)
            if ov:
                return None, '%s: %s' % (at, overflow_text('the new card', ov)), 400
            new = dict(src)
            new['id'] = next_id
            next_id += 1
            pos = len(items)
            if op.get('before') is not None:
                b = _to_int(op.get('before'))
                pos = find(b)
                if pos < 0:
                    return None, '%s: there is no card #%d to insert before' % (at, b), 409
            items.insert(pos, new)
            applied.append({'op': 'add', 'id': new['id'], 'title': new.get('title')})
        elif kind == 'delete':
            applied.append({'op': 'delete', 'id': n, 'title': items[i].get('title')})
            items.pop(i)
        elif kind == 'move':
            moved = items.pop(i)
            pos = len(items)
            if op.get('before') is not None:
                b = _to_int(op.get('before'))
                pos = -1 if b == n else find(b)
                if pos < 0:
                    items.insert(i, moved)      # put it back: nothing is written on a failed patch
                    return None, '%s: there is no card #%d to move before' % (at, b), 409
            items.insert(pos, moved)
            applied.append({'op': 'move', 'id': n})
        else:
            # json.dumps (not %r) so the text matches the Node twin's JSON.stringify exactly,
            # and a missing key reads as `null` on both rather than None/undefined.
            return None, '%s: unknown op %s' % (at, json.dumps(kind if isinstance(kind, str) else None)), 400

    try:
        state = write_state(dirpath, {'items': items, 'nextId': next_id}, tracks, order)
    except FieldTooLong as e:     # unreachable while the per-op checks above hold; a backstop
        return None, str(e), 400
    return {'ok': True, 'applied': applied, 'state': state}, None, 200


# ---------------------------------------------------------------------------
# The board merge (v0.63, card #427): two copies of ONE board, changed on two
# machines, folded back into one - card by card, with the app shut.
#
#   py server.py --merge <base.json> <mine.json> <theirs.json> [--out <merged.json>]
#
# BASE is the last version both machines agreed on, MINE is this machine's copy,
# THEIRS is the copy already published. It reads those three files, writes --out
# (and nothing else - never a project's .tracker/ by itself), and prints a report
# of every decision it took. With no --out it is a dry run.
#
# WHY IT LIVES HERE. Share / host mode needs the host PC switched on. A board kept
# in a git repo does not - but state.json is one multi-megabyte JSON file and a
# text merge of it cannot be resolved by anybody. The engine is the only thing
# that knows what a card is, how ids are handed out and what a clash means, so
# the rule belongs here and an outside sync tool CALLS it rather than copying it.
#
# THE RULE IS board.html's mergeBacklog (v0.41), not a second invention:
#   - a card one side did not touch takes the other side's version,
#   - an EDIT always beats a DELETE, in both directions,
#   - order follows THEIRS unless MINE reordered, and a card the leading list
#     has never seen goes just above the card it sat above in its own list.
# tests/test_merge.py runs the same cases through that browser function and
# through both twins of this one, so the three cannot drift apart.
#
# TWO THINGS THE BROWSER NEVER HAD TO ANSWER, because there a person is at the
# screen and the other copy is the one file on disk:
#
#   BOTH SIDES CHANGED THE SAME CARD. The browser keeps the whole of MINE. Here
#   neither machine is "the one at the screen", so the card is merged FIELD BY
#   FIELD: a field only one side changed takes that side's value, and links are
#   merged as a set (what either side added stays, what either removed goes).
#   Only the SAME FIELD changed to two different values is a clash. The winner
#   is the side whose card carries the newer `lastTouched` - the engine's own
#   stamp of the last day that card's content changed - and on a tie, or where
#   the dates cannot be compared, THEIRS: it is already published, and the
#   person who can read this report is the one sitting at MINE. Every clash is
#   in the report with BOTH values in full, so the loser is never gone.
#
#   TWO NEW CARDS WITH THE SAME NUMBER. Working apart, both machines hand out
#   the same `nextId`. THEIRS keeps the number (commits and records may already
#   cite the published one); MINE's card takes a fresh number above every id
#   either side has ever used, every link MINE wrote that pointed at it is
#   rewritten, and the report lists old id, new id, title - and the cards whose
#   prose still says the old number, because prose is never rewritten for you.
#
# Refused whole, nothing written, for anything it cannot trust: a file that does
# not read, a board with a duplicated id, an unknown status, or a card carrying a
# field this engine does not know (a board saved by a NEWER Stasys - merging it
# with an older one would drop that field on every card without a word).
#
# NOT here: active.json. "Who is at the desk" is per machine and is not board
# content (v0.58) - the caller decides what to do with it, using `renumbered`.
MERGE_TOP_KEYS = ('version', 'updated', 'items', 'nextId', 'rev')
MERGE_ITEM_KEYS = ('id',) + PATCH_FIELDS + STAMPED_FIELDS
MERGE_BOOL = ('flag', 'parked')
MERGE_TEXT = tuple(f for f in PATCH_FIELDS if f not in MERGE_BOOL and f != 'links')
MERGE_CITED = ('title', 'writeup', 'resume', 'resumeRef')   # prose that can name a card
MERGE_ID_MAX = 9007199254740991       # 2**53 - 1: the largest id both twins can hold exactly
RE_MERGE_DAY = re.compile(r'^[0-9]{4}-[0-9]{2}-[0-9]{2}')


class MergeRefused(ValueError):
    """The merge cannot be done safely. Nothing has been written."""


def _merge_int(v):
    """A whole number out of a parsed JSON value, or None. Strict on purpose, and the
    same on both twins: JSON `12.0` is a float here and an integer in JavaScript."""
    if isinstance(v, bool):
        return None
    if isinstance(v, float) and v == v and abs(v) <= MERGE_ID_MAX and v == int(v):
        v = int(v)
    if not isinstance(v, int) or abs(v) > MERGE_ID_MAX:
        return None
    return v


def _merge_day(s):
    """The YYYY-MM-DD at the front of a stamp, or '' if it is not one."""
    s = str(s or '')
    return s[:10] if RE_MERGE_DAY.match(s) else ''


def _merge_link_key(e):
    return '%d:%s' % (e['to'], e['type'])


def _merge_same(a, b, f):
    if f == 'links':
        return (','.join(_merge_link_key(e) for e in a[f])
                == ','.join(_merge_link_key(e) for e in b[f]))
    return a[f] == b[f]


def _merge_same_card(a, b):
    """board.html's cardSig, as a comparison: every CONTENT field, never the stamps."""
    for f in PATCH_FIELDS:
        if not _merge_same(a, b, f):
            return False
    return True


def merge_check(state, who):
    """Why this board cannot be merged, or None. STRICT, unlike write_state's normaliser:
    that one must keep a board saveable; this one must never guess at a board it is about
    to combine with another, because a guess here is a silent rewrite of somebody's card."""
    if not isinstance(state, dict) or not isinstance(state.get('items'), list):
        return "%s is not a backlog (no 'items' list)" % who
    extra = sorted(k for k in state if k not in MERGE_TOP_KEYS)
    if extra:
        return ('%s carries a top-level entry this Stasys does not know (%s) - it was saved by '
                'a newer Stasys. Update this copy before merging' % (who, extra[0]))
    if state.get('version') is not None and _merge_int(state.get('version')) != 1:
        return '%s is not a version 1 backlog' % who
    if state.get('nextId') is not None:
        n = _merge_int(state.get('nextId'))
        if n is None or n < 0:
            return '%s has a nextId that is not a whole number' % who
    seen = set()
    for i, it in enumerate(state['items']):
        if not isinstance(it, dict):
            return '%s: entry %d of its items is not a card' % (who, i + 1)
        iid = _merge_int(it.get('id'))
        if iid is None or iid <= 0:
            return '%s: entry %d of its items has no usable id' % (who, i + 1)
        if iid in seen:
            return '%s: card #%d appears twice' % (who, iid)
        seen.add(iid)
        extra = sorted(k for k in it if k not in MERGE_ITEM_KEYS)
        if extra:
            return ('%s: card #%d carries a field this Stasys does not know (%s) - it was saved '
                    'by a newer Stasys. Update this copy before merging' % (who, iid, extra[0]))
        st = it.get('status')
        if not isinstance(st, str) or st not in CARD_STATUSES:
            return '%s: card #%d has a status this Stasys does not know' % (who, iid)
        if not isinstance(it.get('track'), str) or not it.get('track'):
            return '%s: card #%d has no track' % (who, iid)
        for f in MERGE_TEXT + STAMPED_FIELDS:
            if it.get(f) is not None and not isinstance(it.get(f), str):
                return "%s: card #%d's %s is not text" % (who, iid, f)
        for f in MERGE_BOOL:
            if it.get(f) is not None and not isinstance(it.get(f), bool):
                return "%s: card #%d's %s is not true or false" % (who, iid, f)
        lk = it.get('links')
        if lk is not None and (not isinstance(lk, list) or len(_clean_links(lk, iid)) != len(lk)):
            return '%s: card #%d has a link the engine cannot read' % (who, iid)
    return None


def _merge_card(it):
    """One card in full canonical form - every field present - so two copies of it can be
    compared by VALUE. A card the board wrote without a `resume` key and the same card
    echoed back with resume:'' are the same card; reading that as an edit would hand one
    side a win it never earned (the trap cardSig's own comment describes)."""
    iid = _merge_int(it.get('id'))
    c = {'id': iid}
    for f in PATCH_FIELDS:
        if f in MERGE_BOOL:
            c[f] = bool(it.get(f))
        elif f == 'links':
            c[f] = _clean_links(it.get(f), iid)
        else:
            c[f] = it.get(f) or ''
    for f in STAMPED_FIELDS:
        c[f] = it.get(f) or ''
    return c


def _merge_copy(c):
    d = dict(c)
    d['links'] = [{'to': e['to'], 'type': e['type']} for e in c['links']]
    return d


def _merge_shape(c):
    """A merged card in exactly the shape write_state leaves on disk: same key order, the
    same keys left out when empty, and the same three backstops - `parked` only on a live
    card, the done stamps only on a done card, a note's date only with a note. A field
    merge can produce 'done by one machine, parked by the other'; a normal save would
    settle that the same way."""
    out = {'id': c['id'], 'title': c['title'], 'track': c['track'], 'status': c['status'],
           'writeup': c['writeup'], 'flag': c['flag'],
           'parked': c['parked'] and c['status'] in ('table', 'air')}
    if c['resume']:
        out['resume'] = c['resume']
    if c['resumeRef']:
        out['resumeRef'] = c['resumeRef']
    if c['resume'] and c['resumeAt']:
        out['resumeAt'] = c['resumeAt']
    if c['status'] == 'done':
        out['doneVersion'] = c['doneVersion']
        out['doneDate'] = c['doneDate']
    if c['links']:
        out['links'] = [{'to': e['to'], 'type': e['type']} for e in c['links']]
    if c['created']:
        out['created'] = c['created']
    if c['lastTouched']:
        out['lastTouched'] = c['lastTouched']
    return out


def _merge_cites(text, n):
    """Does this prose name card #n? The character after the number is tested by hand
    rather than with a regex word boundary: Python's is Unicode-aware and JavaScript's is
    not, so a letter outside ASCII straight after the number would split the twins."""
    tag = '#%d' % n
    i = text.find(tag)
    while i >= 0:
        ch = text[i + len(tag):i + len(tag) + 1]
        if not (ch == '_' or ('0' <= ch <= '9') or ('a' <= ch <= 'z') or ('A' <= ch <= 'Z')) or not ch:
            return True
        i = text.find(tag, i + 1)
    return False


def _merge_fields(b, m, t):
    """Both sides changed one card (b in BASE). Merge it field by field.
    Returns (card, report entry, clashes)."""
    md, td = _merge_day(m['lastTouched']), _merge_day(t['lastTouched'])
    if md and td and md > td:
        winner, why = 'mine', 'mine was edited more recently (%s against %s)' % (md, td)
    elif md and td and td > md:
        winner, why = 'theirs', 'theirs was edited more recently (%s against %s)' % (td, md)
    elif md and td:
        winner, why = 'theirs', 'both were edited on %s - the published copy (theirs) is kept' % td
    else:
        winner, why = 'theirs', ('the edit dates cannot be compared - the published copy '
                                 '(theirs) is kept')
    c = _merge_copy(t)
    m_f, t_f, clash = [], [], []
    for f in PATCH_FIELDS:
        m_ch, t_ch = not _merge_same(m, b, f), not _merge_same(t, b, f)
        if m_ch:
            m_f.append(f)
        if t_ch:
            t_f.append(f)
        if f == 'links' or f == 'resumeAt':
            continue                                   # settled below, never a clash
        if m_ch and t_ch and m[f] != t[f]:
            clash.append({'field': f, 'winner': winner, 'why': why,
                          'mine': m[f], 'theirs': t[f]})
            c[f] = m[f] if winner == 'mine' else t[f]
        elif m_ch:
            c[f] = m[f]
    # links are a SET of (to, type): what either side added stays, what either removed goes.
    if 'links' in m_f and 'links' in t_f:
        bk = set(_merge_link_key(e) for e in b['links'])
        mk = set(_merge_link_key(e) for e in m['links'])
        tk = set(_merge_link_key(e) for e in t['links'])
        c['links'] = ([{'to': e['to'], 'type': e['type']} for e in t['links']
                       if not (_merge_link_key(e) in bk and _merge_link_key(e) not in mk)]
                      + [{'to': e['to'], 'type': e['type']} for e in m['links']
                         if _merge_link_key(e) not in bk and _merge_link_key(e) not in tk])
        if len(c['links']) > LINKS_MAX:
            raise MergeRefused('card #%d would carry more than %d links once both sides '
                               'are combined' % (c['id'], LINKS_MAX))
    elif 'links' in m_f:
        c['links'] = [{'to': e['to'], 'type': e['type']} for e in m['links']]
    # resumeAt is a stamp ON the note, not content: it follows the note it describes.
    if 'resumeAt' in m_f and 'resumeAt' in t_f and m['resumeAt'] != t['resumeAt']:
        is_m = c['resume'] == m['resume'] and c['resumeRef'] == m['resumeRef']
        is_t = c['resume'] == t['resume'] and c['resumeRef'] == t['resumeRef']
        ma, ta = _merge_day(m['resumeAt']), _merge_day(t['resumeAt'])
        if is_m and not is_t:
            c['resumeAt'] = m['resumeAt']
        elif is_t and not is_m:
            c['resumeAt'] = t['resumeAt']
        elif ma and ta:
            c['resumeAt'] = m['resumeAt'] if ma > ta else t['resumeAt']
        else:
            c['resumeAt'] = m['resumeAt'] if winner == 'mine' else t['resumeAt']
    elif 'resumeAt' in m_f:
        c['resumeAt'] = m['resumeAt']
    c['created'] = t['created'] or m['created']
    c['lastTouched'] = (m['lastTouched'] if (md and td and md > td) else t['lastTouched']) \
        or m['lastTouched']
    entry = {'id': c['id'], 'title': c['title'], 'mine': m_f, 'theirs': t_f,
             'clashes': [x['field'] for x in clash], 'winner': winner if clash else None,
             'identical': False}
    return c, entry, clash


def merge_states(base, mine, theirs):
    """Three whole boards in, one merged board and a report out. PURE: no files, no clock.
    Raises MergeRefused. Returns ({'items': [...], 'nextId': n}, report)."""
    for who, st in (('BASE', base), ('MINE', mine), ('THEIRS', theirs)):
        err = merge_check(st, who)
        if err:
            raise MergeRefused(err)
    b_list = [_merge_card(it) for it in base['items']]
    m_list = [_merge_card(it) for it in mine['items']]
    t_list = [_merge_card(it) for it in theirs['items']]
    B = dict((c['id'], c) for c in b_list)
    T = dict((c['id'], c) for c in t_list)
    next_free = 1
    for st, lst in ((base, b_list), (mine, m_list), (theirs, t_list)):
        next_free = max(next_free, _merge_int(st.get('nextId')) or 0)
        for c in lst:
            next_free = max(next_free, c['id'] + 1)

    # ---- 1. two NEW cards sharing one number: THEIRS keeps it, MINE's moves ----
    clashing = sorted(c['id'] for c in m_list
                      if c['id'] not in B and c['id'] in T
                      and not _merge_same_card(c, T[c['id']]))
    renum = {}
    for k in clashing:
        renum[k] = next_free
        next_free += 1
    renumbered = []
    if renum:
        for c in m_list:
            old = B.get(c['id'])
            keep = set(_merge_link_key(e) for e in old['links']) if old else set()
            for e in c['links']:
                # A link the card already carried in BASE is older than the clash and never
                # meant MINE's new card; every other link MINE holds to that number did.
                if e['to'] in renum and _merge_link_key(e) not in keep:
                    e['to'] = renum[e['to']]
        for c in m_list:
            if c['id'] in renum:
                c['id'] = renum[c['id']]
        for k in clashing:
            cited = []
            title = ''
            for c in m_list:
                if c['id'] == renum[k]:
                    title = c['title']
                old = B.get(c['id'])
                for f in MERGE_CITED:
                    if (old is None or c[f] != old[f]) and _merge_cites(c[f], k):
                        cited.append(c['id'])
                        break
            renumbered.append({'from': k, 'to': renum[k], 'title': title,
                               'numberKeptBy': T[k]['title'], 'citedBy': sorted(cited)})
    M = dict((c['id'], c) for c in m_list)

    # ---- 2. card by card ----
    pick = {}
    took, took_new, kept, kept_new = [], [], [], []
    both, clashes, revived, deleted = [], [], [], []
    unchanged = 0
    for c in m_list:
        k = c['id']
        if k not in B:
            if k in T:                               # the very same new card on both sides
                pick[k] = T[k]
                unchanged += 1
            else:
                pick[k] = c                          # I added it
                kept.append(k)
                kept_new.append(k)
        elif k not in T:                             # they deleted it...
            if _merge_same_card(c, B[k]):
                deleted.append({'id': k, 'title': B[k]['title'], 'by': 'theirs'})
            else:                                    # ...but I edited it: the edit wins
                pick[k] = c
                revived.append({'id': k, 'title': c['title'], 'deletedBy': 'theirs',
                                'editedBy': 'mine'})
        else:
            m_ch = not _merge_same_card(c, B[k])
            t_ch = not _merge_same_card(T[k], B[k])
            if not m_ch:
                pick[k] = T[k]                       # I never touched it - theirs stands
                if t_ch:
                    took.append(k)
                else:
                    unchanged += 1
            elif not t_ch:
                pick[k] = c                          # only I changed it
                kept.append(k)
            elif _merge_same_card(c, T[k]):          # both made the very same change
                pick[k] = T[k]
                both.append({'id': k, 'title': T[k]['title'], 'mine': [], 'theirs': [],
                             'clashes': [], 'winner': None, 'identical': True})
            else:
                card, entry, cl = _merge_fields(B[k], c, T[k])
                pick[k] = card
                both.append(entry)
                for x in cl:
                    clashes.append({'id': k, 'title': card['title'], 'field': x['field'],
                                    'winner': x['winner'], 'why': x['why'],
                                    'mine': x['mine'], 'theirs': x['theirs']})
    for c in t_list:
        k = c['id']
        if k in M:
            continue                                 # decided above
        if k not in B:
            pick[k] = c                              # they added it
            took.append(k)
            took_new.append(k)
        elif _merge_same_card(c, B[k]):
            deleted.append({'id': k, 'title': B[k]['title'], 'by': 'mine'})
        else:                                        # I deleted it, they edited it
            pick[k] = c
            revived.append({'id': k, 'title': c['title'], 'deletedBy': 'mine',
                            'editedBy': 'theirs'})
    for c in b_list:
        if c['id'] not in M and c['id'] not in T:
            deleted.append({'id': c['id'], 'title': c['title'], 'by': 'both'})

    # ---- 3. order: THEIRS leads unless MINE reordered ----
    # Compared over the cards all three know and that survive, which isolates a real drag
    # from cards merely appearing or disappearing.
    def spine(lst):
        return [c['id'] for c in lst
                if c['id'] in B and c['id'] in M and c['id'] in T and c['id'] in pick]
    mine_moved = spine(m_list) != spine(b_list)
    theirs_moved = spine(t_list) != spine(b_list)
    lead, rest = (m_list, t_list) if mine_moved else (t_list, m_list)
    order = [c['id'] for c in lead if c['id'] in pick]
    placed = set(order)
    # A card the leading list has never seen goes just ABOVE the card it sat above in its
    # own list - and stays at the bottom if it was at the bottom. Walked backwards so a run
    # of such cards keeps its own order.
    nxt = None
    for c in reversed(rest):
        k = c['id']
        if k not in pick:
            continue
        if k not in placed:
            order.insert(order.index(nxt) if nxt is not None else len(order), k)
            placed.add(k)
        nxt = k
    items = [_merge_shape(pick[k]) for k in order]

    # ---- 4. prove nothing went missing BEFORE anyone is told it worked ----
    gone = set(d['id'] for d in deleted)
    if len(placed) != len(order):
        raise MergeRefused('internal fault: the merged board would hold one id twice')
    for k in list(M) + list(T):
        if (k in pick) == (k in gone) or (k in pick and k not in placed):
            raise MergeRefused('internal fault: card #%d is unaccounted for' % k)
    if len(items) != unchanged + len(took) + len(kept) + len(both) + len(revived):
        raise MergeRefused('internal fault: the report does not add up to the merged board')

    def by_id(e):
        return e['id']
    report = {
        'counts': {'base': len(b_list), 'mine': len(m_list), 'theirs': len(t_list),
                   'merged': len(items), 'unchanged': unchanged},
        'nextId': next_free,
        'order': {'follows': 'mine' if mine_moved else 'theirs',
                  'mineReordered': mine_moved, 'theirsReordered': theirs_moved},
        'tookTheirs': {'count': len(took), 'ids': sorted(took), 'added': sorted(took_new)},
        'keptMine': {'count': len(kept), 'ids': sorted(kept), 'added': sorted(kept_new)},
        'bothChanged': {'count': len(both), 'cards': sorted(both, key=by_id)},
        'clashes': {'count': len(clashes), 'list': sorted(clashes, key=by_id)},
        'revived': {'count': len(revived), 'cards': sorted(revived, key=by_id)},
        'deleted': {'count': len(deleted), 'cards': sorted(deleted, key=by_id)},
        'renumbered': {'count': len(renumbered), 'cards': renumbered},
    }
    return {'items': items, 'nextId': next_free}, report


def merge_read(path, who):
    """One of the three boards off disk, by the same tests read_state applies - except that
    a MISSING file is an error here. read_state reads 'no state.json' as 'no backlog yet';
    a merge handed a path that is not there has been handed the wrong path, and treating
    that as an empty board would delete every card on the other side."""
    try:
        with open(path, 'r', encoding='utf-8') as f:
            raw = f.read()
    except Exception as e:
        return None, '%s (%s) could not be opened (%s)' % (who, path, e.__class__.__name__)
    if not raw.strip():
        return None, '%s (%s) is empty (0 bytes)' % (who, path)
    try:
        obj = json.loads(raw)
    except ValueError as e:
        return None, '%s (%s) is not valid JSON (%s)' % (who, path, e)
    if not isinstance(obj, dict) or not isinstance(obj.get('items'), list):
        return None, "%s (%s) is valid JSON but not a backlog (no 'items' list)" % (who, path)
    return obj, None


def merge_files(base_path, mine_path, theirs_path, out_path=None):
    """The --merge door. Returns (report, error). On error NOTHING has been written."""
    states = []
    for who, p in (('BASE', base_path), ('MINE', mine_path), ('THEIRS', theirs_path)):
        st, err = merge_read(p, who)
        if err:
            return None, err
        states.append(st)
    try:
        merged, report = merge_states(states[0], states[1], states[2])
    except MergeRefused as e:
        return None, str(e)
    # Built in write_state's own key order. `rev` is computed, never stored (v0.41).
    clean = {'version': 1, 'updated': datetime.datetime.now().isoformat(),
             'items': merged['items'], 'nextId': merged['nextId']}
    text = json.dumps(clean, indent=2, ensure_ascii=False)
    back = json.loads(text)                # what is about to be handed over must read back
    if merge_check(back, 'the merged board') or len(back['items']) != len(merged['items']):
        return None, 'internal fault: the merged board does not read back as a board'
    if out_path:
        try:
            _write_atomic(out_path, text)
        except Exception as e:
            return None, ('the merged board could not be written to %s (%s)'
                          % (out_path, e.__class__.__name__))
    out = {'ok': True, 'written': bool(out_path), 'out': out_path or None,
           'rev': _state_rev(text)}
    out.update(report)
    return out, None


def render_deferred(proj, state, tracks=None):
    if not tracks:
        tracks = TRACKS
    buckets = [('table', 'On the table'), ('air', 'Up in the air'), ('done', 'Done ✓'), ('cut', 'Cut')]
    top = next((x for x in state['items'] if x['status'] == 'table'), None)
    md = "# Deferred backlog - %s\n\n" % proj
    md += "_Auto-generated by Project Tracker - %s. Edit in the board, not by hand._\n\n" % datetime.date.today().isoformat()
    # Parking never reorders anything: a parked card keeps its place, so the top of the
    # table is still what "let's continue" picks. Saying so here is the whole point -
    # this file is what gets read when the board isn't open.
    nxt = "_(nothing on the table)_"
    if top:
        nxt = top['title']
        if top.get('parked'):
            nxt += ' **(parked - read its resume note below before continuing)**'
    md += "**Next up** (what an unspecified \"let's continue\" picks): %s\n\n" % nxt
    parked = [x for x in state['items'] if x.get('parked')]
    if parked:
        md += "**Parked** (set down mid-flight, %d): %s\n\n" % (
            len(parked), ', '.join('#%s %s' % (x.get('id'), x['title']) for x in parked))
    for st, label in buckets:
        md += "## %s\n" % label
        items = [x for x in state['items'] if x['status'] == st]
        if not items:
            md += "_(none)_\n\n"
            continue
        for i, it in enumerate(items):
            tk = tracks[it['track']]['short'] if it['track'] in tracks else it['track']
            prefix = ("%d." % (i + 1)) if st == 'table' else '-'
            ver = (' (%s)' % it['doneVersion']) if (st == 'done' and it.get('doneVersion')) else ''
            marks = ' **(blocker)**' if it['flag'] else ''
            if it.get('parked'):
                marks += ' **(parked)**' if it.get('resume') else ' **(parked - NO RESUME NOTE)**'
            md += "%s [%s] %s%s%s\n" % (prefix, tk, it['title'], ver, marks)
            # The resume note goes ABOVE the write-up: it is the short "where does this
            # stand" line, and burying it under an 18k-char write-up would defeat it.
            if it.get('resume'):
                md += "   - resume: %s%s\n" % (
                    ' '.join(it['resume'].split()),
                    ('  [%s]' % ' '.join(it['resumeRef'].split())) if it.get('resumeRef') else '')
                # A note's date is only useful if its ABSENCE is visible too: an undated note
                # used to render no line at all here, which reads as "nothing to say" rather
                # than "nobody knows". And `lastTouched` newer than the note means the card
                # moved AFTER the note was written - the better of the two staleness signals,
                # because it is about this card rather than about the calendar.
                at = _date_only(it.get('resumeAt'))
                lt = _date_only(it.get('lastTouched'))
                if not at:
                    md += "     (note UNDATED - written before Stasys stamped these, or by hand)\n"
                elif lt and lt > at:
                    md += "     (note written %s - THE CARD HAS CHANGED SINCE, %s)\n" % (at, lt)
                else:
                    md += "     (note written %s)\n" % at
            # Links are state too, and this file is what gets read when the board isn't open.
            if it.get('links'):
                md += "   - links: %s\n" % ', '.join(
                    '%s #%s' % (l.get('type'), l.get('to')) for l in it['links'])
            if it['writeup']:
                md += "   - %s\n" % ' '.join(it['writeup'].split())
        md += "\n"
    return md


def sync_deferred(dirpath):
    """Self-heal DEFERRED.md from state.json. write_state() regenerates DEFERRED.md only
    when the board *saves*; an externally-edited state.json (an editor, a script, a tool's
    temp-file-then-rename) would otherwise leave DEFERRED.md frozen until the next board write.
    Called from the read paths (/api/state, /api/poll), so while the board is open it polls
    every ~6s and DEFERRED.md reconciles within one interval of any state.json change.
    Cheap: stats first, only reads+renders+writes when DEFERRED.md is missing or stale.
    Regenerating DEFERRED.md changes neither state.json's mtime nor the docs fingerprint,
    so it never re-triggers the board's auto-refresh.
    Refuses to touch DEFERRED.md when state.json can't be parsed - rendering a damaged
    state would write an EMPTY backlog over the last good human-readable copy, and this
    runs on the READ paths, so merely opening the board would have destroyed it."""
    td = os.path.join(dirpath, '.tracker')
    state_mt = _mtime_ms(os.path.join(td, 'state.json'))
    if not state_mt:
        return False
    deferred_path = os.path.join(td, 'DEFERRED.md')
    if state_mt <= _mtime_ms(deferred_path):   # DEFERRED.md already at or ahead of state.json
        return False
    try:
        state, err = read_state(dirpath)
        if err:
            return False                       # damaged - leave the good DEFERRED.md alone
        cfg = read_config(dirpath)
        tracks, _order = resolve_tracks(cfg)
        md = render_deferred(os.path.basename(dirpath), state, tracks)   # render before opening
        _write_atomic(deferred_path, md)
        return True
    except Exception:
        return False


# ---- Truth layer: core-doc audit panel ----
def _date_only(s):
    m = RE_DATE.search(s or '')
    return m.group(0) if m else ''


def _rel_ok(rel):
    """Reject absolute paths and any traversal out of the project dir."""
    rel = (rel or '').replace('\\', '/').strip().lstrip('/')
    if not rel or os.path.isabs(rel):
        return ''
    parts = rel.split('/')
    if '..' in parts or '' in [p for p in parts if p == '']:
        return ''
    return rel


RE_DOC_VER = re.compile(r'v(\d+)[._](\d+)([a-z]?)', re.I)
def _doc_ver_key(rel):
    """Order glob matches by NUMERIC version, so PROJECT_BIBLEv10_08 sorts AFTER
       PROJECT_BIBLEv9_99 - which a plain string sort does not, because the text '9'
       compares greater than '1'.

       This is _session_fname_key's fault in a second place, and it has bitten for
       real: on 2026-08-04 the Documents panel resolved a NINE-VERSION-STALE Bible
       and reported it current, because the project had just passed v10. The
       workaround was a two-digit glob (`v??_`) in that project's config, which only
       hides the fault until v100. Sorting by the number fixes it at the source.

       A name carrying no version keeps a plain sort and ranks BELOW any that does:
       an unversioned file can never be "the latest" while a versioned one exists."""
    ms = RE_DOC_VER.findall(os.path.basename(rel))
    if not ms:
        return (0, 0, 0, '', rel.lower())
    maj, minor, sfx = ms[-1]
    return (1, int(maj), int(minor), sfx.lower(), rel.lower())


def _resolve_latest_glob(dirpath, pattern):
    """Resolve a docs[] glob entry to its latest match, as a project-relative posix
       path. For per-session-versioned docs like a Bible. Latest = NUMERICALLY
       newest version (see _doc_ver_key), not highest-sorting text."""
    import pathlib
    pat = (pattern or '').replace('\\', '/').strip().lstrip('/')
    if not pat or os.path.isabs(pat) or '..' in pat.split('/'):
        return ''
    try:
        matches = []
        for pth in pathlib.Path(dirpath).glob(pat):
            if not pth.is_file():
                continue
            rel = pth.relative_to(dirpath).as_posix()
            if any(seg in EXCLUDE for seg in rel.split('/')):
                continue
            matches.append(rel)
        matches.sort(key=_doc_ver_key)
        return matches[-1] if matches else ''
    except Exception:
        return ''


def declared_docs(dirpath, cfg):
    """(docs, unresolved) - the canonical doc list, PLUS every declared {glob} entry
       that matched no file at all.

       The second half exists because that case used to vanish: the entry was dropped
       and the panel showed one row fewer, so BROKEN CONFIG rendered exactly like a
       project that had never declared the doc. A declared {path} that is missing has
       always shown a red 'missing' row; the glob form was the one that failed
       silently, and an absent signal must never render as a well one (v0.56, v0.59)."""
    out, seen, unresolved = [], set(), []
    decl = cfg.get('docs') if isinstance(cfg, dict) else None
    if isinstance(decl, list) and decl:
        for entry in decl:
            rel = name = None
            self_versioned = False
            pat = ''
            if isinstance(entry, str):
                rel = entry
            elif isinstance(entry, dict):
                name = entry.get('name')
                pat = entry.get('glob') or ''
                rel = _resolve_latest_glob(dirpath, pat) if pat else entry.get('path')
                self_versioned = bool(entry.get('selfVersioned'))
            if not rel:
                if pat:
                    unresolved.append({'name': name or pat, 'glob': pat})
                continue
            rel = _rel_ok(rel)
            if not rel or rel.lower() in seen:
                continue
            seen.add(rel.lower())
            out.append({'path': rel, 'name': name or os.path.basename(rel),
                        'selfVersioned': self_versioned})
        return out, unresolved
    try:
        for name in os.listdir(dirpath):
            if name.lower().endswith('.md') and os.path.isfile(os.path.join(dirpath, name)):
                out.append({'path': name, 'name': name})
    except Exception:
        pass
    out.sort(key=lambda d: (0 if d['path'].lower().startswith('readme') else 1, d['path'].lower()))
    return out, unresolved


def core_docs(dirpath, cfg):
    """Ordered [{path,name}] of canonical docs for the audit panel.
       From cfg['docs'] (strings, {path,name}, or {glob,name}) if declared; else top-level *.md."""
    return declared_docs(dirpath, cfg)[0]


def read_doc_meta(dirpath, doc, latest_version):
    rel = doc['path']
    full = os.path.join(dirpath, rel.replace('/', os.sep))
    self_versioned = bool(doc.get('selfVersioned'))
    meta = {'path': rel, 'name': doc['name'], 'exists': False, 'mtime': '',
            'lastModified': '', 'lastVerified': '', 'version': '',
            'drift': False, 'selfVersioned': self_versioned, 'status': 'missing', 'note': ''}
    try:
        st = os.stat(full)
    except Exception:
        meta['note'] = 'file not found'
        return meta
    meta['exists'] = True
    meta['mtime'] = datetime.date.fromtimestamp(st.st_mtime).isoformat()
    try:
        with open(full, 'r', encoding='utf-8', errors='replace') as f:
            text = f.read()
    except Exception as e:
        meta['status'] = 'unreadable'
        meta['note'] = str(e)
        return meta
    lines = text.replace('\r\n', '\n').replace('\r', '\n').split('\n')
    fm = {}
    if lines and lines[0].strip() == '---':
        i = 1
        while i < len(lines) and lines[i].strip() != '---':
            mm = RE_FRONT.match(lines[i])
            if mm:
                fm[mm.group(1).lower()] = mm.group(2).strip()
            i += 1
    if 'last_modified' in fm:
        meta['lastModified'] = _date_only(fm['last_modified'])
    if 'last_verified' in fm:
        meta['lastVerified'] = _date_only(fm['last_verified'])
    if 'version' in fm:
        vt = RE_VER_TOKEN.search(fm['version'])
        meta['version'] = ('v' + vt.group(1)) if vt else fm['version'].strip()[:24]
    for l in lines[:60]:
        low = l.lower()
        if not meta['lastModified'] and ('last modified' in low or 'last updated' in low):
            meta['lastModified'] = _date_only(l)
        if not meta['lastVerified'] and 'last verified' in low:
            meta['lastVerified'] = _date_only(l)
        if not meta['version']:
            toks = RE_VER_TOKEN.findall(l)
            # Exactly one token AND a real declaration: a "version" label right
            # before it, or it sits at the end of a heading. A range / multiple
            # tokens ("(v4.00..v7.97)"), an incidental prose mention ("last
            # present in v7.00"), or a token cited mid-heading is provenance —
            # leave version blank so it can't produce a false drift flag.
            if len(toks) == 1:
                m = RE_VER_TOKEN.search(l)
                title_end = (bool(RE_HEADING.match(l)) and bool(RE_TITLE_TAIL.match(l[m.end():]))
                             and not RE_VER_PROV.search(l[:m.start()]))
                if title_end or RE_VER_DECL.search(l):
                    meta['version'] = 'v' + toks[0]
    # Drift = a doc that tracks the project version has fallen behind the latest
    # session. A self-versioned doc (own cadence, e.g. an Economics Bible) declares
    # selfVersioned in config.json docs[] and is exempt — it still shows its own
    # version, just isn't compared to the latest session.
    if (meta['version'] and latest_version and not self_versioned
            and meta['version'].lower() != latest_version.lower()):
        meta['drift'] = True
    modified = meta['lastModified'] or meta['mtime']
    if meta['lastVerified']:
        if meta['lastVerified'] < modified:
            meta['status'], meta['note'] = 'stale', 'verified before last change'
        elif meta['mtime'] and meta['lastVerified'] < meta['mtime']:
            meta['status'], meta['note'] = 'stale', 'file changed on disk since verified'
        else:
            meta['status'], meta['note'] = 'current', 'verified up to date'
    else:
        meta['status'], meta['note'] = 'unverified', 'no last_verified declared'
    return meta


def read_audit(dirpath):
    try:
        with open(os.path.join(dirpath, '.tracker', 'audit.json'), 'r', encoding='utf-8') as f:
            obj = json.load(f)
        if isinstance(obj, dict):
            return obj
    except Exception:
        pass
    return None


# ---- Doc alerts: a canonical doc that has fallen behind the sessions (v0.60) ----
#
# WHY. A project's Bible went five versions - v10.54 through v10.58 - without a bump,
# while its own charter names that Bible FIRST in every session-start ritual. So five
# sessions opened by reading a record five tags stale, and a merge failure recurred in
# exactly the way an older Bible records it failing. Nothing said so where anyone would
# see it: the `drift` chip existed, but it is a small tag inside a table in a panel you
# have to open, and nobody opened it. THE DETECTION WAS NOT THE GAP. THE SURFACE WAS.
#
# WARN-ONLY, ALWAYS. This never blocks a save, a close-out or anything else. Its
# precedents are the amber "parked - no note" chip and v0.59's pulse/claimMismatch: the
# board asks a question, the developer answers it.
RE_DOC_VER_CMP = re.compile(r'^v?(\d+)(?:[._](\d+))?', re.I)


def _ver_pair(v):
    """(major, minor) from a version string, or None if it carries no number.
       None means UNCOMPARABLE, and an uncomparable version never produces a warning:
       guessing an order we cannot read would be inventing the very fact at issue."""
    m = RE_DOC_VER_CMP.match((v or '').strip())
    if not m:
        return None
    return (int(m.group(1)), int(m.group(2) or 0))


def doc_alerts(docs, latest_version, unresolved=None):
    """PURE, and the only machine-checkable part of this feature - the twin-parity
       fixtures' subject, exactly like snap_plan and active_state.

       Two kinds:
         behind      - a versioned doc is OLDER than the newest session record.
         unresolved  - a {glob} declared in config.json that matches no file.

       BEHIND, not merely different. read_doc_meta's `drift` flag is `!=`, which is the
       right test for the panel's chip but the wrong one for a warning: bumping a doc to
       the next version BEFORE filing that version's session record is the normal order
       of writing, and warning about it would be a nag that teaches people to ignore the
       chip. Only older is stale.

       SILENCE IS THE DEFAULT, and deliberately so. No docs declared, no version in the
       doc, no session version to compare against - all say nothing. Stasys tracks itself
       and has no Bible; a project without one is a legitimate configuration, exactly like
       a project without the session hook. The case that must NOT be silent is the third:
       a glob DECLARED that matches nothing, which is broken config wearing silence's
       clothes.

       The prose lives here rather than in board.html so the two twins can be proven to
       say the same words, and so it names BOTH versions in one readable sentence."""
    out = []
    for u in (unresolved or []):
        nm = (u.get('name') or u.get('glob') or '').strip() or 'A document'
        pat = (u.get('glob') or '').strip()
        out.append({'kind': 'unresolved', 'name': nm, 'path': '', 'glob': pat,
                    'version': '', 'latest': latest_version or '',
                    'text': '%s is declared in .tracker/config.json, but no file matches %s.'
                            % (nm, pat)})
    lv = _ver_pair(latest_version)
    if lv:
        for d in (docs or []):
            if d.get('selfVersioned'):
                continue          # own cadence, never compared to the sessions
            dv = _ver_pair(d.get('version'))
            if not dv or dv >= lv:
                continue
            nm = (d.get('name') or d.get('path') or '').strip() or 'A document'
            out.append({'kind': 'behind', 'name': nm, 'path': d.get('path') or '',
                        'glob': '', 'version': d.get('version') or '',
                        'latest': latest_version or '',
                        'text': '%s is at %s - the newest session record is %s.'
                                % (nm, d.get('version') or '?', latest_version)})
    return out


def read_docs(dirpath, cfg, sessions):
    latest = sessions[-1]['version'] if sessions else ''
    core, unresolved = declared_docs(dirpath, cfg)
    docs = [read_doc_meta(dirpath, d, latest) for d in core]
    return {'latestVersion': latest, 'docs': docs, 'audit': read_audit(dirpath),
            'alerts': doc_alerts(docs, latest, unresolved)}


# ---- Activity source: a project's git log as dated per-card work evidence (v0.54) ----
#
# WHY. The lineage timeline drew every live card as a bar running to today, which asserts
# continuous work that did not happen: a card raised in July and untouched since looked exactly
# as active as one worked on yesterday. Fixing that needs EVIDENCE THAT WORK HAPPENED ON A DAY,
# and the only place that lives is the commit log.
#
# WHAT THIS IS NOT. It is not `lastTouched`. That field means "the card's content changed", and
# a bulk edit stamps a hundred cards in an afternoon; reading it as work would draw a month of
# activity that was one person typing. It is deliberately not a source here, exactly as it is
# deliberately not in the timeline's start-date ladder.
#
# THE SPLIT WITH THE BOARD. This serves GIT ONLY - the one source the browser cannot reach. The
# board already resolves session records to cards (cardRecords, built by reconcileCompletions)
# and merges its own pairs in. Resolving `completes:`/`touches:` claims a second time here, in
# two twins, would be a second implementation of matching that could disagree with the first.
#
# COMPUTED, NEVER STORED. Same rule as `rev`. Nothing here is written to state.json - a stored
# copy would be a second source of truth that goes stale the moment anyone commits.
GIT_LOG_MAX = 20000          # runaway guard on a huge repo, not a design limit
GIT_TIMEOUT = 20             # seconds; a hung git must never hang the board's poll
RE_CARD_CITE = re.compile(r'#(\d{1,6})\b')
_activity_cache = {}         # project dir -> {'head':..., 'repo':..., 'data':...}


def find_repo(dirpath, cfg):
    """Locate the git repo that carries a project's work, or None.

    THE PATH IS NOT ALWAYS THE PROJECT ROOT. SpaceLogistics keeps its engine in a subfolder and
    the repo with it (`space-logistics/.git`), so a check at the root finds nothing and concludes,
    wrongly, that the project has no history at all. Assume other projects nest theirs too.

    First match wins, in this order - deterministic, and no git process needed to decide:
      1. `repo` in .tracker/config.json (a project-relative path, or "." for the root)
      2. the project root
      3. immediate subfolders, alphabetically
      4. their subfolders, alphabetically
    Config is the escape hatch: when a project has two repos and the guess picks the wrong one,
    one line names the right one and settles it for good.

    `.git` is tested with exists(), not isdir() - a worktree or a submodule keeps a FILE there."""
    named = cfg.get('repo') if isinstance(cfg, dict) else None
    if isinstance(named, str) and named.strip():
        rel = named.strip().replace('/', os.sep).replace('\\', os.sep)
        if _rel_ok(rel.replace(os.sep, '/')) or rel == '.':
            cand = os.path.abspath(os.path.join(dirpath, rel))
            if cand.startswith(os.path.abspath(dirpath)) and os.path.exists(os.path.join(cand, '.git')):
                return cand
        return None          # named and wrong is an error to see, not a reason to go guessing
    if os.path.exists(os.path.join(dirpath, '.git')):
        return dirpath
    for depth in (1, 2):
        for cand in _repo_candidates(dirpath, depth):
            if os.path.exists(os.path.join(cand, '.git')):
                return cand
    return None


def _repo_candidates(dirpath, depth):
    """Folders `depth` levels below dirpath, alphabetically, skipping the obvious noise."""
    skip = ('.git', '.tracker', 'node_modules', '__pycache__', 'backup', '.venv', 'venv')
    level = [dirpath]
    for _ in range(depth):
        nxt = []
        for d in level:
            try:
                names = sorted(os.listdir(d))
            except Exception:
                continue
            for n in names:
                if n.lower() in skip or n.startswith('.'):
                    continue
                p = os.path.join(d, n)
                if os.path.isdir(p):
                    nxt.append(p)
        level = nxt
    return level


def git_log_lines(repo):
    """`<iso date>\\t<subject>` for every commit, newest first. [] if git can't be run.

    Author date, not committer date: we are asking when the work was done, and a rebase rewrites
    the second while leaving the first alone. Merges are kept - a merge subject in this project's
    convention ("merge: #248 - ...") is a real day's work being landed."""
    import subprocess
    try:
        p = subprocess.run(
            ['git', '-C', repo, 'log', '--no-color', '-n', str(GIT_LOG_MAX),
             '--date=short', '--format=%ad\t%s'],
            stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
            timeout=GIT_TIMEOUT, creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
    except Exception:
        return None          # no git on PATH, or it hung - a reason to report, not an empty log
    if p.returncode != 0:
        return None
    return p.stdout.decode('utf-8', 'replace').splitlines()


def git_head(repo):
    """The current commit sha, used as the cache key. '' when it can't be read."""
    import subprocess
    try:
        p = subprocess.run(['git', '-C', repo, 'rev-parse', 'HEAD'],
                           stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                           timeout=GIT_TIMEOUT,
                           creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
        return p.stdout.decode('ascii', 'replace').strip() if p.returncode == 0 else ''
    except Exception:
        return ''


def parse_commit_activity(lines):
    """`<date>\\t<subject>` lines -> {card id: [dates]}, plus what was seen.

    THE PURE CORE, and the only part of the activity source the twins can be machine-checked on:
    everything around it is a subprocess and a filesystem walk. Given identical lines both twins
    must return an identical object.

    A subject cites a card as `#NNN` ("perf: #248 - stop the clock repainting"). Every citation
    in the subject counts, so one commit closing two cards is a work-day for both. Ids are NOT
    checked against the backlog here - that would drag state.json into the cache key for no gain,
    since the board looks each id up anyway and an id it doesn't know simply goes unused.

    Dates come back sorted and deduplicated: this is a set of WORK-DAYS, not a commit count.
    Four commits on one afternoon are one day of work, and drawing them as four would make a
    busy hour look like a busy week."""
    cards, commits, cited = {}, 0, 0
    for line in (lines or []):
        i = line.find('\t')
        if i < 0:
            continue
        d, subject = line[:i].strip(), line[i + 1:]
        if len(d) != 10 or d[4] != '-' or d[7] != '-':
            continue                                  # not a date we can place on an axis
        commits += 1
        ids = RE_CARD_CITE.findall(subject)
        if not ids:
            continue
        cited += 1
        for raw in ids:
            k = str(int(raw))                         # '#007' and '#7' are the same card
            cards.setdefault(k, set()).add(d)
    # Keys go out NUMERICALLY ASCENDING, and that is not a tidiness choice. Card ids are
    # integer-like strings, and JSON.stringify hoists integer-like keys into numeric order no
    # matter what order the Node twin built them in - while Python emits insertion order. Sorting
    # here is what stops the two servers returning byte-different JSON for identical input.
    return {'cards': dict((k, sorted(cards[k])) for k in sorted(cards, key=int)),
            'commits': commits, 'cited': cited}


def project_activity(dirpath, cfg):
    """The activity payload for one project, cached on HEAD.

    1230 commits must not be re-parsed on every six-second poll, so the log is parsed once per
    commit: `git rev-parse HEAD` is one cheap process, and while it answers the same sha the
    previous parse still describes the repo exactly."""
    repo = find_repo(dirpath, cfg)
    if not repo:
        named = isinstance(cfg, dict) and isinstance(cfg.get('repo'), str) and cfg.get('repo').strip()
        return {'repo': None, 'head': '', 'commits': 0, 'cited': 0, 'cards': {}, 'days': 0,
                'note': ('config.json names a repo that has no .git in it' if named
                         else 'no git repository found in this project (checked the root and two levels down)')}
    head = git_head(repo)
    hit = _activity_cache.get(dirpath)
    if hit and hit.get('repo') == repo and hit.get('head') == head and head:
        return hit['data']
    lines = git_log_lines(repo)
    if lines is None:
        return {'repo': _rel_repo(dirpath, repo), 'head': head, 'commits': 0, 'cited': 0,
                'cards': {}, 'days': 0,
                'note': 'found a repository but could not run git (is it on PATH?)'}
    parsed = parse_commit_activity(lines)
    data = {'repo': _rel_repo(dirpath, repo), 'head': head,
            'commits': parsed['commits'], 'cited': parsed['cited'],
            'cards': parsed['cards'],
            'days': sum(len(v) for v in parsed['cards'].values()), 'note': ''}
    _activity_cache[dirpath] = {'repo': repo, 'head': head, 'data': data}
    return data


def _rel_repo(dirpath, repo):
    """The repo's path as the board should show it: relative to the project, '.' at the root."""
    try:
        rel = os.path.relpath(repo, dirpath).replace(os.sep, '/')
    except Exception:
        return '.'
    return rel if rel and rel != '.' else '.'


def _git_stamp(dirpath, cfg):
    """A stat-only signal that the repo moved, for the poll fingerprint.

    `.git/logs/HEAD` gains a line on every commit, checkout and merge, so its mtime is the
    cheapest honest answer to "has anything happened here?". No git process, in keeping with a
    fingerprint the board asks for every six seconds."""
    repo = find_repo(dirpath, cfg)
    if not repo:
        return '0'
    g = os.path.join(repo, '.git')
    return '%d:%d' % (_mtime_ms(os.path.join(g, 'logs', 'HEAD')), _mtime_ms(os.path.join(g, 'HEAD')))


# ---- Auto-refresh: cheap on-disk fingerprint (stat only, no parsing) ----
def _mtime_ms(path):
    try:
        return int(os.stat(path).st_mtime * 1000)
    except Exception:
        return 0


def fingerprint(dirpath, cfg):
    """A cheap signature of everything the board renders, from stat() only - no
       reads/parses. The board polls this; when a field changes it refetches just
       that slice, so panels stay current without a manual Reload. Fields:
         sessions = <count>:<newest mtime>   (new/edited session records)
         state    = <mtime of .tracker/state.json>   (the backlog)
         docs     = <count>:<newest core-doc mtime>:<audit.json mtime>
         config   = <mtime of .tracker/config.json>
         activity = <mtime of the repo's .git/logs/HEAD>:<.git/HEAD>   (a new commit)"""
    sd = sessions_dir_of(dirpath, cfg)
    s_n, s_mt = 0, 0
    try:
        for f in os.listdir(sd):
            if f.lower().endswith('.md'):
                s_n += 1
                mt = _mtime_ms(os.path.join(sd, f))
                if mt > s_mt:
                    s_mt = mt
    except Exception:
        pass
    docs = core_docs(dirpath, cfg)
    d_mt = 0
    for d in docs:
        mt = _mtime_ms(os.path.join(dirpath, d['path'].replace('/', os.sep)))
        if mt > d_mt:
            d_mt = mt
    audit_mt = _mtime_ms(os.path.join(dirpath, '.tracker', 'audit.json'))
    state_mt = _mtime_ms(os.path.join(dirpath, '.tracker', 'state.json'))
    config_mt = _mtime_ms(os.path.join(dirpath, '.tracker', 'config.json'))
    return {
        'sessions': '%d:%d' % (s_n, s_mt),
        'state': '%d' % state_mt,
        'docs': '%d:%d:%d' % (len(docs), d_mt, audit_mt),
        'config': '%d' % config_mt,
        'activity': _git_stamp(dirpath, cfg),
        'active': '%d' % _mtime_ms(active_path(dirpath)),
    }


# ---- Connect Claude (v0.64) ---------------------------------------------------------
# A board and nothing else is what the installer used to hand a new user: their Claude had
# no idea how Stasys works, /stasys-audit and /stasys-fix pointed at the developer's own
# E:\ drive, and the session hook was not shipped at all. This closes that in one click and
# one pasted sentence, WITHOUT a second exception to "the engine only writes inside
# .tracker/":
#
#   * the ENGINE writes its guide and the two command bodies into <project>/.tracker/claude/
#     - machine-neutral text, stamped with the engine version, refreshed forward on update;
#   * CLAUDE does the three things that live outside .tracker/, visibly and with the
#     person's approval: one import line in CLAUDE.md, two skill stubs that point back into
#     .tracker/claude/ (so they never go stale), and this computer's settings.
#
# Two things are kept apart on purpose, and mixing them was the first design and it was
# wrong. What is the SAME on every machine (the guide, the command bodies, the stubs, the
# CLAUDE.md line) may sit in files a project shares through git. What is true of ONE
# machine (where this engine and its Python live, and the hook that runs them) goes only in
# .claude/settings.local.json, which is that file's whole purpose. An absolute path baked
# into .tracker/ would flip between the dev copy and the installed copy on one PC, and
# between two PCs sharing a board - a file that rewrites itself on every poll.
#
# connect_paths / connect_install / connect_command / connect_prompt / connect_setup_text /
# connect_state are the PURE core (no files, no clock) and are machine-diffed against the
# Node twin as TEXT, sentences included - the board prints `text` verbatim and Claude runs
# what the setup text says, so two runtimes must not word either differently.
CONNECT_DIR = 'claude'                       # under a project's .tracker/
CONNECT_COPIES = (('connect/GUIDE.md', 'GUIDE.md'),
                  ('commands/stasys-audit.md', 'stasys-audit.md'),
                  ('commands/stasys-fix.md', 'stasys-fix.md'))
CONNECT_GUIDE_REF = '.tracker/claude/GUIDE.md'
CONNECT_HOOK_MARK = 'stasys_session.py'
CONNECT_EVENTS = ('SessionStart', 'Stop', 'SessionEnd')
# NOTE no ': ' inside a description - it is written into YAML frontmatter as a plain scalar.
CONNECT_SKILLS = (
    ('stasys-audit', 'Run a Stasys deep audit on this project - check its main documents '
                     'against the newest session record and show the findings on the Stasys '
                     'board. Changes no documents.'),
    ('stasys-fix', 'Audit this project with Stasys, fix the safe findings, and ask before '
                   'changing anything that is a judgment call.'),
)
RE_CONNECT_BARE = re.compile(r'^[A-Za-z0-9_.-]+$')


def connect_paths(engine_dir, has_runtime, windows):
    """Where this engine and the Python that runs it live, forward-slashed. The Python is
    decided from the FILESYSTEM (the bundled runtime if it is there, else the launcher on
    PATH), never from the running interpreter - so the Node twin gives the same answer."""
    home = str(engine_dir).replace('\\', '/').rstrip('/')
    py = (home + '/runtime/python.exe') if has_runtime else ('py' if windows else 'python3')
    return {'py': py, 'home': home, 'server': home + '/server.py',
            'audit': home + '/audit_tool.py', 'hook': home + '/hooks/stasys_session.py'}


def connect_command(paths, project, check=False):
    """The one command line Claude is handed. A bare launcher name (py) needs no quotes; a
    path does, because a Windows user name may contain a space."""
    py = paths['py'] if RE_CONNECT_BARE.match(paths['py']) else '"' + paths['py'] + '"'
    return (py + ' "' + paths['server'] + '" --connect "' + project + '"'
            + (' --check' if check else ''))


def connect_prompt(paths, project):
    """What the board puts on the clipboard. Machine-specific, built at click time, and
    never stored anywhere in the project."""
    cmd = connect_command(paths, project)
    return ('Set this project up to work with Stasys, the app that tracks it. Run this '
            'command and do exactly what it prints:\n\n' + cmd
            + ('\n\n(In PowerShell, put & and a space in front of it.)' if cmd.startswith('"') else ''))


def connect_install(paths):
    """Exactly what Claude writes outside .tracker/: the CLAUDE.md line, the two skill
    stubs, and this computer's settings. Insertion order is the output order in both twins."""
    hooks = {}
    for ev in CONNECT_EVENTS:
        # exec form (`args`): spawned directly, no shell - so a path with a space needs no
        # quoting and it does not matter which shell Claude Code would have picked.
        hooks[ev] = [{'hooks': [{'type': 'command', 'command': paths['py'],
                                 'args': [paths['hook']]}]}]
    skills = []
    for name, desc in CONNECT_SKILLS:
        skills.append({'file': '.claude/skills/' + name + '/SKILL.md',
                       # user-invoked only: an audit that edits documents is something the
                       # person asks for, never something Claude decides to start
                       'text': ('---\nname: ' + name + '\ndescription: ' + desc
                                + '\ndisable-model-invocation: true\n---\n\n'
                                'Read `.tracker/claude/' + name + '.md` in this project and '
                                'follow it exactly.\n\nArguments: $ARGUMENTS\n')})
    return {'claudeMd': {'file': 'CLAUDE.md', 'line': '@' + CONNECT_GUIDE_REF},
            'skills': skills,
            'settings': {'file': '.claude/settings.local.json',
                         'merge': {'env': {'STASYS_PY': paths['py'],
                                           'STASYS_HOME': paths['home']},
                                   'hooks': hooks}}}


def connect_setup_text(paths, project, version):
    """The instructions `--connect <project>` prints for Claude to carry out. ASCII apart
    from the paths, one step per thing, every step safe to repeat. GENERATED into both
    twins from one list (build/gen_connect_text.py) - edit that, not this."""
    ins = connect_install(paths)
    py_q = paths['py'] if RE_CONNECT_BARE.match(paths['py']) else '"' + paths['py'] + '"'
    L = [
        '# Stasys - set this project up for Claude Code',
        '',
        'Project: ' + project + '    Stasys: ' + (version or 'unknown'),
        '',
        'Running this command has already put the Stasys guide and two command files in',
        '`.tracker/claude/` in this project. Nothing else has been changed. Now do steps 1 to 3',
        'in THIS project folder, check your work with step 4, and finish with step 5. Change',
        'nothing else. Every step is safe to repeat: skip any that is already done.',
        '',
        'If you are stopped from writing a file under `.claude/` (a permission prompt, or a safety',
        'rule on this computer), ask the person to approve it. Do not work around it.',
        '',
        '## 1. Point CLAUDE.md at the guide',
        '',
        'If the project has no `' + ins['claudeMd']['file'] + '`, create it - a new one needs nothing else in it.',
        'Unless the file already has it, add this line on its own - at the start of a line,',
        'outside any code block (under a `## Stasys` heading is tidy):',
        '',
        ins['claudeMd']['line'],
        '',
        'Then read `' + CONNECT_GUIDE_REF + '` yourself. It is how this project\'s board works.',
        '',
        '## 2. Install the two commands',
        '',
        'Create these two files with exactly this content, each ending with a newline. If one is',
        'already there, replace it:',
    ]
    for sk in ins['skills']:
        L += ['', '`' + sk['file'] + '`', '', '```', sk['text'].rstrip('\n'), '```']
    L += [
        '',
        '## 3. Set this computer up',
        '',
        'Merge this into `' + ins['settings']['file'] + '`. Create the file if it is missing and',
        'keep everything already in it. `env` says where Stasys and its Python are on this',
        'computer: always merge it. The three hooks run a small script, `' + CONNECT_HOOK_MARK + '`,',
        'when a Claude session starts, finishes a turn and ends. It notes in',
        '`.tracker/active.json` that a session is running, so the board can show it, and does',
        'nothing else. If a hook running that script is already registered for this project - in',
        '`.claude/settings.json`, `.claude/settings.local.json` or the user-level',
        '`~/.claude/settings.json` - do not add a second one.',
        '',
        '```json',
        json.dumps(ins['settings']['merge'], indent=2, ensure_ascii=False),
        '```',
        '',
        'That file belongs to this computer only. If the project is a git repository, make sure',
        '`' + ins['settings']['file'] + '` is ignored - add it to `.gitignore` if it is not.',
        '',
        'The hooks are written with `args`, which runs the program directly, with no shell. If',
        'your Claude Code\'s settings reference does not list `args` for a command hook, write each',
        'of the three as one shell command instead:',
        '',
        py_q + ' "' + paths['hook'] + '"',
        '',
        '## 4. Check your work',
        '',
        connect_command(paths, project, True),
        '',
        'It prints each step and whether it is done. Fix whatever it reports as not done, and run',
        'it again. (In PowerShell, a command that starts with a quote needs & and a space in front.)',
        '',
        '## 5. Tell the person',
        '',
        'In plain words: that the project is connected; that they should START A NEW CLAUDE',
        'SESSION so the guide and the session signal load; and that after that the Connect Claude',
        'panel on the Stasys board should show every step ticked and say a Claude session has',
        'reported in. If it still says none has, they should tell you - the guide has a section',
        'for exactly that.',
    ]
    return '\n'.join(L) + '\n'

def connect_state(f):
    """The checklist the board draws. `f` is the facts (see connect_facts); the answer is
    four steps, each one plain sentence, and whether the project is connected. Pure."""
    f = f if isinstance(f, dict) else {}
    missing = f.get('helpersMissing') if isinstance(f.get('helpersMissing'), list) else []
    guide = f.get('guide') if f.get('guide') in ('ok', 'old', 'none') else 'none'
    steps = []
    if missing:
        n = len(missing)
        steps.append({'key': 'guide', 'done': False,
                      'text': ('Stasys is missing ' + str(n) + ' of its own helper file'
                               + ('' if n == 1 else 's') + ', so it cannot set this up yet. '
                               'Update Stasys, then try again.')})
    elif guide == 'ok':
        steps.append({'key': 'guide', 'done': True,
                      'text': 'Stasys has put its guide for Claude in this project.'})
    elif guide == 'old':
        steps.append({'key': 'guide', 'done': False,
                      'text': ('The guide in this project is from an older Stasys ('
                               + str(f.get('guideVersion') or 'unknown')
                               + '). Click Connect Claude to refresh it.')})
    else:
        steps.append({'key': 'guide', 'done': False,
                      'text': 'Stasys has not put its guide for Claude in this project yet.'})
    if f.get('instructions') is True:
        steps.append({'key': 'instructions', 'done': True,
                      'text': 'Claude reads the guide at the start of every session.'})
    else:
        steps.append({'key': 'instructions', 'done': False,
                      'text': 'Claude has not been told to read the guide yet.'})
    if f.get('skills') is True:
        steps.append({'key': 'skills', 'done': True,
                      'text': '/stasys-audit and /stasys-fix are installed.'})
    else:
        steps.append({'key': 'skills', 'done': False,
                      'text': '/stasys-audit and /stasys-fix are not installed yet.'})
    if f.get('machine') is True and f.get('hookSeen') is True:
        steps.append({'key': 'machine', 'done': True,
                      'text': 'This computer is set up, and a Claude session has reported in.'})
    elif f.get('machine') is True:
        # set up but silent is NOT the same as working - say which, as v0.59 learned
        steps.append({'key': 'machine', 'done': True,
                      'text': ('This computer is set up. No Claude session has reported in '
                               'yet - start a new one.')})
    else:
        steps.append({'key': 'machine', 'done': False,
                      'text': 'This computer is not set up yet.'})
    done = len([s for s in steps if s['done']])
    connected = done == len(steps)
    return {'connected': connected, 'ready': not missing, 'done': done, 'total': len(steps),
            'summary': ('Claude is connected to this project.' if connected
                        else str(done) + ' of ' + str(len(steps)) + ' steps done.'),
            'steps': steps}


def _claude_home():
    """The user-level .claude folder. STASYS_CLAUDE_HOME overrides it - the suites point it
    at an empty folder so a developer's own global commands cannot tick a sandbox's box."""
    env = os.environ.get('STASYS_CLAUDE_HOME')
    if env and env.strip():
        return env.strip()
    return os.path.join(os.path.expanduser('~'), '.claude')


def _read_small(path, limit=2000000):
    """A text file's content, or '' if it is missing, unreadable or implausibly large."""
    try:
        if os.path.getsize(path) > limit:
            return ''
        with open(path, 'r', encoding='utf-8-sig', errors='replace') as f:
            return f.read()
    except Exception:
        return ''


def connect_here():
    return connect_paths(ENGINE_DIR,
                         os.path.isfile(os.path.join(ENGINE_DIR, 'runtime', 'python.exe')),
                         os.name == 'nt')


def connect_dir(dirpath):
    return os.path.join(dirpath, '.tracker', CONNECT_DIR)


def connect_stamp():
    return APP_VERSION or 'v0.0'


def connect_guide_state(dirpath):
    """('ok'|'old'|'none', the version stamped on the project's copies)."""
    cd = connect_dir(dirpath)
    ver = _read_small(os.path.join(cd, 'VERSION')).strip()
    if not ver or not all(os.path.isfile(os.path.join(cd, dst)) for _src, dst in CONNECT_COPIES):
        return 'none', ver
    return ('old' if _version_cmp(ver, connect_stamp()) < 0 else 'ok'), ver


def connect_write(dirpath):
    """Copy the guide and the two command bodies into <project>/.tracker/claude/ and stamp
    them. Returns (names written, error). Byte-for-byte copies, so what the project holds
    is what the engine ships. NEVER downgrades: copies stamped by a NEWER engine (another
    machine, or the dev copy beside an installed one) are left exactly as they are."""
    if helpers_missing():
        return [], 'helpers-missing'
    cd = connect_dir(dirpath)
    ver = _read_small(os.path.join(cd, 'VERSION')).strip()
    if ver and _version_cmp(ver, connect_stamp()) > 0:
        return [], None
    os.makedirs(cd, exist_ok=True)
    todo = []
    for src, dst in CONNECT_COPIES:
        with open(os.path.join(ENGINE_DIR, *src.split('/')), 'rb') as f:
            todo.append((dst, f.read()))
    todo.append(('VERSION', (connect_stamp() + '\n').encode('utf-8')))   # last: it is the stamp
    written = []
    for dst, data in todo:
        out = os.path.join(cd, dst)
        try:
            with open(out, 'rb') as f:
                if f.read() == data:
                    continue
        except Exception:
            pass
        tmp = out + '.tmp'
        with open(tmp, 'wb') as f:
            f.write(data)
        os.replace(tmp, out)
        written.append(dst)
    return written, None


_CONNECT_CHECKED = set()

def connect_refresh(dirpath):
    """Bring an ALREADY-CONNECTED project's copies up to this engine's version. Called from
    the poll, so it is one stat-and-compare per project per process (a version can only
    change with a restart). Strictly forward and strictly opt-in: a project that was never
    connected is never touched, and same-version copies are never rewritten here - only an
    explicit Connect does that - or a dev copy and an installed copy would trade the files
    back and forth for ever."""
    key = os.path.normcase(os.path.abspath(dirpath))
    if key in _CONNECT_CHECKED:
        return False
    state, _ver = connect_guide_state(dirpath)
    if state != 'old':
        _CONNECT_CHECKED.add(key)
        return False
    if helpers_missing():
        return False                    # not yet - ensure_helpers may still be fetching
    written, err = connect_write(dirpath)
    _CONNECT_CHECKED.add(key)
    return bool(written) and not err


def connect_facts(dirpath):
    """Read-only. Everything outside .tracker/ is only ever LOOKED at here."""
    guide, gver = connect_guide_state(dirpath)
    home = _claude_home()
    proj_claude = os.path.join(dirpath, '.claude')
    instructions = (CONNECT_GUIDE_REF in _read_small(os.path.join(dirpath, 'CLAUDE.md'))
                    or CONNECT_GUIDE_REF in _read_small(os.path.join(proj_claude, 'CLAUDE.md')))

    def has_skill(name):
        # THE PROJECT'S OWN stub, and one that really points at the body in .tracker/claude/.
        # A copy in the user account does not count: the first rehearsal ran on a machine with
        # old global /stasys-audit and /stasys-fix, the two stubs were never written, and this
        # box ticked anyway - so "fix whatever is not done" could not catch the skipped step.
        ref = '.tracker/' + CONNECT_DIR + '/' + name + '.md'
        return (ref in _read_small(os.path.join(proj_claude, 'skills', name, 'SKILL.md'))
                or ref in _read_small(os.path.join(proj_claude, 'commands', name + '.md')))
    skills = all(has_skill(name) for name, _desc in CONNECT_SKILLS)

    local = _read_small(os.path.join(proj_claude, 'settings.local.json'))
    env_ok = False
    try:
        env = json.loads(local).get('env')
        py, hm = env.get('STASYS_PY'), env.get('STASYS_HOME')
        env_ok = (isinstance(py, str) and bool(py.strip()) and isinstance(hm, str)
                  and os.path.isfile(os.path.join(hm, 'server.py')))
    except Exception:
        env_ok = False
    hook = (CONNECT_HOOK_MARK in local
            or CONNECT_HOOK_MARK in _read_small(os.path.join(proj_claude, 'settings.json'))
            or CONNECT_HOOK_MARK in _read_small(os.path.join(home, 'settings.json')))
    try:
        seen = active_view(dirpath).get('pulse') != 'never'
    except Exception:
        seen = False
    return {'engine': APP_VERSION, 'helpersMissing': helpers_missing(), 'guide': guide,
            'guideVersion': gver, 'instructions': bool(instructions), 'skills': bool(skills),
            'machine': bool(env_ok and hook), 'hookSeen': bool(seen)}


def connect_view(dirpath):
    project = os.path.basename(os.path.abspath(dirpath))
    out = connect_state(connect_facts(dirpath))
    out['project'] = project
    out['version'] = APP_VERSION
    out['prompt'] = connect_prompt(connect_here(), connect_ref(dirpath))
    return out


def connect_ref(dirpath):
    """How the pasted command names the project: by its FOLDER, in full. The other doors
    take a bare id and look it up under the projects root, which is right for a person
    typing; but this sentence is generated for one specific folder, and a command-line run
    whose projects root differs from the app's (an env override, a second copy of Stasys)
    would otherwise answer 'bad project' to a command the board itself handed out."""
    return os.path.abspath(dirpath).replace('\\', '/')


def connect_target(arg):
    """The project `--connect` was pointed at. A bare name is an id under the projects
    root, exactly like --patch. Anything with a slash in it is a folder path, and must
    already BE a trackable project - never created, same test tracked_project_dir applies."""
    arg = str(arg or '')
    if '/' not in arg and '\\' not in arg:
        return tracked_project_dir(arg)
    d = os.path.abspath(arg)
    if not os.path.isdir(d) or not os.path.isdir(sessions_dir_of(d, read_config(d))):
        return None
    return d


def connect_now(dirpath):
    """The explicit Connect (the board's button, `--connect`): make sure the helpers are
    here, write the project's copies, and answer with the checklist."""
    heal = ensure_helpers()                 # a no-op unless something is missing
    written = []
    if heal.get('ok'):
        written, _err = connect_write(dirpath)
        _CONNECT_CHECKED.discard(os.path.normcase(os.path.abspath(dirpath)))
    view = connect_view(dirpath)
    view['wrote'] = written
    if not heal.get('ok'):
        if heal.get('reason') == 'update-first':
            view['problem'] = ('A newer Stasys is available. Click Update & restart, then '
                               'Connect Claude again.')
        else:
            view['problem'] = ('Stasys could not fetch its helper files ('
                               + str(heal.get('reason') or 'unknown') + '). Check the internet '
                               'connection and try again.')
    return view


# ---- HTTP handler ----
class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def _send(self, code, body_bytes, ctype):
        self.send_response(code)
        self.send_header('Content-Type', ctype)
        self.send_header('Cache-Control', 'no-store')
        if HOST_MODE:
            # keep the access token out of any outbound Referer, and hand the board a
            # SameSite cookie so target=_blank navigations (record/doc links) authenticate.
            self.send_header('Referrer-Policy', 'no-referrer')
            for ck in getattr(self, '_set_cookies', ()):
                self.send_header('Set-Cookie', ck)
        self.send_header('Content-Length', str(len(body_bytes)))
        self.end_headers()
        try:
            self.wfile.write(body_bytes)
        except (BrokenPipeError, ConnectionResetError):
            pass

    # ---- host-mode network safety (no-ops unless HOST_MODE) ----
    def _client_is_loopback(self):
        ip = (self.client_address[0] if self.client_address else '') or ''
        return ip in ('127.0.0.1', '::1') or ip.startswith('127.')

    def _host_header_ok(self):
        """Anti-DNS-rebind: the Host must name one of our own addresses, not a
        foreign domain pointed at our IP."""
        if not HOST_MODE:
            return True
        host = (self.headers.get('Host') or '').rsplit(':', 1)[0].strip().strip('[]').lower()
        return host in HOST_ALLOW

    def _supplied_token(self):
        h = self.headers.get('Authorization') or ''
        if h.startswith('Bearer '):
            return h[7:].strip()
        ck = self.headers.get('Cookie') or ''
        for part in ck.split(';'):
            k, _, v = part.strip().partition('=')
            if k == 'stasys_token' and v:
                return v.strip()
        return parse_qs(urlparse(self.path).query).get('token', [''])[0]   # bootstrap only

    def _auth_ok(self):
        """In host mode, REMOTE requests need the token; the host machine (loopback)
        is trusted and unauthenticated (so its own board works exactly as today)."""
        if not HOST_MODE or self._client_is_loopback():
            return True
        tok = self._supplied_token()
        return bool(tok) and hmac.compare_digest(tok, ACCESS_TOKEN)

    def _api_blocked(self, p):
        """Gate for /api/* in host mode: Host allowlist + token. Sends the error and
        returns True when the request must be refused; returns False when it may pass."""
        if not HOST_MODE:
            return False
        if not self._host_header_ok():
            self._text(403, 'bad host')
            return True
        if not self._auth_ok():
            time.sleep(0.3)                    # mild brute-force friction; entropy carries it
            self._json(401, {'error': 'unauthorized - open this board with a Connect link from the host'})
            return True
        return False

    def _host_only(self):
        """True (and sends 403) if a host-mode request to a host-only endpoint came
        from a REMOTE device. apply-update / new-project are never remote-triggerable."""
        if HOST_MODE and not self._client_is_loopback():
            self._json(403, {'error': 'this action can only be run on the host machine'})
            return True
        return False

    def _json(self, code, obj):
        self._send(code, json.dumps(obj).encode('utf-8'), 'application/json; charset=utf-8')

    def _text(self, code, text, ctype='text/plain'):
        body = text if isinstance(text, bytes) else text.encode('utf-8')
        self._send(code, body, ctype + '; charset=utf-8')

    def _serve_board(self):
        try:
            with open(os.path.join(ENGINE_DIR, 'board.html'), 'rb') as f:
                self._text(200, f.read(), 'text/html')
        except Exception:
            self._text(500, 'board.html not found next to server.py')

    def _serve_icon(self, p):
        # The board declares these as its favicon; an Edge --app window uses it as the
        # window/taskbar icon, so Stasys shows its own icon instead of Edge's.
        name, ctype = (('Stasys_Icon.png', 'image/png') if p.endswith('.png')
                       else ('Stasys.ico', 'image/x-icon'))
        try:
            with open(os.path.join(ENGINE_DIR, name), 'rb') as f:
                self._send(200, f.read(), ctype)
        except Exception:
            self._text(404, 'icon not found')

    def _serve_record(self, proj, fname):
        d = project_dir(proj)
        if not d:
            return self._text(400, 'bad project')
        if not re.match(r'^[\w.\- ]+\.md$', fname or '', re.I):
            return self._text(400, 'bad file')
        sd = os.path.abspath(sessions_dir_of(d, read_config(d)))
        path_ = os.path.abspath(os.path.join(sd, fname))
        if path_ != os.path.join(sd, fname):
            return self._text(400, 'bad path')
        try:
            with open(path_, 'r', encoding='utf-8', errors='replace') as f:
                self._text(200, f.read(), 'text/markdown')
        except Exception:
            self._text(404, 'not found')

    def _serve_doc(self, proj, relpath):
        d = project_dir(proj)
        if not d:
            return self._text(400, 'bad project')
        allow = {dd['path'] for dd in core_docs(d, read_config(d))}
        rel = _rel_ok(relpath)
        if not rel or rel not in allow:
            return self._text(400, 'not a core doc')
        full = os.path.abspath(os.path.join(d, rel.replace('/', os.sep)))
        if os.path.commonpath([full, os.path.abspath(d)]) != os.path.abspath(d):
            return self._text(400, 'bad path')
        try:
            with open(full, 'r', encoding='utf-8', errors='replace') as f:
                self._text(200, f.read(), 'text/markdown')
        except Exception:
            self._text(404, 'not found')

    def do_GET(self):
        u = urlparse(self.path)
        p = u.path
        q = parse_qs(u.query)
        proj = q.get('project', [None])[0]
        try:
            if HOST_MODE and not self._host_header_ok():
                return self._text(403, 'bad host')
            if p in ('/', '/board.html'):
                # hand a valid client (or the loopback host) the SameSite cookie so
                # in-page navigations (record/doc links) carry the token automatically.
                if HOST_MODE and self._auth_ok():
                    self._set_cookies = ['stasys_token=%s; Path=/; SameSite=Strict' % ACCESS_TOKEN]
                return self._serve_board()
            if p in ('/app-icon.png', '/favicon.ico'):
                return self._serve_icon(p)
            if p == '/api/host-info':                 # loopback-only: never hand the token to a remote
                if not self._client_is_loopback():
                    return self._json(403, {'error': 'loopback only'})
                return self._json(200, host_info(self.server.server_address[1]))
            if p.startswith('/api/') and self._api_blocked(p):
                return
            if p == '/api/version':
                return self._json(200, {'name': APP_NAME, 'version': APP_VERSION})
            if p in ('/api/help', '/api'):
                # Discovery. Deliberately answers on BOTH paths and needs no project:
                # a caller looking for the contract should not also have to guess the
                # URL it lives at (v0.43).
                return self._json(200, patch_help())
            if p == '/api/update-check':
                return self._json(200, update_check())
            if p == '/api/projects':
                projects, unlisted = survey_projects()
                # `unlisted` (v0.65): registered folders that could not be shown, and why
                return self._json(200, {'root': ROOT, 'projects': projects, 'unlisted': unlisted})
            if p == '/api/sessions':
                d = project_dir(proj)
                if not d:
                    return self._json(400, {'error': 'bad project'})
                cfg = read_config(d)
                tracks, order = resolve_tracks(cfg)
                sessions = constrain_tracks(read_sessions(d, cfg), order)
                return self._json(200, {'tracks': tracks, 'order': order,
                                        'config': cfg, 'sessions': sessions})
            if p == '/api/state':
                d = project_dir(proj)
                if not d:
                    return self._json(400, {'error': 'bad project'})
                state, serr = read_state(d)
                if serr:           # say so loudly - never hand back an empty backlog we didn't read
                    return self._json(409, state_error_body(d, serr))
                sync_deferred(d)   # keep DEFERRED.md current with external state.json edits
                return self._json(200, state)
            if p == '/api/state/patch':
                # write-only door; answer the same 405 the Node twin does rather than a 404
                return self._json(405, {'error': 'method not allowed',
                                        'detail': 'POST or PUT to this path; GET /api/help '
                                                  'describes the ops',
                                        'help': '/api/help'})
            if p == '/api/docs':
                d = project_dir(proj)
                if not d:
                    return self._json(400, {'error': 'bad project'})
                cfg = read_config(d)
                return self._json(200, read_docs(d, cfg, read_sessions(d, cfg)))
            if p == '/api/activity':
                d = project_dir(proj)
                if not d:
                    return self._json(400, {'error': 'bad project'})
                return self._json(200, project_activity(d, read_config(d)))
            if p == '/api/active':
                d = project_dir(proj)
                if not d:
                    return self._json(400, {'error': 'bad project'})
                return self._json(200, active_view(d))
            if p == '/api/poll':
                d = project_dir(proj)
                if not d:
                    return self._json(400, {'error': 'bad project'})
                sync_deferred(d)   # regenerate DEFERRED.md within one poll of any state.json change
                try:
                    connect_refresh(d)   # a connected project's guide follows the engine (v0.64)
                except Exception:
                    pass                 # best-effort: a guide must never break the poll
                return self._json(200, fingerprint(d, read_config(d)))
            if p == '/api/connect':
                # Connect Claude (v0.64), the read half: the checklist + the sentence to paste.
                # LOOPBACK-ONLY in host mode - the sentence carries THIS machine's paths, which
                # mean nothing on another device and are nobody else's business.
                if self._host_only():
                    return
                d = tracked_project_dir(proj)
                if not d:
                    return self._json(400, {'error': 'bad project'})
                return self._json(200, connect_view(d))
            if p == '/api/record':
                return self._serve_record(proj, q.get('file', [''])[0])
            if p == '/api/doc':
                return self._serve_doc(proj, q.get('path', [''])[0])
            return self._text(404, 'not found')
        except Exception as e:
            self._json(500, {'error': str(e)})

    def _origin_ok(self):
        """CSRF guard for state-changing requests: accept a write only if its
        browser Origin/Referer is this same localhost server. Browsers always
        attach Origin on cross-site writes and a page cannot forge it, so this
        blocks a malicious site (or a DNS-rebind) from POSTing to our localhost
        port. Non-browser clients (no Origin and no Referer) are allowed - they
        aren't a CSRF vector."""
        origin = self.headers.get('Origin') or self.headers.get('Referer')
        if not origin:
            return True
        try:
            u = urlparse(origin)
        except Exception:
            return False
        host = (u.hostname or '').lower()
        # localhost always; in host mode also this machine's own (tailnet/LAN) address,
        # so a token-authenticated remote browser's same-origin write is accepted.
        allowed = host in ('localhost', '127.0.0.1', '::1') or (HOST_MODE and host in HOST_ALLOW)
        if not allowed:
            return False
        return u.port is None or u.port == self.server.server_address[1]

    def do_PUT(self):
        u = urlparse(self.path)
        if self._api_blocked(u.path):          # host mode: Host allowlist + token (no-op on localhost)
            return
        if u.path == '/api/apply-update':
            # Trigger the updater (board "Update & restart" button). LOOPBACK-ONLY in
            # host mode - a remote device can never make the host download/apply/restart.
            # Runs apply_update INLINE (no child process to orphan when the app restarts);
            # signature-gated + fail-closed, so only a properly signed release applies.
            if self._host_only():
                return
            if not self._origin_ok():
                return self._json(403, {'error': 'cross-origin write rejected'})
            res = apply_update('')
            return self._json(200 if res.get('applied') else 400, res)
        if u.path == '/api/new-project':
            if self._host_only():              # scaffolding is loopback-only in host mode
                return
            if not self._origin_ok():
                return self._json(403, {'error': 'cross-origin write rejected'})
            try:
                ln = int(self.headers.get('Content-Length') or 0)
                raw = self.rfile.read(ln) if ln else b''
                body = json.loads(raw.decode('utf-8') or '{}')
            except Exception:
                return self._json(400, {'error': 'bad json'})
            if not isinstance(body, dict):
                return self._json(400, {'error': 'bad json'})
            # {path}: the folder the person picked IS the project (v0.65). {name, location}
            # still works - a name inside a location - and is what the suites and older callers send.
            if body.get('path'):
                res = new_project_at(body.get('path'))
            else:
                res = new_project(body.get('name'), body.get('location'))
            return self._json(200 if res.get('ok') else 400, res)
        if u.path in ('/api/browse', '/api/forget-project', '/api/pick-folder'):
            # v0.65. /api/pick-folder opens the Windows folder window; /api/browse lists the
            # FOLDERS in a folder (what the box asks about the folder that was picked, and the
            # stand-in picker where there is no Windows window);
            # /api/forget-project drops a registered folder from this computer's list (the
            # folder itself is never touched). Both loopback-only in host mode - they are
            # about THIS machine's disk and THIS machine's settings - and both POST behind
            # the origin guard: a web page must not be able to read a directory listing out
            # of a local server by rebinding a name to it.
            if self._host_only():
                return
            if not self._origin_ok():
                return self._json(403, {'error': 'cross-origin request rejected'})
            try:
                ln = int(self.headers.get('Content-Length') or 0)
                body = json.loads(self.rfile.read(ln).decode('utf-8') or '{}') if ln else {}
            except Exception:
                return self._json(400, {'error': 'bad json'})
            if not isinstance(body, dict):
                return self._json(400, {'error': 'bad json'})
            if u.path == '/api/browse':
                return self._json(200, browse_dirs(body.get('path')))
            if u.path == '/api/pick-folder':
                # opens the Windows folder window ON THIS MACHINE and waits for the answer;
                # the server is threaded, so the board keeps polling meanwhile
                return self._json(200, pick_folder(body.get('start') or ''))
            n = forget_extra(body.get('path') or '')
            return self._json(200, {'ok': True, 'forgotten': n})
        if u.path == '/api/connect':
            # Connect Claude (v0.64), the write half: put the guide and the command bodies in
            # the project's own .tracker/claude/ - and nowhere else. Loopback-only and
            # origin-guarded like the scaffolder; the project must already exist.
            if self._host_only():
                return
            if not self._origin_ok():
                return self._json(403, {'error': 'cross-origin write rejected'})
            d = tracked_project_dir(parse_qs(u.query).get('project', [None])[0])
            if not d:
                return self._json(400, {'error': 'bad project'})
            try:
                return self._json(200, connect_now(d))
            except Exception as e:
                return self._json(500, {'error': str(e)})
        if u.path == '/api/set-host-mode':
            # Toggle sharing on/off from the board (loopback-only) so the user never
            # hand-edits settings.json. Takes effect on the next restart (a restart is
            # what binds/unbinds the network) - the board triggers that via the host.
            if self._host_only():
                return
            if not self._origin_ok():
                return self._json(403, {'error': 'cross-origin write rejected'})
            try:
                ln = int(self.headers.get('Content-Length') or 0)
                body = json.loads(self.rfile.read(ln).decode('utf-8') or '{}') if ln else {}
            except Exception:
                return self._json(400, {'error': 'bad json'})
            on = bool(body.get('on'))
            cfg = _read_settings()
            cfg['hostMode'] = on
            if on and not (isinstance(cfg.get('accessToken'), str) and cfg.get('accessToken', '').strip()):
                cfg['accessToken'] = secrets.token_urlsafe(32)
            ok = _write_settings(cfg)
            return self._json(200 if ok else 500, {'ok': ok, 'hostMode': on, 'restartRequired': True})
        if u.path == '/api/active':
            # Claim / release the in-progress card (v0.58). Origin-guarded like every other
            # write. Body: {"id": 14} to claim, {"id": null} to release, optional "by"/"note".
            if not self._origin_ok():
                return self._json(403, {'error': 'cross-origin write rejected'})
            d = tracked_project_dir(parse_qs(u.query).get('project', [None])[0])
            if not d:
                return self._json(400, {'error': 'bad project'})
            try:
                ln = int(self.headers.get('Content-Length') or 0)
                body = json.loads(self.rfile.read(ln).decode('utf-8') or '{}') if ln else {}
            except Exception:
                return self._json(400, {'error': 'bad json'})
            if not isinstance(body, dict):
                return self._json(400, {'error': 'bad json'})
            if body.get('session'):     # a hook beat, not a claim - liveness only
                return self._json(200, touch_session(d, body.get('event') or 'beat',
                                                     body.get('session')))
            try:
                tracks, order = resolve_tracks(read_config(d))
                view, aerr = set_active(d, body.get('id'), body.get('by') or '',
                                        body.get('note') or '', tracks, order)
            except Exception as e:
                return self._json(500, {'error': str(e)})
            if aerr:
                return self._json(409, {'error': 'active-rejected', 'detail': aerr})
            return self._json(200, view)
        if u.path == '/api/state/patch':
            # The narrow write door: one card at a time, merged into what's on disk right
            # now. Same origin guard as every other write - and note a non-browser caller
            # (no Origin/Referer) is already allowed by it, so a local script needs no
            # special-casing and the guard is not weakened to let one in.
            if not self._origin_ok():
                return self._json(403, {'error': 'cross-origin write rejected'})
            d = tracked_project_dir(parse_qs(u.query).get('project', [None])[0])
            if not d:      # must already be a real project - never invent one from a typo
                return self._json(400, {'error': 'bad project'})
            try:
                ln = int(self.headers.get('Content-Length') or 0)
                if ln > BODY_MAX:
                    return self._json(400, {'error': 'body too large'})
                body = json.loads(self.rfile.read(ln).decode('utf-8') or '{}') if ln else {}
            except Exception:
                return self._json(400, {'error': 'bad json'})
            ops = body.get('ops') if isinstance(body, dict) and 'ops' in body else body
            try:
                tracks, order = resolve_tracks(read_config(d))
                res, perr, code = apply_state_patch(d, ops, tracks, order)
            except Exception as e:
                return self._json(500, {'error': str(e)})
            if perr:   # nothing was written - say why, and never pretend it landed
                # `help` closes the discovery loop: the one moment a caller is proven to be
                # reading this endpoint's output is when it has just got something wrong.
                return self._json(code, {'error': 'patch-rejected', 'detail': perr,
                                         'help': '/api/help'})
            return self._json(200, res)
        if u.path != '/api/state':
            return self._text(404, 'not found')
        if not self._origin_ok():
            return self._json(403, {'error': 'cross-origin write rejected'})
        d = project_dir(parse_qs(u.query).get('project', [None])[0])
        if not d:
            return self._json(400, {'error': 'bad project'})
        try:
            ln = int(self.headers.get('Content-Length') or 0)
            if ln > BODY_MAX:
                return self._json(400, {'error': 'body too large'})
            raw = self.rfile.read(ln) if ln else b''
            incoming = json.loads(raw.decode('utf-8') or '{}')
        except Exception:
            return self._json(400, {'error': 'bad json'})
        try:
            cur, serr = read_state(d)
            if serr:   # refuse to overwrite a backlog we couldn't read - the board may be showing
                       # nothing at all, and saving that would make the damage permanent
                return self._json(409, state_error_body(d, serr))
            # THE STALE-SAVE GUARD. This endpoint replaces the WHOLE backlog, so a client that
            # built its copy before someone else wrote would silently erase that write. A client
            # that quotes the rev it loaded gets told instead: 409, plus the current state, so it
            # can merge its own edits onto it and try again.
            # A client that sends NO rev is still allowed through - an older board must keep
            # working against a newer engine, and refusing it would break saving outright rather
            # than protect anything. The rev is opt-in on the client and enforced once offered.
            want = incoming.get('rev') if isinstance(incoming, dict) else None
            if want and want != cur.get('rev'):
                return self._json(409, {
                    'error': 'state-stale',
                    'detail': 'the backlog changed on disk since you loaded it',
                    'rev': cur.get('rev'), 'yourRev': want, 'state': cur})
            tracks, order = resolve_tracks(read_config(d))
            return self._json(200, {'ok': True, 'state': write_state(d, incoming, tracks, order)})
        except FieldTooLong as e:      # nothing written; the board keeps the text and says why
            return self._json(400, e.body())
        except Exception as e:
            return self._json(500, {'error': str(e)})

    do_POST = do_PUT


def open_browser(url):
    try:
        webbrowser.open(url)
    except Exception:
        pass


def main():
    # CLI: `py server.py --apply-update [<manifest-url-or-path>]` runs the updater and
    # exits WITHOUT serving (a separate process from the running app, matching the future
    # "spawn updater, then restart" flow). Source defaults to the configured update feed.
    if sys.argv[1:2] == ['--apply-update']:
        src = sys.argv[2] if len(sys.argv) > 2 else ''
        res = apply_update(src)
        print(json.dumps(res, indent=2))
        sys.exit(0 if res.get('applied') else 1)

    # CLI: `py server.py --patch <project> [ops.json]` (omit the file to read stdin) applies a
    # one-card patch and exits without serving. This is the door for when Stasys ISN'T RUNNING
    # (card #23) - and it deliberately calls the SAME apply_state_patch the HTTP endpoint calls,
    # so there is one implementation of "merge this change into the backlog" rather than two
    # that can drift. Exit 0 = written, 1 = rejected (nothing written), 2 = bad invocation.
    if sys.argv[1:2] == ['--patch']:
        pid = sys.argv[2] if len(sys.argv) > 2 else ''
        d = tracked_project_dir(pid)
        if not d:
            print(json.dumps({'ok': False, 'error': 'bad project %r (looking under %s)' % (pid, ROOT)}, indent=2))
            sys.exit(2)
        src = sys.argv[3] if len(sys.argv) > 3 else ''
        if src:
            try:
                with open(src, 'r', encoding='utf-8') as f:
                    raw = f.read()
            except Exception as e:
                print(json.dumps({'ok': False, 'error': "couldn't read %r (%s)" % (src, e.__class__.__name__)}, indent=2))
                sys.exit(2)
        else:
            raw = sys.stdin.read()
        try:
            body = json.loads(raw or '{}')
        except ValueError as e:
            print(json.dumps({'ok': False, 'error': 'bad json (%s)' % e}, indent=2))
            sys.exit(2)
        ops = body.get('ops') if isinstance(body, dict) and 'ops' in body else body
        tracks, order = resolve_tracks(read_config(d))
        res, perr, _code = apply_state_patch(d, ops, tracks, order)
        if perr:
            print(json.dumps({'ok': False, 'error': perr}, indent=2))
            sys.exit(1)
        print(json.dumps({'ok': True, 'applied': res['applied']}, indent=2))
        sys.exit(0)

    # CLI: `py server.py --merge <base.json> <mine.json> <theirs.json> [--out <merged.json>]`
    # (v0.63). Merges two copies of one board that were changed on two machines, card by
    # card, and exits without serving. Unlike every door above it takes FILES, not a project:
    # it reads those three, writes --out, and never touches a project's .tracker/ - where the
    # result goes is the caller's decision. No --out = a dry run that only reports.
    # Exit 0 = merged, 1 = refused (nothing written), 2 = bad invocation.
    if sys.argv[1:2] == ['--merge']:
        args = sys.argv[2:]
        out_path = None
        usage = ('usage: py server.py --merge <base.json> <mine.json> <theirs.json> '
                 '[--out <merged.json>]')
        if '--out' in args:
            i = args.index('--out')
            if i + 1 >= len(args):
                print(json.dumps({'ok': False, 'written': False, 'error': usage}, indent=2))
                sys.exit(2)
            out_path = args[i + 1]
            del args[i:i + 2]
        if len(args) != 3:
            print(json.dumps({'ok': False, 'written': False, 'error': usage}, indent=2))
            sys.exit(2)
        res, merr = merge_files(args[0], args[1], args[2], out_path)
        if merr:
            print(json.dumps({'ok': False, 'written': False, 'error': merr}, indent=2))
            sys.exit(1)
        print(json.dumps(res, indent=2))
        sys.exit(0)

    # CLI: `py server.py --snapshots <project>` lists the dated snapshots, and
    # `py server.py --restore-snapshot <project> <YYYY-MM-DD>` puts one back. A history
    # you cannot get back out of is not a history - that is the sentence card #262 ends
    # on - and gunzipping a file by hand is not a door a non-technical user has.
    if sys.argv[1:2] in (['--snapshots'], ['--restore-snapshot']):
        mode = sys.argv[1]
        pid = sys.argv[2] if len(sys.argv) > 2 else ''
        d = tracked_project_dir(pid)
        if not d:
            print(json.dumps({'ok': False, 'error': 'bad project %r (looking under %s)' % (pid, ROOT)}, indent=2))
            sys.exit(2)
        if mode == '--snapshots':
            rows = []
            for e in snap_list(d):
                txt = snap_read(d, e['date'])
                cards = None
                if txt is not None:
                    try:
                        cards = len(json.loads(txt).get('items') or [])
                    except Exception:
                        cards = None
                rows.append({'date': e['date'], 'bytes': e['size'], 'cards': cards,
                             'readsBack': txt is not None})
            total = sum(r['bytes'] for r in rows)
            print(json.dumps({'ok': True, 'project': os.path.basename(d),
                              'dir': snap_dir(d), 'count': len(rows),
                              'totalBytes': total, 'budgetBytes': snap_opts(read_config(d))['budget'],
                              'snapshots': rows}, indent=2))
            sys.exit(0)
        date = sys.argv[3] if len(sys.argv) > 3 else ''
        tracks, order = resolve_tracks(read_config(d))
        st, err = restore_snapshot(d, date, tracks, order)
        if err:
            print(json.dumps({'ok': False, 'error': err,
                              'available': [e['date'] for e in snap_list(d)]}, indent=2))
            sys.exit(1)
        print(json.dumps({'ok': True, 'restored': date, 'items': len(st.get('items') or []),
                          'note': 'the content this replaced is in .tracker/state.json.bak'}, indent=2))
        sys.exit(0)

    # CLI: the in-progress marker (v0.58). Works with the app shut, exactly like --patch,
    # because a session very often starts before Stasys is open.
    #   py server.py --active <project>          show what is claimed
    #   py server.py --active <project> 14       claim card #14 (un-parks it if parked)
    #   py server.py --active <project> none     release
    #   py server.py --session <project> start|beat|end [session-id]     liveness only
    if sys.argv[1:2] in (['--active'], ['--session']):
        mode = sys.argv[1]
        pid = sys.argv[2] if len(sys.argv) > 2 else ''
        d = tracked_project_dir(pid)
        if not d:
            print(json.dumps({'ok': False, 'error': 'bad project %r (looking under %s)' % (pid, ROOT)}, indent=2))
            sys.exit(2)
        if mode == '--session':
            ev = sys.argv[3] if len(sys.argv) > 3 else 'beat'
            sid = sys.argv[4] if len(sys.argv) > 4 else ''
            print(json.dumps({'ok': True, 'active': touch_session(d, ev, sid)}, indent=2))
            sys.exit(0)
        if len(sys.argv) <= 3:
            print(json.dumps({'ok': True, 'active': active_view(d)}, indent=2))
            sys.exit(0)
        arg = sys.argv[3].strip().lstrip('#')
        want = 0 if arg.lower() in ('none', 'off', 'clear', '0', '-') else _to_int(arg)
        if arg and not want and arg.lower() not in ('none', 'off', 'clear', '0', '-'):
            print(json.dumps({'ok': False, 'error': 'not a card id: %r' % sys.argv[3]}, indent=2))
            sys.exit(2)
        tracks, order = resolve_tracks(read_config(d))
        view, aerr = set_active(d, want, sys.argv[4] if len(sys.argv) > 4 else 'claude',
                                sys.argv[5] if len(sys.argv) > 5 else '', tracks, order)
        if aerr:
            print(json.dumps({'ok': False, 'error': aerr}, indent=2))
            sys.exit(1)
        print(json.dumps({'ok': True, 'active': view}, indent=2))
        sys.exit(0)

    # CLI: Connect Claude (v0.64).
    #   py server.py --connect <project>            write the project's .tracker/claude/ copies
    #                                               and PRINT the setup instructions for Claude
    #   py server.py --connect <project> --check    print the checklist as JSON
    # <project> is an id under the projects root OR the project's folder path - the board's
    # sentence always gives the path (see connect_ref). The first form is what that sentence
    # tells Claude to run; the second is how Claude proves its own work.
    # Exit 0 = done / connected, 1 = not yet, 2 = bad invocation.
    if sys.argv[1:2] == ['--connect']:
        pid = sys.argv[2] if len(sys.argv) > 2 else ''
        d = connect_target(pid)
        if not d:
            print(json.dumps({'ok': False, 'error': 'bad project %r - not a tracked project folder, '
                              'and no project by that name under %s' % (pid, ROOT)}, indent=2))
            sys.exit(2)
        if '--check' in sys.argv[3:]:
            view = connect_view(d)
            print(json.dumps({'ok': view['connected'], 'connect': view}, indent=2))
            sys.exit(0 if view['connected'] else 1)
        view = connect_now(d)
        if not view['ready']:
            print(json.dumps({'ok': False, 'error': view.get('problem') or view['steps'][0]['text']}, indent=2))
            sys.exit(1)
        text = connect_setup_text(connect_here(), connect_ref(d), APP_VERSION)
        try:
            sys.stdout.buffer.write(text.encode('utf-8'))   # a path may hold non-cp1252 letters
            sys.stdout.buffer.flush()
        except Exception:
            print(text)
        sys.exit(0)

    # Clear out any app-shell image a previous update renamed aside; by now the process
    # that held it has exited, so this is where the old .exe/.dll actually goes away.
    sweep_stale_updates()

    # An engine installed by a pre-v0.64 updater arrives without its helper files (that
    # updater has never heard of them). Fetch them from this version's own signed package,
    # in the background so a slow network never delays the board. A no-op on every healthy
    # install - it does not touch the network unless something is actually missing.
    if helpers_missing():
        threading.Thread(target=ensure_helpers, daemon=True).start()

    # Host mode binds the network so other devices (reached privately via Tailscale)
    # can share this board; off by default it stays localhost-only.
    bind_ip = '0.0.0.0' if HOST_MODE else '127.0.0.1'
    httpd = None
    port = None
    for candidate in PORTS:
        try:
            httpd = ThreadingHTTPServer((bind_ip, candidate), Handler)
            port = candidate
            break
        except OSError:
            httpd = None
    if httpd is None:
        print('No free port in ' + ', '.join(str(p) for p in PORTS))
        sys.exit(1)
    url = 'http://localhost:%d' % port
    print()
    print('  Project Tracker is running:  ' + url)
    print('  Serving projects from:       ' + ROOT)
    if HOST_MODE:
        print()
        print('  HOST MODE ON - this board is shared on the network (token-protected).')
        if TAILSCALE_IP:
            print('  Connect from another device:  http://%s:%d/?token=%s' % (TAILSCALE_IP, port, ACCESS_TOKEN))
        else:
            print('  No Tailscale address found - bound to 0.0.0.0 (all interfaces);')
            print('  rely on your firewall. Token: ' + ACCESS_TOKEN)
    print('  Leave this window open. Close it (or press Ctrl+C) to stop.')
    print()
    if not os.environ.get('STASYS_NO_BROWSER'):   # the app launcher opens its own window instead
        threading.Timer(0.6, open_browser, args=(url,)).start()
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print('\nStopping...')
        httpd.shutdown()


if __name__ == '__main__':
    main()
