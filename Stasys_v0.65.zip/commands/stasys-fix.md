---
description: Audit the current project, auto-fix the safe findings, get your sign-off on the rest, then write the result and stamp confirmed docs verified — so both the deep-audit and the Documents panel update.
argument-hint: "[start-dir]  (optional; defaults to the current folder)"
---

# /stasys-fix — audit, fix the safe stuff, sign off on the rest

> CANONICAL SOURCE (version-controlled, shipped with the engine). Installed by the board's Connect Claude — see the bottom.

Builds on `/stasys-audit`. It runs the deep audit, then **remediates** in one invocation: auto-fixes the
low-risk findings, pauses for your approval on the judgment calls, applies what you approve, and writes the
audit so the board flips the fixed ones to "✓ resolved". `/stasys-audit` stays the pure, read-only pass;
this is the opt-in version that also edits docs.

Same engine tool and severity vocab as `/stasys-audit` (its instructions sit beside this file as `stasys-audit.md`). Severity vocab:
**contradiction | staleness | drift | note**.

**How to run the engine tool.** Two environment variables are set on a connected computer (in
`.claude/settings.local.json`, under `env`): `STASYS_PY` (the Python that runs Stasys) and
`STASYS_HOME` (the Stasys folder). The tool is `audit_tool.py` in that folder:

```
Git Bash:    "$STASYS_PY" "$STASYS_HOME/audit_tool.py" <command> ...
PowerShell:  & $env:STASYS_PY "$env:STASYS_HOME/audit_tool.py" <command> ...
```

Below, that is written `AUDIT_TOOL <command> ...`. If the variables are empty, read the two values
from `.claude/settings.local.json` and use them literally; if that file has none, this computer is
not connected - tell the user to click **Connect Claude** on the Stasys board, and stop.

**START dir:** `$ARGUMENTS` if given, else `.`. Replace `.` in the commands below if you were given one.
The deterministic write/merge is the tool's job — **never hand-edit `audit.json`**.

## The triage rule (Balanced)
Sort every finding you observe this run into one of two buckets:

- **AUTO — fix without asking.** ALL must hold:
  - severity is `staleness`, `drift`, or `note` (NEVER `contradiction`);
  - the target doc is a **process / engineering doc** — README, CONTRACT, the dev handoff, changelogs,
    session records — i.e. NOT canonical game-design / creative content;
  - the doc is NOT marked `"protected": true` in `.tracker/config.json`.
- **REVIEW — needs your sign-off.** Everything else: every `contradiction`; anything touching
  **game-design / creative docs** (a world Bible, a mechanics or economy spec, design-intent / rules /
  philosophy / architecture docs, lore); and anything whose `docs[]` entry is `"protected": true`.

Decide "process vs design doc" from what you actually read in Step 2 — judge the document's *role*, don't
just pattern-match the filename. **When in doubt → REVIEW.** Protected always wins: a protected doc is
review regardless of severity.

## Step 1 — audit
1. `AUDIT_TOOL context --start .`
   → `{root, project, configDocs, sessions, latest, priorAudit}`. If it errors with "no .tracker/ found",
   you're not inside a tracked project — tell the user and stop.
2. Read every doc in `configDocs[]` (join `root` + the relative path) and the **latest** session record.
   Also read `root/.tracker/config.json` and note any `docs[]` entry with `"protected": true`.
3. Find the issues (contradiction / staleness / drift / note), reconciling with `priorAudit` the same way
   `/stasys-audit` does: a still-true prior finding keeps its **id**; a brand-new issue has no id; a prior
   finding that no longer reproduces is simply not reported. Hold this list in mind — **don't write yet.**

## Step 2 — triage
Split the findings into AUTO and REVIEW per the rule above. If you found **no** issues at all, tell the
user the project is clean, write nothing, and stop.

## Step 3 — auto-fix the AUTO bucket
For each AUTO finding, apply its `suggestion` with a **minimal, faithful** edit to the named doc — fix
exactly what the finding describes, nothing more. Keep a list of what you changed. In this step never touch
session records, game files, protected docs, or design docs.

## Step 4 — sign-off on the REVIEW bucket
If REVIEW is non-empty, present it as a numbered list. For each: severity, doc, the problem in one line,
and your **proposed fix** (concrete — show the edit you would make). Then **STOP and ask** which to apply
(e.g. "all / these numbers / none / let me adjust one"). Do not edit any REVIEW doc until the user answers.
If REVIEW is empty, skip this step.

## Step 5 — apply approved fixes
Apply exactly the REVIEW fixes the user approved (minimal edits). Anything declined or deferred stays an
open finding.

## Step 6 — stamp the confirmed docs as verified
Record what this pass confirmed so the board's **Documents panel** (the freshness table) reflects it. For
**every** core doc in `configDocs` that has **no open finding left** after steps 3 + 5 (the audit reconciled
it), update its frontmatter:
- set `last_verified:` to **today** (`YYYY-MM-DD`);
- if you **edited that doc's body** this run, also set `last_modified:` to today.

Rules: if the doc has frontmatter but lacks the line, add it; if it has no frontmatter block at all, add a
minimal one (`---` / `last_modified: …` / `last_verified: …` / `---`) at the very top. **Metadata only — never
touch the body in this step.** **Do NOT stamp a doc that still has an open (declined / deferred) finding** —
leave its dates so it stays flagged. This is what turns the Documents table green: that panel computes
current-vs-stale from `last_verified` against `last_modified` / file-time, so a doc you just confirmed should
now read **current**. (A finding that was only about stale frontmatter dates is resolved by this stamp.)

## Step 7 — write the result (one merge-write)
Build a single findings JSON capturing this run:
- findings **still open** (not fixed): status `open`; carry the prior `id` if it was in `priorAudit`, else omit `id`.
- findings you **fixed** this run (auto or approved): include them with `"status": "resolved"`; carry the
  prior `id` if it existed, else omit `id` (so a found-and-fixed issue is still recorded as resolved).
- (Prior findings you never saw this run need no entry — the tool auto-resolves them.)

Save it to `stasys_findings.json`, then:
`AUDIT_TOOL write --start . --in stasys_findings.json`
Then delete the temp file `stasys_findings.json`. The board reflects the new `audit.json` within ~6s.

## Step 8 — report
Tell the user, briefly: what was auto-fixed, what you applied after their approval, which docs you stamped
verified, what's still open (declined / left for later), and that both panels now reflect it. Don't edit
anything further.

---

## Install
Nothing to copy by hand. On the Stasys board, click **Connect Claude** and paste the sentence it
gives you into Claude Code: that installs this command for the project (as a small stub pointing at
`.tracker/claude/`, which Stasys keeps up to date) and sets the two variables above.
