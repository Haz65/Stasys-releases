---
description: Run a Stasys deep audit on the current project and merge-write .tracker/audit.json (the board surfaces it within ~6s).
argument-hint: "[start-dir]  (optional; defaults to the current folder)"
---

# /stasys-audit — close the Stasys audit loop

> CANONICAL SOURCE. This file is version-controlled with the engine and shipped with it; Stasys
> copies it into a connected project's `.tracker/claude/` (see "Install" at the bottom).

You are running the **deep audit** pass for the Stasys (Project Tracker) Truth panel.
It is the out-of-band LLM pass: read the project's canonical docs, check them against the
latest session record (and each other), and **merge-write** the findings into
`.tracker/audit.json` so the board can display them. It runs ONLY when invoked — never bake
it into anything automatic.

The deterministic mechanics (find the project root, resolve the declared docs, read the prior
audit, merge + write valid schema with stable ids) are handled by the engine tool. **Do not
hand-roll `audit.json`** — always go through the tool.

**How to run the engine tool.** Two environment variables are set on a connected computer (in
`.claude/settings.local.json`, under `env`): `STASYS_PY` (the Python that runs Stasys) and
`STASYS_HOME` (the Stasys folder). The tool is `audit_tool.py` in that folder:

```
Git Bash:    "$STASYS_PY" "$STASYS_HOME/audit_tool.py" <command> ...
PowerShell:  & $env:STASYS_PY "$env:STASYS_HOME/audit_tool.py" <command> ...
```

Below, that is written `AUDIT_TOOL <command> ...`. If the variables are empty, read the two values
from `.claude/settings.local.json` and use them literally; if that file has none, this computer is
not connected - tell the user to click **Connect Claude** on the Stasys board, and stop.

**START dir:** use `$ARGUMENTS` if one was passed, otherwise `.` (the current folder). The tool
walks UP from there to the nearest folder containing `.tracker/`. In the commands below, replace
`.` with the argument if you were given one.

## Step 1 — gather context
Run:

```
AUDIT_TOOL context --start .
```

It prints JSON: `{ root, project, sessionsDir, configDocs[], sessions[], latest, priorAudit }`.
- If it errors with **"no .tracker/ found"**, you're not inside a tracked project — tell the user
  to run it from inside the project (or pass the path) and stop.
- `configDocs[]` = the canonical docs to audit (paths are relative to `root`).
- `priorAudit` = the existing `.tracker/audit.json`, or `null` on the first run.

## Step 2 — read the material
Read every file in `configDocs[]` (join `root` + the relative path) and the **latest** session
record (`latest`). If a doc points at others that matter (a spec, a Bible), read those too. Look
for issues in the board's four-word severity vocab:
- **contradiction** — a doc asserts something the session record / another doc / the code shows is false.
- **staleness** — a doc describes an older state than reality (a feature now exists; a step is obsolete).
- **drift** — a doc's stated version or scheme no longer matches the latest session's.
- **note** — a smaller gap worth recording (missing metadata, an ambiguity), not a hard error.

Be specific and conservative: cite both sides of each finding, and don't invent issues to look thorough.

## Step 3 — reconcile with the prior audit (this is the "loop")
For each finding in `priorAudit.findings`:
- **Still true?** Re-report it **with its original `id`** → the tool keeps it `open`.
- **Fixed / no longer reproduces?** **Omit it** → the tool auto-flips any prior finding you don't
  re-report to `resolved`, keeping it on record. (Or include it with `"status":"resolved"` to update
  its wording as it resolves.)
- Already `resolved` and not regressed? Leave it out.

Then add any **new** issues you found (omit `id` — the tool assigns the next one).

## Step 4 — write the findings file
Save this JSON to `stasys_findings.json` in the current folder:

```json
{
  "by": "<your model name> — deep audit pass (/stasys-audit)",
  "summary": "<one sentence: N findings, X open, Y resolved, what you checked>",
  "findings": [
    {
      "id": 5,
      "severity": "contradiction",
      "doc": "CONTRACT.md",
      "refs": ["server.py", "Documentation/SESSIONS/2026-06-16_v0.5_per-project-track-sets.md"],
      "message": "State the conflict concretely, citing both sides.",
      "suggestion": "The smallest fix."
    }
  ]
}
```

Rules: `severity` ∈ contradiction|staleness|drift|note (anything else becomes `note`); `message`
is required; `doc` / `refs` / `suggestion` are recommended; carry `id` ONLY for prior findings you're
re-asserting. `summary` / `scope` / `by` are optional (the tool fills sensible defaults).

## Step 5 — merge-write
Run:

```
AUDIT_TOOL write --start . --in stasys_findings.json
```

It prints the path it wrote and a one-line merge summary (total / open / resolved, new, newly
resolved). Then delete the temp file `stasys_findings.json`.

## Step 6 — report
Tell the user: that the audit ran, the open-vs-resolved counts, the headline findings, and that
the board will show the update within ~6 seconds (no reload) if Stasys is running — otherwise on
next launch. **Do not edit the docs themselves** unless the user asks; this pass only records findings.

---

## Install
Nothing to copy by hand. On the Stasys board, click **Connect Claude** and paste the sentence it
gives you into Claude Code: that installs this command for the project (as a small stub pointing at
`.tracker/claude/`, which Stasys keeps up to date) and sets the two variables above.
