#!/usr/bin/env python
"""Stasys session hook (v0.58) - the LIVENESS half of the in-progress marker.

Claude Code runs this on SessionStart / Stop / SessionEnd. It reads the hook's JSON from
stdin, finds the tracked project by walking up from `cwd` to a `.tracker/` folder, and
updates ONLY the `live` block of that project's `.tracker/active.json`.

It never touches the CLAIM (which card is being worked on). That is deliberate and it is
the whole design: the claim is persistent, because a card claimed last night is still the
card you are on when you sit down in the morning, and an ageing-out claim would delete the
answer at exactly the moment the question gets asked. Liveness is the ephemeral half - it
says whether a session is running *this second*, which is the only thing a hook can
actually know - and the board draws it as a pulse on the gold border rather than as the
border itself. A session that dies without ever reaching SessionEnd therefore stops
pulsing within the half hour while its claim, which is still perfectly true, survives.

Why this is standalone rather than a call into server.py:
  - it must work with Stasys SHUT, which is the usual state when a session starts;
  - importing server.py runs its module-level setup (settings, host mode, a Tailscale
    address lookup), and that is far too much to pay on a hook that fires every turn.
It writes one small file with a temp-and-rename, so it can never leave a half-written
marker behind, and it exits 0 on every path - a hook that can break a session in order to
draw a border on a board would be a spectacularly bad trade.

Install (per project, in .claude/settings.json):

  {"hooks": {
     "SessionStart": [{"hooks": [{"type": "command",
        "command": "py \"<engine>/hooks/stasys_session.py\""}]}],
     "Stop":         [{"hooks": [{"type": "command",
        "command": "py \"<engine>/hooks/stasys_session.py\""}]}],
     "SessionEnd":   [{"hooks": [{"type": "command",
        "command": "py \"<engine>/hooks/stasys_session.py\""}]}]}}

The event is read from the payload's `hook_event_name`, so all three entries run the same
command with no arguments. An explicit `start` / `beat` / `end` argument overrides it,
which is what makes the script testable by hand.
"""
import io
import os
import sys
import json
import time

MAX_UP = 6          # how far to walk up looking for a .tracker/ before giving up


def find_project(start):
    """The nearest ancestor of `start` that holds a .tracker/ folder. A session is
    normally started in the project root, so this usually matches on the first try; the
    walk is for a session started in a subfolder."""
    d = os.path.abspath(start or os.getcwd())
    for _ in range(MAX_UP):
        if os.path.isdir(os.path.join(d, '.tracker')):
            return d
        parent = os.path.dirname(d)
        if parent == d:
            break
        d = parent
    return None


def write_atomic(path, text):
    """Temp-and-rename, so a reader never sees a half-written marker."""
    tmp = path + '.tmp'
    with io.open(tmp, 'w', encoding='utf-8', newline='\n') as f:
        f.write(text)
    os.replace(tmp, path)


def main():
    try:
        raw = sys.stdin.read()
    except Exception:
        raw = ''
    try:
        payload = json.loads(raw or '{}')
    except Exception:
        # Content arrived and did NOT parse. Do nothing at all rather than fall back to
        # os.getcwd(): the fallback is only correct when there was no payload (a hand-run
        # test), and on a real-but-garbled one it would mark a DIFFERENT project's board
        # live - the wrong card lit on the wrong board, which is worse than no light.
        return
    if not isinstance(payload, dict):
        return

    # An explicit argument wins, so the script can be exercised by hand; otherwise the
    # event comes from the payload, which is what lets all three hooks share one command.
    event = (sys.argv[1] if len(sys.argv) > 1 else '').lower()
    if not event:
        name = str(payload.get('hook_event_name') or '')
        event = {'SessionStart': 'start', 'SessionEnd': 'end'}.get(name, 'beat')

    root = find_project(payload.get('cwd') or os.getcwd())
    if not root:
        return                                  # not a tracked project: nothing to say

    path = os.path.join(root, '.tracker', 'active.json')
    try:
        with io.open(path, 'r', encoding='utf-8') as f:
            d = json.load(f)
        if not isinstance(d, dict):
            d = {}
    except Exception:
        d = {}                                  # no marker yet, or a damaged one

    sid = str(payload.get('session_id') or '')
    live = d.get('live') if isinstance(d.get('live'), dict) else {}
    now = int(time.time() * 1000)

    if event == 'end':
        # Only the session that owns the marker may clear it. Two sessions open on one
        # project is rare, but the first to exit must not blank the second one's pulse.
        if sid and live.get('session') and live.get('session') != sid:
            return
        d['live'] = {}
    else:
        if event == 'start' or live.get('session') != sid:
            live = {'session': sid, 'startedAt': now}
        live['at'] = now
        d['live'] = live

    write_atomic(path, json.dumps(d, indent=2, ensure_ascii=False))


if __name__ == '__main__':
    try:
        main()
    except Exception:
        pass          # a hook must never be the reason a session fails to start or stop
    sys.exit(0)
