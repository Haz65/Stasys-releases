#!/usr/bin/env python3
# Project Tracker - local engine server (Python twin of server.js)
# Standard library only. Run with:  py server.py   (or python server.py)
# Serves the board at http://localhost:<port> and reads/writes each project's
# own  .tracker/  folder. The tool only ever writes inside .tracker/.

import os
import re
import io
import sys
import json
import hmac
import shutil
import base64
import hashlib
import time
import socket
import zipfile
import secrets
import datetime
import threading
import webbrowser
from urllib.parse import urlparse, parse_qs
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

ENGINE_DIR = os.path.dirname(os.path.abspath(__file__))   # the app/engine folder

def _settings_path():
    """Per-user settings file: %APPDATA%\\Stasys\\settings.json on Windows."""
    base = (os.environ.get('APPDATA') or os.environ.get('XDG_CONFIG_HOME')
            or os.path.join(os.path.expanduser('~'), '.config'))
    return os.path.join(base, 'Stasys', 'settings.json')

def _read_settings():
    """The whole per-user settings dict (BOM-tolerant), {} on any problem."""
    try:
        with open(_settings_path(), 'r', encoding='utf-8-sig') as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}

def _write_settings(d):
    """Persist the settings dict (UTF-8, no BOM, preserving other keys). The engine
    writes here only for its OWN config (e.g. the host-mode access token) — never a
    tracked project."""
    try:
        os.makedirs(os.path.dirname(_settings_path()), exist_ok=True)
        with open(_settings_path(), 'w', encoding='utf-8') as f:
            json.dump(d, f, indent=4)
        return True
    except Exception:
        return False

def _saved_projects_root():
    r = _read_settings().get('projectsRoot')
    return r if isinstance(r, str) and r.strip() else None

# ---- host mode (live multi-board sync, backlog #16/#18) -------------------------
# OFF by default: the server binds 127.0.0.1 and needs no auth (the safe local app).
# When ON (opt-in), it binds the network so other devices (reached privately via
# Tailscale) can share this one board, behind a mandatory access token. The host
# machine itself (loopback) stays trusted/unauthenticated; only REMOTE requests need
# the token, and they can only read/write the backlog - never apply updates or
# scaffold projects (those are loopback-only). See the v0.31 session record.
def _host_mode_enabled():
    env = os.environ.get('STASYS_HOST')
    if env is not None:
        return env.strip().lower() not in ('', '0', 'false', 'no', 'off')
    return bool(_read_settings().get('hostMode'))

def _resolve_access_token():
    """The shared secret remote devices must present. Precedence: STASYS_HOST_TOKEN
    env -> settings.json 'accessToken' -> generate a strong one and persist it."""
    env = os.environ.get('STASYS_HOST_TOKEN')
    if env and env.strip():
        return env.strip()
    s = _read_settings()
    tok = s.get('accessToken')
    if isinstance(tok, str) and tok.strip():
        return tok.strip()
    tok = secrets.token_urlsafe(32)
    s['accessToken'] = tok
    _write_settings(s)
    return tok

def _own_ipv4s():
    """Best-effort set of this machine's own IPv4 addresses (incl. the Tailscale
    100.64.0.0/10 one and the LAN IP) — used to display the connect link and to
    allowlist the Host header against DNS-rebind."""
    ips = set()
    try:
        for ip in socket.gethostbyname_ex(socket.gethostname())[2]:
            ips.add(ip)
    except Exception:
        pass
    return ips

def _tailscale_ip(ips=None):
    """A 100.64.0.0/10 address among our own IPs (the Tailscale tailnet IP), or None."""
    for ip in (ips if ips is not None else _own_ipv4s()):
        o = ip.split('.')
        if len(o) == 4 and o[0] == '100' and o[1].isdigit() and 64 <= int(o[1]) <= 127:
            return ip
    return None

def host_info(port):
    """Connect details for the board's Share panel. Served loopback-only, so the
    token is never handed to a remote device."""
    return {
        'hostMode': HOST_MODE,
        'tailscaleIp': TAILSCALE_IP or '',
        'port': port,
        'token': ACCESS_TOKEN,
        'connectUrl': ('http://%s:%d/?token=%s' % (TAILSCALE_IP, port, ACCESS_TOKEN))
                      if (HOST_MODE and TAILSCALE_IP) else '',
        'hasTailscale': bool(TAILSCALE_IP),
    }

def get_projects_root():
    """Where to look for tracked projects (cartridges). Precedence:
    1) STASYS_PROJECTS_ROOT env var, 2) the saved per-user setting,
    3) fallback: the engine folder's parent (the original in-folder behaviour).
    This lets the app be installed anywhere yet still point at your projects."""
    env = os.environ.get('STASYS_PROJECTS_ROOT')
    if env and os.path.isdir(env):
        return os.path.abspath(env)
    saved = _saved_projects_root()
    if saved and os.path.isdir(saved):
        return os.path.abspath(saved)
    return os.path.dirname(ENGINE_DIR)

def _read_app_version():
    """The engine/build version this app reports — single source of truth in the
    root VERSION file (stamped by the release process). Read by /api/version and,
    later, the auto-updater (compares this against the latest published release)."""
    try:
        with open(os.path.join(ENGINE_DIR, 'VERSION'), 'r', encoding='utf-8-sig') as f:
            return f.read().strip()
    except Exception:
        return ''

ROOT = get_projects_root()                                # the projects parent
ENGINE_NAME = os.path.basename(ENGINE_DIR)
APP_NAME = 'Stasys'
APP_VERSION = _read_app_version()                         # e.g. 'v0.22' (root VERSION file)
DEFAULT_SESSIONS_DIR = os.path.join('Documentation', 'SESSIONS')
EXCLUDE = {'backup', 'node_modules', '.git'}  # engine folder NOT excluded: the tracker tracks itself
PORTS = [8787, 8788, 8789, 8790, 8791]

# Host-mode state, resolved once at startup (a UI toggle would need a restart; not this phase).
HOST_MODE = _host_mode_enabled()
ACCESS_TOKEN = _resolve_access_token() if HOST_MODE else ''
OWN_IPS = _own_ipv4s()
TAILSCALE_IP = _tailscale_ip(OWN_IPS)
# Host header allowlist (anti-DNS-rebind): our own addresses + the loopback names.
HOST_ALLOW = {'127.0.0.1', 'localhost', '::1'} | OWN_IPS

# ---- auto-updater: version compare + release-manifest check (board item #21) ----
# Phase 2: compare the installed VERSION against the latest published release.
# The release feed is a separate PUBLIC channel (repo/bucket) serving a small
# manifest:  { "latest": "v0.23", "url": "...zip", "notes": "...", "sig": "..." }.
# Verifying the signature ("sig") happens later, at download/apply time — this
# phase only *detects* that a newer version exists. No source is exposed here.

def _version_key(s):
    """Parse 'v0.10' / 'v1.2.3' / 'v0.5a' into a comparable (nums, letter) so that
    v0.10 sorts ABOVE v0.9 (numeric, not lexical). Returns None if no version found."""
    m = re.search(r'v?\s*([0-9]+(?:\.[0-9]+)*)\s*([a-z]?)', str(s or ''), re.I)
    if not m:
        return None
    return ([int(x) for x in m.group(1).split('.')], m.group(2).lower())

def _version_cmp(a, b):
    """-1 / 0 / 1 comparing two version strings; an unparseable version sorts lowest."""
    ka, kb = _version_key(a), _version_key(b)
    if ka is None and kb is None:
        return 0
    if ka is None:
        return -1
    if kb is None:
        return 1
    na, nb = ka[0], kb[0]
    n = max(len(na), len(nb))
    na = na + [0] * (n - len(na))
    nb = nb + [0] * (n - len(nb))
    if na != nb:
        return -1 if na < nb else 1
    if ka[1] != kb[1]:
        return -1 if ka[1] < kb[1] else 1
    return 0

# The public releases feed, baked in so a fresh install auto-checks for updates with
# ZERO config (the real end-user experience - no settings file to hand-edit). An env
# var or settings.json 'updateFeedUrl' still overrides it (for testing / a custom feed).
DEFAULT_UPDATE_FEED = 'https://raw.githubusercontent.com/Haz65/Stasys-releases/main/manifest.json'

def _update_feed_url():
    """Where the release manifest lives. Precedence: STASYS_UPDATE_FEED env ->
    settings.json 'updateFeedUrl' -> the baked-in DEFAULT_UPDATE_FEED. Config-only and
    never client-supplied, so it can't be abused as a request-forgery (SSRF) vector."""
    env = os.environ.get('STASYS_UPDATE_FEED')
    if env and env.strip():
        return env.strip()
    try:
        with open(_settings_path(), 'r', encoding='utf-8-sig') as f:
            r = json.load(f).get('updateFeedUrl')
        if isinstance(r, str) and r.strip():
            return r.strip()
    except Exception:
        pass
    return DEFAULT_UPDATE_FEED

def _fetch_manifest(feed):
    """Read+parse the release manifest JSON from an http(s)/file URL or a local path.
    Local paths make the check testable offline (point STASYS_UPDATE_FEED at a file)."""
    if re.match(r'^(https?|file)://', feed, re.I):
        import urllib.request
        with urllib.request.urlopen(feed, timeout=5) as r:        # nosec: URL is operator config, not user input
            raw = r.read().decode('utf-8-sig')
    else:
        with open(feed, 'r', encoding='utf-8-sig') as f:
            raw = f.read()
    return json.loads(raw)

def update_check():
    """Compare the installed VERSION against the latest published release.
    Returns a dict the board renders; never raises (errors are reported in-band)."""
    feed = _update_feed_url()
    out = {'current': APP_VERSION, 'configured': bool(feed),
           'latest': '', 'updateAvailable': False, 'url': '', 'notes': ''}
    if not feed:
        return out
    try:
        m = _fetch_manifest(feed)
    except Exception as e:
        out['error'] = str(e)
        return out
    latest = str(m.get('latest') or '').strip()
    out['latest'] = latest
    out['url'] = str(m.get('url') or '')
    out['notes'] = str(m.get('notes') or '')
    out['updateAvailable'] = bool(latest) and _version_cmp(latest, APP_VERSION) > 0
    return out

# ---- auto-updater: release signature verification (board item #21, Phase 3a) ----
# The shipped app holds a PUBLIC key and only ever VERIFIES; the maintainer SIGNS
# offline (OpenSSL) with the matching private key. This is what makes a downloaded
# package trustworthy — not repo privacy. Scheme: RSASSA-PKCS#1 v1.5 over SHA-256
# (RSA-2048). The signature is over the package's raw bytes and rides in the
# manifest's "sig" field (base64). Python's stdlib has no public-key verify, so we
# do RSA verification by hand (modular exponentiation + PKCS#1 padding check) — the
# Node twin uses its built-in crypto.verify, which is the same scheme.
#
# Trust anchor: the public key, baked in below. SHIPPED EMPTY = fail-closed (every
# verification rejected) until the maintainer generates the real keypair and pastes
# its PEM here (must match server.js's RELEASE_PUBLIC_KEY_PEM exactly).
RELEASE_PUBLIC_KEY_PEM = """-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAyxBUwqnwv4eOGKsXQYzs
9N5IW/wg4sE+7rOrMf4f4l3fQFgD6H2aeXtXhVsJcsQHzsTFwUxVXKSr4O5G3/QA
IMEEi+X/R6yFuuEt3sHYxuZp5gCgwJPJ14MG0cp2KHg5x68oMjkZapIhCVvYKs9V
rWni4wCdASnXZ+qo5ojxrKdOCBtQ+Htng7+EPtW2JSAFSY6DJZov26lMdJ+5VFxr
HY2mZVC0L0VJolJr+6VtyQf0n9qQCip6B6dPTz4KAhQ2OAHUuqQPA1Nrca7W1WwN
kMjMZr1KB5lY7twg2vP1n7YT+lRTHaOfk3lYiZ7xYDpfAYav6KoiLrlcgflR6DMI
jwIDAQAB
-----END PUBLIC KEY-----
"""

# DigestInfo prefix for SHA-256 (RFC 8017 / PKCS#1 v1.5, EMSA-PKCS1-v1_5).
_SHA256_DIGEST_INFO = bytes.fromhex('3031300d060960864801650304020105000420')

def _der_tlv(buf, i):
    """Read one ASN.1 DER tag-length-value at offset i. Returns (tag, value_bytes,
    next_index). Handles short- and long-form lengths. Raises on malformed input."""
    tag = buf[i]
    n = buf[i + 1]
    i += 2
    if n & 0x80:                          # long form: low 7 bits = number of length bytes
        k = n & 0x7f
        n = int.from_bytes(buf[i:i + k], 'big')
        i += k
    return tag, buf[i:i + n], i + n

def _rsa_pubkey_from_pem(pem):
    """Extract (n, e) from an RSA public key in SubjectPublicKeyInfo PEM (the default
    `openssl rsa -pubout` format). Returns None on any parse failure (fail-closed)."""
    try:
        b64 = ''.join(ln for ln in pem.splitlines() if ln and not ln.startswith('-----'))
        der = base64.b64decode(b64)
        _, spki, _ = _der_tlv(der, 0)             # outer SEQUENCE
        # spki = SEQUENCE{algo} BITSTRING{ subjectPublicKey }
        _, _algo, j = _der_tlv(spki, 0)           # skip AlgorithmIdentifier
        tag, bitstr, _ = _der_tlv(spki, j)        # BIT STRING
        if tag != 0x03:
            return None
        inner = bitstr[1:]                        # drop the "unused bits" count byte
        _, rsakey, _ = _der_tlv(inner, 0)         # SEQUENCE{ INTEGER n, INTEGER e }
        tn, nval, k = _der_tlv(rsakey, 0)
        te, eval_, _ = _der_tlv(rsakey, k)
        if tn != 0x02 or te != 0x02:
            return None
        n = int.from_bytes(nval, 'big')
        e = int.from_bytes(eval_, 'big')
        if n <= 0 or e <= 0:
            return None
        return n, e
    except Exception:
        return None

def _rsa_verify_pkcs1_sha256(data, sig, n, e):
    """Verify an RSASSA-PKCS#1 v1.5 / SHA-256 signature over `data` against key (n, e)."""
    k = (n.bit_length() + 7) // 8
    if len(sig) != k:
        return False
    s = int.from_bytes(sig, 'big')
    if s >= n:
        return False
    em = pow(s, e, n).to_bytes(k, 'big')
    t = _SHA256_DIGEST_INFO + hashlib.sha256(data).digest()
    ps_len = k - len(t) - 3
    if ps_len < 8:                                # PKCS#1 mandates >= 8 padding bytes
        return False
    expected = b'\x00\x01' + b'\xff' * ps_len + b'\x00' + t
    return hmac.compare_digest(em, expected)

def verify_release(data, sig_b64, key_pem=None):
    """True only if `data` (the package bytes) carries a valid signature `sig_b64`
    (base64) from the release key. `key_pem` overrides the baked-in trust anchor
    `RELEASE_PUBLIC_KEY_PEM` (used by tests to inject a throwaway key; production
    passes None). Fail-closed: empty/unparseable key, bad base64, or any error ->
    False. Never raises."""
    try:
        pem = key_pem if key_pem is not None else RELEASE_PUBLIC_KEY_PEM
        if not pem.strip():
            return False
        key = _rsa_pubkey_from_pem(pem)
        if not key:
            return False
        sig = base64.b64decode(sig_b64, validate=True)
        return _rsa_verify_pkcs1_sha256(data, sig, key[0], key[1])
    except Exception:
        return False

# ---- auto-updater: download -> verify -> apply (board item #21, Phase 3b) ----
# Fetch the package named in the manifest, VERIFY its signature (verify_release —
# fail-closed), then atomically swap the engine's own text files. Python-only by
# design: the shipped runtime is Python and the stdlib has zipfile, whereas Node has
# no built-in zip extraction (the security-critical verify lives in both twins). Runs
# as a separate CLI process (`py server.py --apply-update <manifest>`), NOT an HTTP
# route — a file-overwriting endpoint would be needless attack surface, and a separate
# process matches the future "spawn updater, then restart" flow. Writing into the
# engine's OWN install dir is the updater's purpose; the "only write inside .tracker/"
# rule guards tracked projects, which this never touches.
UPDATE_FILES = ('server.py', 'server.js', 'board.html', 'VERSION')  # what an update replaces
UPDATE_CORE = ('server.py', 'board.html', 'VERSION')                # a package missing any of these is rejected
# The app SHELL - the native window, its WebView2 dlls, the icons and launchers. All
# optional in a package (most releases are engine-only), and all of them may be LOCKED
# while Stasys is running, which is what _replace_or_stage exists for.
UPDATE_SHELL = ('StasysApp.exe', 'Microsoft.Web.WebView2.Core.dll',
                'Microsoft.Web.WebView2.WinForms.dll', 'WebView2Loader.dll',
                'Stasys.ico', 'Stasys_Icon.png', 'Stasys_App.vbs', 'stasys_app.ps1',
                'Stop_Stasys.bat', 'Stasys.bat', 'Set_Projects_Folder.bat',
                'set_projects_folder.ps1')
UPDATE_BACKUP_DIR = '.update-backup'
STALE_SUFFIX = '.stasys-old'        # a running image renamed aside by an update

def _fetch_bytes(src):
    """Raw download of a package from an http(s)/file URL or a local path. Byte-level
    sibling of _fetch_manifest. Operator/manifest-supplied source, not client input."""
    if re.match(r'^(https?|file)://', src, re.I):
        import urllib.request
        with urllib.request.urlopen(src, timeout=30) as r:        # nosec: source is signed-package URL, verified after
            return r.read()
    with open(src, 'rb') as f:
        return f.read()

def _stale_path(dst):
    """A free <name>.stasys-old path to park a running image at. Normally there's only
    one; a numbered variant is used if an earlier one is still locked (Stasys was
    updated twice without ever being closed)."""
    stale = dst + STALE_SUFFIX
    if os.path.exists(stale):
        try:
            os.remove(stale)                   # a previous update's leftover, now free
        except OSError:
            n = 1
            while os.path.exists('%s.%d%s' % (dst, n, STALE_SUFFIX)):
                n += 1
            stale = '%s.%d%s' % (dst, n, STALE_SUFFIX)
    return stale


def _replace_or_stage(dst, data):
    """Write `data` to `dst`. Returns ('replaced'|'staged', stale_path_or_None).

    Plain files are swapped atomically (temp + os.replace). But the app shell can be
    IN USE: Windows refuses to overwrite or delete a running .exe or a loaded .dll -
    while still allowing it to be RENAMED. So on a lock we move the running image aside
    to <name>.stasys-old and drop the new file at the real path: the running Stasys
    keeps executing from the renamed image, the shortcut still points at the real path,
    and the new shell takes over the next time Stasys is opened. The leftover is deleted
    by sweep_stale_updates() on a later start, once nothing holds it."""
    tmp = dst + '.update-tmp'
    with open(tmp, 'wb') as f:
        f.write(data)
        f.flush()
        os.fsync(f.fileno())
    try:
        os.replace(tmp, dst)
        return 'replaced', None
    except OSError:
        pass                                   # in use - fall through to the rename path
    stale = _stale_path(dst)
    os.rename(dst, stale)                      # allowed even while running
    try:
        os.replace(tmp, dst)
    except Exception:
        os.rename(stale, dst)                  # put the running image back where it was
        raise
    return 'staged', stale


def sweep_stale_updates(target_dir=None):
    """Delete the <name>.stasys-old images a shell update left behind, once the process
    that held them has exited. Called at startup. Best-effort by design: anything still
    locked (Stasys reopened before the old window closed) is left for the next start."""
    target_dir = target_dir or ENGINE_DIR
    removed = []
    try:
        for fn in os.listdir(target_dir):
            if not fn.endswith(STALE_SUFFIX):
                continue
            try:
                os.remove(os.path.join(target_dir, fn))
                removed.append(fn)
            except OSError:
                pass                           # still in use - try again next time
    except Exception:
        pass
    return removed


def apply_update(manifest_src, target_dir=None, key_pem=None):
    """Download, verify, and apply the release named in the manifest. Returns a result
    dict and NEVER raises. Fail-closed: a bad/absent signature (against the baked-in
    release key) aborts without touching a single file. Atomic per-file with a full
    rollback if any write fails.

    manifest_src: manifest URL/path, or '' to use the configured update feed.
    target_dir:   install dir to update (defaults to this engine's own dir).
    key_pem:      override the trust anchor (tests inject a throwaway key)."""
    target_dir = target_dir or ENGINE_DIR
    try:
        feed = manifest_src or _update_feed_url()
        if not feed:
            return {'applied': False, 'reason': 'no manifest / update feed configured'}
        m = _fetch_manifest(feed)
        latest = str(m.get('latest') or '').strip()
        url = str(m.get('url') or '').strip()
        sig = str(m.get('sig') or '').strip()
        if not (latest and url and sig):
            return {'applied': False, 'reason': 'manifest missing latest/url/sig'}
        if _version_cmp(latest, APP_VERSION) <= 0:
            return {'applied': False, 'reason': 'not newer', 'current': APP_VERSION, 'latest': latest}

        pkg = _fetch_bytes(url)
        # THE trust gate — only a package signed by the baked-in release key proceeds.
        if not verify_release(pkg, sig, key_pem):
            return {'applied': False, 'reason': 'signature invalid'}

        # Read the allowlisted members out of the verified zip (never arbitrary extraction).
        try:
            zf = zipfile.ZipFile(io.BytesIO(pkg))
        except Exception:
            return {'applied': False, 'reason': 'package is not a valid zip'}
        names = set(zf.namelist())
        new_bytes = {}
        for fn in UPDATE_FILES + UPDATE_SHELL:   # shell members are optional: engine-only
            if fn in names:                      # releases simply don't carry them
                new_bytes[fn] = zf.read(fn)
        missing = [fn for fn in UPDATE_CORE if fn not in new_bytes]
        if missing:
            return {'applied': False, 'reason': 'package missing core files: ' + ', '.join(missing)}
        pkg_ver = new_bytes['VERSION'].decode('utf-8-sig').strip()
        if pkg_ver != latest:
            return {'applied': False, 'reason': "package VERSION %r != manifest latest %r" % (pkg_ver, latest)}

        # Atomic apply with backup + rollback.
        backup = os.path.join(target_dir, UPDATE_BACKUP_DIR)
        if os.path.isdir(backup):
            shutil.rmtree(backup, ignore_errors=True)
        os.makedirs(backup, exist_ok=True)
        written = []                                                  # (name, mode, stale_path)
        try:
            for fn, data in new_bytes.items():
                dst = os.path.join(target_dir, fn)
                if os.path.exists(dst):
                    shutil.copy2(dst, os.path.join(backup, fn))      # back up the current file
                                                                     # (reading a running exe is allowed)
                mode, stale = _replace_or_stage(dst, data)
                written.append((fn, mode, stale))
        except Exception as e:
            for fn, mode, stale in written:
                dst = os.path.join(target_dir, fn)
                try:
                    if mode == 'staged' and stale and os.path.exists(stale):
                        # the file now at dst is the NEW one and nothing is running it,
                        # so it can go; then the running image returns to its real path
                        if os.path.exists(dst):
                            os.remove(dst)
                        os.rename(stale, dst)
                    else:
                        b = os.path.join(backup, fn)
                        if os.path.exists(b):
                            shutil.copy2(b, dst)
                except Exception:
                    pass
            return {'applied': False, 'reason': 'write failed, rolled back: ' + str(e), 'rolledBack': True}

        staged = [fn for fn, mode, _ in written if mode == 'staged']
        return {'applied': True, 'from': APP_VERSION, 'to': latest,
                'files': [fn for fn, _, _ in written], 'staged': staged,
                # the engine reloads on the server restart; a staged shell only takes
                # over when Stasys itself is next opened - the board says so
                'appRestartRequired': bool(staged),
                'backup': backup, 'notes': str(m.get('notes') or '')}
    except Exception as e:
        return {'applied': False, 'reason': str(e)}

# ---- track palette (display order + colours); tracks are inferred, tune freely ----
TRACKS = {
    'F': {'name': 'Foundations & diagnostics', 'short': 'Foundations',  'color': '#8b8f9a'},
    'E': {'name': 'Economy & sim',             'short': 'Economy',      'color': '#2bb89a'},
    'M': {'name': 'Movement & physics',        'short': 'Movement',     'color': '#3f8ae0'},
    'P': {'name': 'Polish & FX',               'short': 'Polish',       'color': '#d56aa0'},
    'O': {'name': 'Optimisation & scale',      'short': 'Optimisation', 'color': '#8a7fe0'},
    'C': {'name': 'Construction',              'short': 'Construction', 'color': '#e0a23f'},
    'U': {'name': 'UI / HUD',                  'short': 'UI / HUD',     'color': '#e0673f'},
}
TRACK_ORDER = ['F', 'E', 'M', 'P', 'O', 'C', 'U']
# Per-card field ceilings applied on save. These are runaway guards (a bad paste, a
# client bug) - NOT design limits - so they sit far above real use. The write-up was
# capped at 5000 from the first commit with no rationale, and real cards reached it;
# 100k is ~16,000 words, more than anyone writes on one card, and still trivial next
# to a state.json the server reads whole.
WRITEUP_MAX = 100000
TITLE_MAX = 500
# The resume note is deliberately SHORT - it is the "where does this stand" line a
# picked-up card is read for, not a second write-up (that's `writeup`, above). The
# ceiling is a runaway guard like the others, not a style rule.
RESUME_MAX = 4000
RESUME_REF_MAX = 200      # the free-text "branch / last commit" the note was written against
RESUME_AT_MAX = 40        # when the note was last edited (ISO), stamped by the board
TRACK_KEYWORDS = [
    ('U', re.compile(r'\b(ui|hud|panel|theme|style-guide|world-layer|markers?|2d-migration|watch-panels?)\b', re.I)),
    ('C', re.compile(r'\b(construction|shipyard|station-construction|buildable|logistics-centre|dockyard|warehouse)\b', re.I)),
    ('O', re.compile(r'\b(optimi[sz]ation|optimi[sz]e|scale|throttle|cache|stress)\b', re.I)),
    ('M', re.compile(r'\b(two-body|2-body|traversal|interplanetary|avoidance|movement)\b', re.I)),
    ('E', re.compile(r'\b(economy|track[1-6]|recipe|happiness|currency|maintenance|manifests?|storage|prioritisation|governors?|consumption|resupply|crew|resident|tug|moon-station|dispatch|water-recycling|ownership)\b', re.I)),
    ('P', re.compile(r'\b(polish|fx|material|time-dilation|orientation|engine-fx|invisible|clipping)\b', re.I)),
    ('F', re.compile(r'\b(doc|diagnostics?|audit|cleanup|planning|world-model|refactor|decomposition|recipe-pattern|phase)\b', re.I)),
]

# ---- precompiled patterns for the parser ----
RE_MD = re.compile(r'\.md$', re.I)
# A record's version may be written v0.37 or v9_71 - projects differ, and a filename this
# didn't match cost the record BOTH its date and its version (its "version" came out as the
# whole filename). 74 of SpaceLogistics' 143 records parsed that way before v0.38. A trailing
# -suffix (v9.64-wip) is kept; the separator is normalised to a dot by parse_session.
RE_FNAME = re.compile(r'^(\d{4}-\d{2}-\d{2})_v([0-9]+[._][0-9]+[a-z]?(?:-[A-Za-z0-9]+)?)_(.+)$', re.I)
# The value is OPTIONAL: a bare `completes:` introduces an indented YAML list on the lines
# below it, which is how records have actually been written since ~2026-07-24.
RE_FRONT = re.compile(r'^([\w-]+):\s*(.*)$')
RE_FRONT_ITEM = re.compile(r'^\s+-\s*(.*)$')
RE_DATE = re.compile(r'\d{4}-\d{2}-\d{2}')
RE_H1 = re.compile(r'^#\s+\S')
RE_SUB = re.compile(r'^###\s+v?[0-9]')
RE_TRACK_SUFFIX = re.compile(r'·\s*([A-Za-z][\w/ ]*?)\s*track\b', re.I)
RE_VER_PREFIX = re.compile(r'^v?[0-9.]+[a-z]?(\s+baseline)?\s*·?\s*', re.I)
RE_TRACK_STRIP = re.compile(r'·\s*[A-Za-z][\w/ ]*?\s*track\b', re.I)
RE_BRANCH_WORD = re.compile(r'^branch[:\s]+', re.I)
RE_HEADER = re.compile(r'^#{2,3}\s')
RE_BQ = re.compile(r'^>\s?')
RE_COMMIT = re.compile(r'^[-*]\s+\*\*(.+?)\*\*\s*\(`?([0-9a-f]{6,40})`?\)', re.I)
RE_NEXT = re.compile(r'^(?:\d+\.|[-*])\s+(.+)$')
RE_COMMIT_HDR = re.compile(r'^#{2,3}.*\bcommits?\b.*$', re.I)
RE_NEXT_HDR = re.compile(r'^#{2,3}.*\bnext steps?\b.*$', re.I)
RE_FLAG_HDR = re.compile(r'^#{2,3}.*\b(bug|blocker)\b', re.I)
# ---- audit / Truth-layer patterns ----
RE_VER_TOKEN = re.compile(r'\bv([0-9]+(?:\.[0-9]+){0,2}[a-z]?)\b', re.I)
# A doc's version counts only when *positively declared*: a "version" label
# immediately followed by a token (RE_VER_DECL), or a single token at the END
# of a heading/title (RE_HEADING + RE_TITLE_TAIL — only trailing emphasis or
# closing punctuation after it). A token buried mid-heading ("(do not use the
# v7.00 wording)"), an incidental prose mention, or a range is provenance.
RE_VER_DECL = re.compile(r'\bversion\b[\s:*\-—]*v[0-9]', re.I)
RE_HEADING = re.compile(r'^\s{0,3}#{1,6}\s')
RE_TITLE_TAIL = re.compile(r'^[\s*_~`)\].]*$')


def infer_track(slug):
    for k, rx in TRACK_KEYWORDS:
        if rx.search(slug):
            return k
    return 'F'


def track_from_header(txt):
    t = (txt or '').strip().lower()
    for k in TRACK_ORDER:
        tr = TRACKS[k]
        if t in (tr['short'].lower(), tr['name'].lower(), k.lower()):
            return k
    if t.startswith('ui'): return 'U'
    if t.startswith('econ'): return 'E'
    if t.startswith('const'): return 'C'
    if t.startswith('move') or t.startswith('phys'): return 'M'
    if t.startswith('opt'): return 'O'
    if t.startswith('pol'): return 'P'
    if t.startswith('found') or t.startswith('diag'): return 'F'
    return None


# Fallback colours for declared track codes with no built-in match (cycled by order).
FALLBACK_COLORS = ['#8b8f9a', '#2bb89a', '#3f8ae0', '#d56aa0', '#8a7fe0', '#e0a23f', '#e0673f']


def resolve_tracks(cfg):
    """Resolve a project's lane palette from cfg['tracks'].

    Honors two forms (and a mix of both):
      - a code string  ("F")                       -> built-in defaults for that code
      - an object      {code,name,short,color}     -> custom lane; omitted fields fall
                                                       back to the built-in for that code
    Returns (tracks_map, order). When cfg declares no usable tracks, falls back to the
    full built-in palette (the historical behaviour), so undeclared projects are unchanged.
    """
    decl = cfg.get('tracks') if isinstance(cfg, dict) else None
    if not isinstance(decl, list) or not decl:
        return dict(TRACKS), list(TRACK_ORDER)
    tracks, order = {}, []
    for entry in decl:
        if isinstance(entry, str):
            code, custom = entry.strip(), {}
        elif isinstance(entry, dict):
            code = str(entry.get('code') or entry.get('key') or '').strip()
            custom = entry
        else:
            continue
        if not code or code in tracks:
            continue
        base = TRACKS.get(code, {})
        name = custom.get('name') or base.get('name') or code
        short = custom.get('short') or base.get('short') or name
        color = custom.get('color') or base.get('color') or FALLBACK_COLORS[len(order) % len(FALLBACK_COLORS)]
        tracks[code] = {'name': name, 'short': short, 'color': color}
        order.append(code)
    if not order:
        return dict(TRACKS), list(TRACK_ORDER)
    return tracks, order


def constrain_tracks(sessions, order):
    """Snap any session whose track is outside the project's declared set onto the first
    declared lane, so every dot has a lane to sit in (inference is built-in/global)."""
    valid = set(order)
    fb = order[0] if order else 'F'
    for s in sessions:
        if s.get('track') not in valid:
            s['track'] = fb
    return sessions


def section_body(lines, header_rx):
    idx = -1
    for i, l in enumerate(lines):
        if header_rx.search(l):
            idx = i
            break
    if idx < 0:
        return []
    body = []
    for i in range(idx + 1, len(lines)):
        if RE_HEADER.match(lines[i]):
            break
        body.append(lines[i])
    return body


def _strip_quotes(s):
    """Trim a claim and drop one matched pair of surrounding quotes, so `- "a title"`
    and `- a title` mean the same thing."""
    s = (s or '').strip()
    if len(s) >= 2 and s[0] == s[-1] and s[0] in '"\'':
        s = s[1:-1].strip()
    return s


def _claims_from_value(raw):
    """The claims named by ONE inline `completes:` value.

    Splits on commas, but NEVER inside quotes - card titles are prose and commas in them
    are normal ("Rocky maria - artifacts at fill_iters around 340 (dev-observed,
    undiagnosed)" is one card, not two). Also accepts a bracketed list, so the `[]` that
    records use to mean "this one completed nothing" reads as empty rather than as a card
    titled '[]'."""
    s = (raw or '').strip()
    if s.startswith('[') and s.endswith(']'):
        s = s[1:-1].strip()
    out, buf, quote = [], [], ''
    for ch in s:
        if quote:
            if ch == quote:
                quote = ''
            else:
                buf.append(ch)
        elif ch in '"\'':
            quote = ch
        elif ch == ',':
            out.append(''.join(buf))
            buf = []
        else:
            buf.append(ch)
    out.append(''.join(buf))
    return [t for t in (x.strip() for x in out) if t]


def parse_session(filename, text):
    base = RE_MD.sub('', filename)
    m = RE_FNAME.match(base)
    date = m.group(1) if m else ''
    version = ('v' + m.group(2).replace('_', '.')) if m else base
    slug = m.group(3) if m else base
    out = {
        'file': filename, 'date': date, 'version': version, 'slug': slug,
        'title': slug.replace('-', ' '),
        'track': 'F', 'summary': '', 'branch': '',
        'lastModified': '', 'lastVerified': '',
        'commits': [], 'next': [], 'flag': None, 'rich': False, 'completes': [],
        # `touches:` is `completes:`'s sibling - the SAME claim syntax and the same
        # number-first matching - but it only LINKS a record to a card. It never
        # changes the card's status, so a record can say "I worked on #206" without
        # claiming to have finished it.
        'touches': [],
    }
    lines = text.replace('\r\n', '\n').replace('\r', '\n').split('\n')

    # frontmatter
    if lines and lines[0].strip() == '---':
        i = 1
        while i < len(lines) and lines[i].strip() != '---':
            fm = RE_FRONT.match(lines[i])
            if fm:
                key = fm.group(1).lower()
                if key in ('completes', 'touches'):
                    # ONE parser for both keys, deliberately: `touches:` differs from
                    # `completes:` only in what the board does with the result, so any
                    # future fix to claim syntax lands on both at once.
                    raw = fm.group(2).strip()
                    claims = _claims_from_value(raw)
                    if not raw:
                        # bare `completes:` - the claims are the indented "- item" lines
                        # under it. This form was silently invisible before v0.38: the
                        # key matched nothing, the items weren't keys, and the whole
                        # list evaporated with no error anywhere.
                        while i + 1 < len(lines) and lines[i + 1].strip() != '---':
                            if not lines[i + 1].strip():   # blank lines inside a YAML list are
                                i += 1                     # legal - stopping here would drop
                                continue                   # every claim below them, silently
                            item = RE_FRONT_ITEM.match(lines[i + 1])
                            if not item:
                                break
                            v = _strip_quotes(item.group(1))
                            if v:
                                claims.append(v)
                            i += 1
                    out[key] = claims
                else:
                    dm = RE_DATE.search(fm.group(2))
                    val = dm.group(0) if dm else fm.group(2).strip()
                    if key == 'last_modified':
                        out['lastModified'] = val
                    elif key == 'last_verified':
                        out['lastVerified'] = val
            i += 1

    # H1 title
    for l in lines:
        if RE_H1.match(l):
            out['title'] = re.sub(r'^#\s+', '', l).strip()
            break

    # ### version - branch/merge - track
    track_explicit = False
    sub = None
    for l in lines:
        if RE_SUB.match(l):
            sub = l
            break
    if sub:
        s = re.sub(r'^###\s+', '', sub).strip()
        tk = RE_TRACK_SUFFIX.search(s)
        if tk:
            k = track_from_header(tk.group(1))
            if k:
                out['track'] = k
                track_explicit = True
        branch = RE_VER_PREFIX.sub('', s)
        branch = RE_TRACK_STRIP.sub('', branch).replace('`', '').strip()
        branch = RE_BRANCH_WORD.sub('', branch).strip()
        out['branch'] = branch
        out['rich'] = True
    if not track_explicit:
        out['track'] = infer_track(slug)
    if out['track'] not in TRACKS:
        out['track'] = 'F'

    # summary: first contiguous '>' blockquote run
    sum_lines = []
    started = False
    for l in lines:
        if RE_BQ.match(l):
            started = True
            sum_lines.append(RE_BQ.sub('', l))
        elif started:
            break
    if sum_lines:
        out['summary'] = re.sub(r'\s+', ' ', ' '.join(sum_lines).replace('**', '').replace('`', '')).strip()

    # commits (top-level bullets only)
    for l in section_body(lines, RE_COMMIT_HDR):
        cm = RE_COMMIT.match(l)
        if cm:
            out['commits'].append({'name': cm.group(1).strip(), 'hash': cm.group(2)})
    if out['commits']:
        out['rich'] = True

    # next steps (top-level items only)
    for l in section_body(lines, RE_NEXT_HDR):
        nm = RE_NEXT.match(l)
        if not nm:
            continue
        item = nm.group(1).replace('**', '').replace('`', '').strip()
        if len(item) > 160:
            item = item[:157].strip() + '…'
        if item:
            out['next'].append(item)
        if len(out['next']) >= 5:
            break

    # flag: first content line under a BUG/BLOCKER header
    for i, l in enumerate(lines):
        if RE_FLAG_HDR.match(l):
            for j in range(i + 1, len(lines)):
                t = lines[j].strip()
                if not t:
                    continue
                if RE_HEADER.match(t):
                    break
                t = re.sub(r'^[-*]\s+', '', t).replace('**', '').replace('`', '')
                out['flag'] = t[:220]
                break
            break
    return out


# ---- project helpers ----
def safe_name(pid):
    return bool(pid) and isinstance(pid, str) and '/' not in pid and '\\' not in pid \
        and '..' not in pid and not pid.startswith('.')


def project_dir(pid):
    if not safe_name(pid):
        return None
    d = os.path.abspath(os.path.join(ROOT, pid))
    if d != os.path.join(os.path.abspath(ROOT), pid):
        return None
    return d


def tracked_project_dir(pid):
    """Like project_dir, but the project must ALREADY EXIST and be trackable.

    project_dir only sanitises the name - it happily returns a path for a folder that isn't
    there, and write_state would then create it. That's tolerable for the board, whose project
    names come from a dropdown this server filled in, but not for the patch door, whose name is
    typed by a person or an agent: a typo has to be an error, never a brand-new folder with a
    backlog inside it. Same trackable test list_projects uses, so the two can't disagree."""
    d = project_dir(pid)
    if not d or pid in EXCLUDE or not os.path.isdir(d):
        return None
    if not os.path.isdir(sessions_dir_of(d, read_config(d))):
        return None
    return d


def read_config(dirpath):
    try:
        with open(os.path.join(dirpath, '.tracker', 'config.json'), 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return None


def sessions_dir_of(dirpath, cfg):
    rel = (cfg.get('sessionsDir') if isinstance(cfg, dict) else None) or DEFAULT_SESSIONS_DIR
    rel = rel.replace('/', os.sep).replace('\\', os.sep)
    return os.path.join(dirpath, rel)


def list_projects():
    out = []
    try:
        entries = os.listdir(ROOT)
    except Exception:
        return out
    for name in entries:
        full = os.path.join(ROOT, name)
        if not os.path.isdir(full) or name in EXCLUDE or name.startswith('.'):
            continue
        cfg = read_config(full)
        if os.path.isdir(sessions_dir_of(full, cfg)):
            disp = cfg.get('name') if isinstance(cfg, dict) and cfg.get('name') else name
            out.append({'id': name, 'name': disp})
    out.sort(key=lambda x: x['name'].lower())
    return out


# ---- scaffolding: set up a new project's structure (idempotent - only adds what's missing) ----
def _safe_folder(name):
    name = (name or '').strip()
    if not name:
        return None
    cleaned = re.sub(r'[<>:"/\\|?*\x00-\x1f]', '', name).strip().rstrip('. ')
    if not cleaned or '..' in cleaned or cleaned.startswith('.'):
        return None
    return cleaned

def _starter_session(name, today):
    return (
        "---\n"
        "last_modified: %s\n"
        "last_verified: %s\n"
        "---\n\n"
        "# Getting started — %s\n\n"
        "### v0.1\n\n"
        "> Starter entry created by Stasys. Files in Documentation/SESSIONS named like\n"
        "> `YYYY-MM-DD_vX.Y_slug.md` become points on the timeline. Edit or delete this and add your own.\n\n"
        "## What this is\n"
        "- Stasys builds the timeline from these session write-ups.\n"
        "- Add backlog items (the cards) directly in the board.\n"
        "- Delete this file once you have real sessions.\n"
    ) % (today, today, name)

def new_project(name):
    folder = _safe_folder(name)
    if not folder:
        return {'error': 'bad name'}
    proj = os.path.abspath(os.path.join(ROOT, folder))
    if os.path.dirname(proj) != os.path.abspath(ROOT):   # no traversal outside ROOT
        return {'error': 'bad name'}
    tracker = os.path.join(proj, '.tracker')
    cfg_path = os.path.join(tracker, 'config.json')
    already = os.path.exists(cfg_path)
    sessions = os.path.join(proj, DEFAULT_SESSIONS_DIR)
    os.makedirs(sessions, exist_ok=True)
    os.makedirs(tracker, exist_ok=True)
    if not os.path.exists(cfg_path):   # never overwrite an existing config
        with open(cfg_path, 'w', encoding='utf-8') as f:
            json.dump({'name': name.strip(), 'tracks': ['F', 'O', 'P', 'U']}, f, indent=2)
    state_path = os.path.join(tracker, 'state.json')
    if not os.path.exists(state_path):
        with open(state_path, 'w', encoding='utf-8') as f:
            json.dump({'version': 1, 'items': []}, f, indent=2)
    try:
        has_md = any(fn.lower().endswith('.md') for fn in os.listdir(sessions))
    except Exception:
        has_md = False
    if not has_md:   # a starter entry so the timeline isn't bare (and self-documents the format)
        today = datetime.date.today().isoformat()
        with open(os.path.join(sessions, '%s_v0.1_getting-started.md' % today), 'w', encoding='utf-8') as f:
            f.write(_starter_session(name.strip(), today))
    return {'ok': True, 'id': folder, 'name': name.strip(), 'alreadyExisted': already}


RE_SESSION_SORT = re.compile(r'^(\d{4}-\d{2}-\d{2})_v(\d+)[._](\d+)([a-z]?)', re.I)
def _session_fname_key(fname):
    """Order session files chronologically, then by NUMERIC version, so v0.10 sorts
    AFTER v0.9 (a plain string sort put 'v0.10' between 'v0.1' and 'v0.2', because the
    text '0.10' compares less than '0.2')."""
    m = RE_SESSION_SORT.match(fname)
    if not m:
        return (1, fname.lower(), 0, 0, '')
    return (0, m.group(1), int(m.group(2)), int(m.group(3)), (m.group(4) or '').lower())


def read_sessions(dirpath, cfg):
    sd = sessions_dir_of(dirpath, cfg)
    try:
        files = [f for f in os.listdir(sd) if f.lower().endswith('.md')]
    except Exception:
        return []
    files.sort(key=_session_fname_key)
    out = []
    for f in files:
        try:
            with open(os.path.join(sd, f), 'r', encoding='utf-8', errors='replace') as fh:
                out.append(parse_session(f, fh.read()))
        except Exception as e:
            out.append({'file': f, 'date': '', 'version': f, 'slug': f, 'title': f, 'track': 'F',
                        'summary': '', 'branch': '', 'commits': [], 'next': [], 'flag': None,
                        'rich': False, 'error': str(e)})
    return out


def _write_atomic(path, text):
    """Write via a temp file + os.replace so an interrupted write can never leave a
    truncated file behind. state.json IS the backlog - a half-written one reads as
    damage (and used to render as an empty board), so it's never written in place."""
    tmp = path + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as f:
        f.write(text)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, path)


# The revision a client must quote to save the whole backlog. NOT a field in state.json -
# it is computed from the file's own text every time it is read, so it costs no schema
# change (an older Stasys reads and writes the same file unchanged) and, unlike a counter,
# it cannot be fooled by a writer that edits the file without bumping anything.
REV_NONE = 'none'          # there is no state.json yet - a distinct value, never the empty string,
                           # so "I loaded a project with no backlog" is still something to compare


def _state_rev(text):
    """Revision token for a backlog file: a short hash of its text.

    Hashes the DECODED TEXT with newlines normalised, not the raw bytes, and that is
    deliberate. Python writes state.json through a text-mode handle, so on Windows it
    lands with CRLF; Node writes the same string with LF. Hashing bytes would give the
    two twins different revisions for a file whose content is identical - a spurious
    conflict on the first save after switching runtime. Same content, same rev, either
    twin."""
    return hashlib.sha256(text.replace('\r\n', '\n').encode('utf-8')).hexdigest()[:16]


def read_state(dirpath):
    """Read a project's backlog, telling 'legitimately empty' apart from 'damaged'.

    Returns (state, error). error is None on success - including a genuinely ABSENT
    state.json, which means a project with no backlog yet, not damage. When the file
    exists but can't be trusted (invalid JSON, truncated, wrong shape), state is None
    and error is a short human-readable reason.

    The returned state carries a 'rev' the file itself does not: see _state_rev. It is
    added on the way OUT and is never written back - write_state builds the saved object
    field by field, so state.json's shape is unchanged by this.

    Callers must NOT substitute an empty backlog on error. That was the old behaviour
    and it was silent data loss: an empty state renders as a blank board, then gets
    written straight over DEFERRED.md and state.json - indistinguishable from the real
    backlog having been deleted."""
    p = os.path.join(dirpath, '.tracker', 'state.json')
    if not os.path.exists(p):
        # no backlog yet - legitimately empty
        return {'version': 1, 'items': [], 'rev': REV_NONE}, None
    try:
        with open(p, 'r', encoding='utf-8') as f:
            raw = f.read()
    except Exception as e:
        return None, 'could not be opened (%s)' % e.__class__.__name__
    if not raw.strip():
        return None, 'is empty (0 bytes) - most likely truncated by an interrupted write'
    try:
        obj = json.loads(raw)
    except ValueError as e:
        return None, 'is not valid JSON (%s)' % e
    if not isinstance(obj, dict) or not isinstance(obj.get('items'), list):
        return None, "is valid JSON but not a backlog (no 'items' list)"
    obj['rev'] = _state_rev(raw)
    return obj, None


def state_error_body(dirpath, reason):
    """The body every endpoint returns when a project's state.json can't be trusted.
    Deliberately NOT an empty backlog: the board shows a read-only banner instead of a
    blank one, and no write path touches the file until it's fixed."""
    td = os.path.join(dirpath, '.tracker')
    bak = os.path.join(td, 'state.json.bak')
    return {'error': 'state-unreadable', 'detail': reason,
            'path': os.path.join(td, 'state.json'),
            'backup': bak if os.path.exists(bak) else ''}


def _to_int(v):
    try:
        return int(v)
    except Exception:
        return 0


def write_state(dirpath, incoming, tracks=None, order=None):
    if not tracks:
        tracks = TRACKS
    if not order:
        order = TRACK_ORDER
    td = os.path.join(dirpath, '.tracker')
    os.makedirs(td, exist_ok=True)
    clean = {'version': 1, 'updated': datetime.datetime.now().isoformat(), 'items': []}
    items_in = incoming.get('items') if isinstance(incoming, dict) else None
    # nextId is a MONOTONIC id allocator persisted beside the items. Ids used to be
    # handed out as max(live ids)+1, which recycles a number as soon as the highest
    # card is deleted - fine while ids were invisible, wrong now that the board prints
    # them and session records cite them (a reused #25 would name two different items).
    # It only ever moves forward: never below the highest id present, and never below
    # whatever a previous save already reserved, so a deleted number is retired for good.
    next_id = _to_int(incoming.get('nextId')) if isinstance(incoming, dict) else 0
    # Floor it against what's already on disk, so the counter can't be walked backwards by a
    # client that doesn't send one (a stale browser tab, or a board older than this version).
    # The on-disk items matter too: a legacy state.json has no nextId, so deleting its highest
    # card and saving would otherwise recycle that number on the very first write.
    disk, _derr = read_state(dirpath)
    if isinstance(disk, dict):
        next_id = max(next_id, _to_int(disk.get('nextId')))
        for it in (disk.get('items') or []):
            next_id = max(next_id, _to_int((it or {}).get('id')) + 1)
    if isinstance(items_in, list):
        used = set()
        max_id = 0
        for it in items_in:
            n = _to_int((it or {}).get('id'))
            if n > 0:
                max_id = max(max_id, n)
        next_id = max(next_id, max_id + 1)
        max_id = next_id - 1          # backfilled ids come from the allocator too
        for it in items_in:
            it = it or {}
            iid = _to_int(it.get('id'))
            if iid <= 0 or iid in used:
                max_id += 1
                iid = max_id
            used.add(iid)
            track = it.get('track') if it.get('track') in tracks else order[0]
            status = it.get('status') if it.get('status') in ('table', 'air', 'cut', 'done') else 'table'
            # `parked` sits ALONGSIDE status, the way `flag` does - it is not a fifth
            # lane. A parked card keeps its place in the table ordering (so it is still
            # what "let's continue" picks); it just says out loud that it was set down
            # mid-flight and that its resume note is the place to look.
            # Only a live card can be parked. Clearing it on done/cut is the backstop
            # for the failure this whole field exists to avoid: a state nobody clears
            # becomes a lie, and a "parked" Done card would make the parked count -
            # the one number you're meant to trust at a glance - meaningless.
            parked = bool(it.get('parked')) and status in ('table', 'air')
            clean_item = {
                'id': iid,
                'title': str(it.get('title') or '')[:TITLE_MAX],
                'track': track,
                'status': status,
                'writeup': str(it.get('writeup') or '')[:WRITEUP_MAX],
                'flag': bool(it.get('flag')),
                'parked': parked,
            }
            # The note itself is NEVER dropped, on any status - it is the writer's prose
            # and it stays readable as history after the card closes. Only the boolean
            # is cleared above. `parked` is written on every item (it mirrors `flag`,
            # which has always been); the three string fields are omitted when empty,
            # the way doneVersion/doneDate already are, so a card that never uses them
            # gains nothing but the one boolean.
            resume = str(it.get('resume') or '')[:RESUME_MAX]
            resume_ref = str(it.get('resumeRef') or '')[:RESUME_REF_MAX]
            resume_at = str(it.get('resumeAt') or '')[:RESUME_AT_MAX]
            if resume:
                clean_item['resume'] = resume
            if resume_ref:
                clean_item['resumeRef'] = resume_ref
            if resume_at:
                clean_item['resumeAt'] = resume_at
            if status == 'done':
                clean_item['doneVersion'] = str(it.get('doneVersion') or '')[:40]
                clean_item['doneDate'] = str(it.get('doneDate') or '')[:20]
            clean['items'].append(clean_item)
        next_id = max(next_id, max_id + 1)
    clean['nextId'] = max(next_id, 1)
    sp = os.path.join(td, 'state.json')
    try:                                  # the bytes we're about to replace, for the .bak
        with open(sp, 'rb') as f:
            prev = f.read()
    except Exception:
        prev = b''
    text = json.dumps(clean, indent=2, ensure_ascii=False)
    _write_atomic(sp, text)
    # The rev of what we just wrote, handed back so a caller that saved can quote it on its
    # NEXT save without re-reading. Set after the write and never before: a rev is a claim
    # about what is on disk. It goes on the returned object only - not into the file.
    clean['rev'] = _state_rev(text)
    if prev.strip():                      # keep the previous save one step behind, so a bad
        try:                              # state.json is always recoverable by hand
            with open(sp + '.bak', 'wb') as f:
                f.write(prev)
        except Exception:
            pass
    # render BEFORE opening the target: a render that raised mid-write used to leave a
    # truncated (or empty) DEFERRED.md behind, which is the same data loss one step down.
    md = render_deferred(os.path.basename(dirpath), clean, tracks)
    _write_atomic(os.path.join(td, 'DEFERRED.md'), md)
    return clean


# Fields a patch may set on a card. Deliberately NOT `id` - an id is the one thing a
# caller must never rewrite, because session records cite it (see the v0.36 note above).
PATCH_FIELDS = ('title', 'track', 'status', 'writeup', 'flag', 'parked',
                'resume', 'resumeRef', 'resumeAt', 'doneVersion', 'doneDate')
PATCH_MAX_OPS = 200


def apply_state_patch(dirpath, ops, tracks=None, order=None):
    """Apply one-card edits on top of whatever is CURRENTLY on disk, then save.

    This is the merge point that makes two writers safe. PUT /api/state sends the WHOLE
    backlog, so whoever saves last wins the entire file and the other side's work vanishes
    with no warning - true whether the other writer is the board, a second tab, or an agent
    editing state.json by hand. A patch says "set #209's resume note" instead, so two
    writers touching DIFFERENT cards can never collide: neither one ever sends, or
    overwrites, the other's card.

    Ops, applied in order and ALL-OR-NOTHING (nothing is written unless every op lands):
      {"op": "set",    "id": N, "fields": {...}}       change named fields on one card
      {"op": "add",    "item": {...} [, "before": N]}  new card, appended or inserted
      {"op": "delete", "id": N}                        remove one card
      {"op": "move",   "id": N [, "before": N]}        reorder (before a card, or to the end)

    Returns (result, error, http_code). An op naming a card that isn't there is an ERROR,
    never a silent no-op: a write that quietly does nothing is the exact failure this
    whole path exists to remove.

    The save itself still goes through write_state, so every existing invariant applies
    unchanged - the parked-only-when-live backstop, the length caps, monotonic ids, the
    .bak, and the DEFERRED.md regeneration."""
    if isinstance(ops, dict):
        ops = [ops]
    if not isinstance(ops, list) or not ops:
        return None, 'no ops given', 400
    if len(ops) > PATCH_MAX_OPS:
        return None, 'too many ops in one patch (max %d)' % PATCH_MAX_OPS, 400
    cur, serr = read_state(dirpath)
    if serr:      # same refusal as PUT: never write on top of a backlog we couldn't read
        return None, 'state.json ' + serr, 409
    items = [dict(it) for it in (cur.get('items') or []) if isinstance(it, dict)]
    next_id = max(1, _to_int(cur.get('nextId')))
    for it in items:
        next_id = max(next_id, _to_int(it.get('id')) + 1)

    def find(n):
        for i, it in enumerate(items):
            if _to_int(it.get('id')) == n:
                return i
        return -1

    def bad_fields(src, verb):
        for key in src:
            if key not in PATCH_FIELDS:
                return "can't %s '%s' (allowed: %s)" % (verb, key, ', '.join(PATCH_FIELDS))
        return None

    applied = []
    for k, op in enumerate(ops):
        at = 'op %d' % (k + 1)
        if not isinstance(op, dict):
            return None, '%s is not an object' % at, 400
        kind = op.get('op')
        if kind in ('set', 'delete', 'move'):
            # report the PARSED id, not the raw value: it keeps this message byte-identical
            # to the Node twin's, which is what makes the two machine-comparable.
            n = _to_int(op.get('id'))
            i = find(n)
            if i < 0:
                return None, '%s: there is no card #%d' % (at, n), 409
        if kind == 'set':
            fields = op.get('fields')
            if not isinstance(fields, dict) or not fields:
                return None, '%s: no fields to set' % at, 400
            msg = bad_fields(fields, 'set')
            if msg:
                return None, '%s: %s' % (at, msg), 400
            items[i].update(fields)
            applied.append({'op': 'set', 'id': n, 'fields': sorted(fields)})
        elif kind == 'add':
            src = op.get('item')
            if not isinstance(src, dict):
                return None, '%s: no item given' % at, 400
            msg = bad_fields(src, 'set')
            if msg:
                return None, '%s: %s' % (at, msg), 400
            if not str(src.get('title') or '').strip():
                return None, '%s: a new card needs a title' % at, 400
            new = dict(src)
            new['id'] = next_id
            next_id += 1
            pos = len(items)
            if op.get('before') is not None:
                b = _to_int(op.get('before'))
                pos = find(b)
                if pos < 0:
                    return None, '%s: there is no card #%d to insert before' % (at, b), 409
            items.insert(pos, new)
            applied.append({'op': 'add', 'id': new['id'], 'title': new.get('title')})
        elif kind == 'delete':
            applied.append({'op': 'delete', 'id': n, 'title': items[i].get('title')})
            items.pop(i)
        elif kind == 'move':
            moved = items.pop(i)
            pos = len(items)
            if op.get('before') is not None:
                b = _to_int(op.get('before'))
                pos = -1 if b == n else find(b)
                if pos < 0:
                    items.insert(i, moved)      # put it back: nothing is written on a failed patch
                    return None, '%s: there is no card #%d to move before' % (at, b), 409
            items.insert(pos, moved)
            applied.append({'op': 'move', 'id': n})
        else:
            # json.dumps (not %r) so the text matches the Node twin's JSON.stringify exactly,
            # and a missing key reads as `null` on both rather than None/undefined.
            return None, '%s: unknown op %s' % (at, json.dumps(kind if isinstance(kind, str) else None)), 400

    state = write_state(dirpath, {'items': items, 'nextId': next_id}, tracks, order)
    return {'ok': True, 'applied': applied, 'state': state}, None, 200


def render_deferred(proj, state, tracks=None):
    if not tracks:
        tracks = TRACKS
    buckets = [('table', 'On the table'), ('air', 'Up in the air'), ('done', 'Done ✓'), ('cut', 'Cut')]
    top = next((x for x in state['items'] if x['status'] == 'table'), None)
    md = "# Deferred backlog - %s\n\n" % proj
    md += "_Auto-generated by Project Tracker - %s. Edit in the board, not by hand._\n\n" % datetime.date.today().isoformat()
    # Parking never reorders anything: a parked card keeps its place, so the top of the
    # table is still what "let's continue" picks. Saying so here is the whole point -
    # this file is what gets read when the board isn't open.
    nxt = "_(nothing on the table)_"
    if top:
        nxt = top['title']
        if top.get('parked'):
            nxt += ' **(parked - read its resume note below before continuing)**'
    md += "**Next up** (what an unspecified \"let's continue\" picks): %s\n\n" % nxt
    parked = [x for x in state['items'] if x.get('parked')]
    if parked:
        md += "**Parked** (set down mid-flight, %d): %s\n\n" % (
            len(parked), ', '.join('#%s %s' % (x.get('id'), x['title']) for x in parked))
    for st, label in buckets:
        md += "## %s\n" % label
        items = [x for x in state['items'] if x['status'] == st]
        if not items:
            md += "_(none)_\n\n"
            continue
        for i, it in enumerate(items):
            tk = tracks[it['track']]['short'] if it['track'] in tracks else it['track']
            prefix = ("%d." % (i + 1)) if st == 'table' else '-'
            ver = (' (%s)' % it['doneVersion']) if (st == 'done' and it.get('doneVersion')) else ''
            marks = ' **(blocker)**' if it['flag'] else ''
            if it.get('parked'):
                marks += ' **(parked)**' if it.get('resume') else ' **(parked - NO RESUME NOTE)**'
            md += "%s [%s] %s%s%s\n" % (prefix, tk, it['title'], ver, marks)
            # The resume note goes ABOVE the write-up: it is the short "where does this
            # stand" line, and burying it under an 18k-char write-up would defeat it.
            if it.get('resume'):
                md += "   - resume: %s%s\n" % (
                    ' '.join(it['resume'].split()),
                    ('  [%s]' % ' '.join(it['resumeRef'].split())) if it.get('resumeRef') else '')
                if it.get('resumeAt'):
                    md += "     (note written %s)\n" % it['resumeAt']
            if it['writeup']:
                md += "   - %s\n" % ' '.join(it['writeup'].split())
        md += "\n"
    return md


def sync_deferred(dirpath):
    """Self-heal DEFERRED.md from state.json. write_state() regenerates DEFERRED.md only
    when the board *saves*; an externally-edited state.json (an editor, a script, a tool's
    temp-file-then-rename) would otherwise leave DEFERRED.md frozen until the next board write.
    Called from the read paths (/api/state, /api/poll), so while the board is open it polls
    every ~6s and DEFERRED.md reconciles within one interval of any state.json change.
    Cheap: stats first, only reads+renders+writes when DEFERRED.md is missing or stale.
    Regenerating DEFERRED.md changes neither state.json's mtime nor the docs fingerprint,
    so it never re-triggers the board's auto-refresh.
    Refuses to touch DEFERRED.md when state.json can't be parsed - rendering a damaged
    state would write an EMPTY backlog over the last good human-readable copy, and this
    runs on the READ paths, so merely opening the board would have destroyed it."""
    td = os.path.join(dirpath, '.tracker')
    state_mt = _mtime_ms(os.path.join(td, 'state.json'))
    if not state_mt:
        return False
    deferred_path = os.path.join(td, 'DEFERRED.md')
    if state_mt <= _mtime_ms(deferred_path):   # DEFERRED.md already at or ahead of state.json
        return False
    try:
        state, err = read_state(dirpath)
        if err:
            return False                       # damaged - leave the good DEFERRED.md alone
        cfg = read_config(dirpath)
        tracks, _order = resolve_tracks(cfg)
        md = render_deferred(os.path.basename(dirpath), state, tracks)   # render before opening
        _write_atomic(deferred_path, md)
        return True
    except Exception:
        return False


# ---- Truth layer: core-doc audit panel ----
def _date_only(s):
    m = RE_DATE.search(s or '')
    return m.group(0) if m else ''


def _rel_ok(rel):
    """Reject absolute paths and any traversal out of the project dir."""
    rel = (rel or '').replace('\\', '/').strip().lstrip('/')
    if not rel or os.path.isabs(rel):
        return ''
    parts = rel.split('/')
    if '..' in parts or '' in [p for p in parts if p == '']:
        return ''
    return rel


def _resolve_latest_glob(dirpath, pattern):
    """Resolve a docs[] glob entry to its highest-sorting (latest) match, as a
       project-relative posix path. For per-session-versioned docs like a Bible."""
    import pathlib
    pat = (pattern or '').replace('\\', '/').strip().lstrip('/')
    if not pat or os.path.isabs(pat) or '..' in pat.split('/'):
        return ''
    try:
        matches = []
        for pth in pathlib.Path(dirpath).glob(pat):
            if not pth.is_file():
                continue
            rel = pth.relative_to(dirpath).as_posix()
            if any(seg in EXCLUDE for seg in rel.split('/')):
                continue
            matches.append(rel)
        matches.sort()
        return matches[-1] if matches else ''
    except Exception:
        return ''


def core_docs(dirpath, cfg):
    """Ordered [{path,name}] of canonical docs for the audit panel.
       From cfg['docs'] (strings, {path,name}, or {glob,name}) if declared; else top-level *.md."""
    out, seen = [], set()
    decl = cfg.get('docs') if isinstance(cfg, dict) else None
    if isinstance(decl, list) and decl:
        for entry in decl:
            rel = name = None
            self_versioned = False
            if isinstance(entry, str):
                rel = entry
            elif isinstance(entry, dict):
                name = entry.get('name')
                rel = _resolve_latest_glob(dirpath, entry.get('glob')) if entry.get('glob') else entry.get('path')
                self_versioned = bool(entry.get('selfVersioned'))
            if not rel:
                continue
            rel = _rel_ok(rel)
            if not rel or rel.lower() in seen:
                continue
            seen.add(rel.lower())
            out.append({'path': rel, 'name': name or os.path.basename(rel),
                        'selfVersioned': self_versioned})
        return out
    try:
        for name in os.listdir(dirpath):
            if name.lower().endswith('.md') and os.path.isfile(os.path.join(dirpath, name)):
                out.append({'path': name, 'name': name})
    except Exception:
        pass
    out.sort(key=lambda d: (0 if d['path'].lower().startswith('readme') else 1, d['path'].lower()))
    return out


def read_doc_meta(dirpath, doc, latest_version):
    rel = doc['path']
    full = os.path.join(dirpath, rel.replace('/', os.sep))
    self_versioned = bool(doc.get('selfVersioned'))
    meta = {'path': rel, 'name': doc['name'], 'exists': False, 'mtime': '',
            'lastModified': '', 'lastVerified': '', 'version': '',
            'drift': False, 'selfVersioned': self_versioned, 'status': 'missing', 'note': ''}
    try:
        st = os.stat(full)
    except Exception:
        meta['note'] = 'file not found'
        return meta
    meta['exists'] = True
    meta['mtime'] = datetime.date.fromtimestamp(st.st_mtime).isoformat()
    try:
        with open(full, 'r', encoding='utf-8', errors='replace') as f:
            text = f.read()
    except Exception as e:
        meta['status'] = 'unreadable'
        meta['note'] = str(e)
        return meta
    lines = text.replace('\r\n', '\n').replace('\r', '\n').split('\n')
    fm = {}
    if lines and lines[0].strip() == '---':
        i = 1
        while i < len(lines) and lines[i].strip() != '---':
            mm = RE_FRONT.match(lines[i])
            if mm:
                fm[mm.group(1).lower()] = mm.group(2).strip()
            i += 1
    if 'last_modified' in fm:
        meta['lastModified'] = _date_only(fm['last_modified'])
    if 'last_verified' in fm:
        meta['lastVerified'] = _date_only(fm['last_verified'])
    if 'version' in fm:
        vt = RE_VER_TOKEN.search(fm['version'])
        meta['version'] = ('v' + vt.group(1)) if vt else fm['version'].strip()[:24]
    for l in lines[:60]:
        low = l.lower()
        if not meta['lastModified'] and ('last modified' in low or 'last updated' in low):
            meta['lastModified'] = _date_only(l)
        if not meta['lastVerified'] and 'last verified' in low:
            meta['lastVerified'] = _date_only(l)
        if not meta['version']:
            toks = RE_VER_TOKEN.findall(l)
            # Exactly one token AND a real declaration: a "version" label right
            # before it, or it sits at the end of a heading. A range / multiple
            # tokens ("(v4.00..v7.97)"), an incidental prose mention ("last
            # present in v7.00"), or a token cited mid-heading is provenance —
            # leave version blank so it can't produce a false drift flag.
            if len(toks) == 1:
                m = RE_VER_TOKEN.search(l)
                title_end = bool(RE_HEADING.match(l)) and bool(RE_TITLE_TAIL.match(l[m.end():]))
                if title_end or RE_VER_DECL.search(l):
                    meta['version'] = 'v' + toks[0]
    # Drift = a doc that tracks the project version has fallen behind the latest
    # session. A self-versioned doc (own cadence, e.g. an Economics Bible) declares
    # selfVersioned in config.json docs[] and is exempt — it still shows its own
    # version, just isn't compared to the latest session.
    if (meta['version'] and latest_version and not self_versioned
            and meta['version'].lower() != latest_version.lower()):
        meta['drift'] = True
    modified = meta['lastModified'] or meta['mtime']
    if meta['lastVerified']:
        if meta['lastVerified'] < modified:
            meta['status'], meta['note'] = 'stale', 'verified before last change'
        elif meta['mtime'] and meta['lastVerified'] < meta['mtime']:
            meta['status'], meta['note'] = 'stale', 'file changed on disk since verified'
        else:
            meta['status'], meta['note'] = 'current', 'verified up to date'
    else:
        meta['status'], meta['note'] = 'unverified', 'no last_verified declared'
    return meta


def read_audit(dirpath):
    try:
        with open(os.path.join(dirpath, '.tracker', 'audit.json'), 'r', encoding='utf-8') as f:
            obj = json.load(f)
        if isinstance(obj, dict):
            return obj
    except Exception:
        pass
    return None


def read_docs(dirpath, cfg, sessions):
    latest = sessions[-1]['version'] if sessions else ''
    docs = [read_doc_meta(dirpath, d, latest) for d in core_docs(dirpath, cfg)]
    return {'latestVersion': latest, 'docs': docs, 'audit': read_audit(dirpath)}


# ---- Auto-refresh: cheap on-disk fingerprint (stat only, no parsing) ----
def _mtime_ms(path):
    try:
        return int(os.stat(path).st_mtime * 1000)
    except Exception:
        return 0


def fingerprint(dirpath, cfg):
    """A cheap signature of everything the board renders, from stat() only - no
       reads/parses. The board polls this; when a field changes it refetches just
       that slice, so panels stay current without a manual Reload. Fields:
         sessions = <count>:<newest mtime>   (new/edited session records)
         state    = <mtime of .tracker/state.json>   (the backlog)
         docs     = <count>:<newest core-doc mtime>:<audit.json mtime>
         config   = <mtime of .tracker/config.json>"""
    sd = sessions_dir_of(dirpath, cfg)
    s_n, s_mt = 0, 0
    try:
        for f in os.listdir(sd):
            if f.lower().endswith('.md'):
                s_n += 1
                mt = _mtime_ms(os.path.join(sd, f))
                if mt > s_mt:
                    s_mt = mt
    except Exception:
        pass
    docs = core_docs(dirpath, cfg)
    d_mt = 0
    for d in docs:
        mt = _mtime_ms(os.path.join(dirpath, d['path'].replace('/', os.sep)))
        if mt > d_mt:
            d_mt = mt
    audit_mt = _mtime_ms(os.path.join(dirpath, '.tracker', 'audit.json'))
    state_mt = _mtime_ms(os.path.join(dirpath, '.tracker', 'state.json'))
    config_mt = _mtime_ms(os.path.join(dirpath, '.tracker', 'config.json'))
    return {
        'sessions': '%d:%d' % (s_n, s_mt),
        'state': '%d' % state_mt,
        'docs': '%d:%d:%d' % (len(docs), d_mt, audit_mt),
        'config': '%d' % config_mt,
    }


# ---- HTTP handler ----
class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def _send(self, code, body_bytes, ctype):
        self.send_response(code)
        self.send_header('Content-Type', ctype)
        self.send_header('Cache-Control', 'no-store')
        if HOST_MODE:
            # keep the access token out of any outbound Referer, and hand the board a
            # SameSite cookie so target=_blank navigations (record/doc links) authenticate.
            self.send_header('Referrer-Policy', 'no-referrer')
            for ck in getattr(self, '_set_cookies', ()):
                self.send_header('Set-Cookie', ck)
        self.send_header('Content-Length', str(len(body_bytes)))
        self.end_headers()
        try:
            self.wfile.write(body_bytes)
        except (BrokenPipeError, ConnectionResetError):
            pass

    # ---- host-mode network safety (no-ops unless HOST_MODE) ----
    def _client_is_loopback(self):
        ip = (self.client_address[0] if self.client_address else '') or ''
        return ip in ('127.0.0.1', '::1') or ip.startswith('127.')

    def _host_header_ok(self):
        """Anti-DNS-rebind: the Host must name one of our own addresses, not a
        foreign domain pointed at our IP."""
        if not HOST_MODE:
            return True
        host = (self.headers.get('Host') or '').rsplit(':', 1)[0].strip().strip('[]').lower()
        return host in HOST_ALLOW

    def _supplied_token(self):
        h = self.headers.get('Authorization') or ''
        if h.startswith('Bearer '):
            return h[7:].strip()
        ck = self.headers.get('Cookie') or ''
        for part in ck.split(';'):
            k, _, v = part.strip().partition('=')
            if k == 'stasys_token' and v:
                return v.strip()
        return parse_qs(urlparse(self.path).query).get('token', [''])[0]   # bootstrap only

    def _auth_ok(self):
        """In host mode, REMOTE requests need the token; the host machine (loopback)
        is trusted and unauthenticated (so its own board works exactly as today)."""
        if not HOST_MODE or self._client_is_loopback():
            return True
        tok = self._supplied_token()
        return bool(tok) and hmac.compare_digest(tok, ACCESS_TOKEN)

    def _api_blocked(self, p):
        """Gate for /api/* in host mode: Host allowlist + token. Sends the error and
        returns True when the request must be refused; returns False when it may pass."""
        if not HOST_MODE:
            return False
        if not self._host_header_ok():
            self._text(403, 'bad host')
            return True
        if not self._auth_ok():
            time.sleep(0.3)                    # mild brute-force friction; entropy carries it
            self._json(401, {'error': 'unauthorized - open this board with a Connect link from the host'})
            return True
        return False

    def _host_only(self):
        """True (and sends 403) if a host-mode request to a host-only endpoint came
        from a REMOTE device. apply-update / new-project are never remote-triggerable."""
        if HOST_MODE and not self._client_is_loopback():
            self._json(403, {'error': 'this action can only be run on the host machine'})
            return True
        return False

    def _json(self, code, obj):
        self._send(code, json.dumps(obj).encode('utf-8'), 'application/json; charset=utf-8')

    def _text(self, code, text, ctype='text/plain'):
        body = text if isinstance(text, bytes) else text.encode('utf-8')
        self._send(code, body, ctype + '; charset=utf-8')

    def _serve_board(self):
        try:
            with open(os.path.join(ENGINE_DIR, 'board.html'), 'rb') as f:
                self._text(200, f.read(), 'text/html')
        except Exception:
            self._text(500, 'board.html not found next to server.py')

    def _serve_icon(self, p):
        # The board declares these as its favicon; an Edge --app window uses it as the
        # window/taskbar icon, so Stasys shows its own icon instead of Edge's.
        name, ctype = (('Stasys_Icon.png', 'image/png') if p.endswith('.png')
                       else ('Stasys.ico', 'image/x-icon'))
        try:
            with open(os.path.join(ENGINE_DIR, name), 'rb') as f:
                self._send(200, f.read(), ctype)
        except Exception:
            self._text(404, 'icon not found')

    def _serve_record(self, proj, fname):
        d = project_dir(proj)
        if not d:
            return self._text(400, 'bad project')
        if not re.match(r'^[\w.\- ]+\.md$', fname or '', re.I):
            return self._text(400, 'bad file')
        sd = os.path.abspath(sessions_dir_of(d, read_config(d)))
        path_ = os.path.abspath(os.path.join(sd, fname))
        if path_ != os.path.join(sd, fname):
            return self._text(400, 'bad path')
        try:
            with open(path_, 'r', encoding='utf-8', errors='replace') as f:
                self._text(200, f.read(), 'text/markdown')
        except Exception:
            self._text(404, 'not found')

    def _serve_doc(self, proj, relpath):
        d = project_dir(proj)
        if not d:
            return self._text(400, 'bad project')
        allow = {dd['path'] for dd in core_docs(d, read_config(d))}
        rel = _rel_ok(relpath)
        if not rel or rel not in allow:
            return self._text(400, 'not a core doc')
        full = os.path.abspath(os.path.join(d, rel.replace('/', os.sep)))
        if os.path.commonpath([full, os.path.abspath(d)]) != os.path.abspath(d):
            return self._text(400, 'bad path')
        try:
            with open(full, 'r', encoding='utf-8', errors='replace') as f:
                self._text(200, f.read(), 'text/markdown')
        except Exception:
            self._text(404, 'not found')

    def do_GET(self):
        u = urlparse(self.path)
        p = u.path
        q = parse_qs(u.query)
        proj = q.get('project', [None])[0]
        try:
            if HOST_MODE and not self._host_header_ok():
                return self._text(403, 'bad host')
            if p in ('/', '/board.html'):
                # hand a valid client (or the loopback host) the SameSite cookie so
                # in-page navigations (record/doc links) carry the token automatically.
                if HOST_MODE and self._auth_ok():
                    self._set_cookies = ['stasys_token=%s; Path=/; SameSite=Strict' % ACCESS_TOKEN]
                return self._serve_board()
            if p in ('/app-icon.png', '/favicon.ico'):
                return self._serve_icon(p)
            if p == '/api/host-info':                 # loopback-only: never hand the token to a remote
                if not self._client_is_loopback():
                    return self._json(403, {'error': 'loopback only'})
                return self._json(200, host_info(self.server.server_address[1]))
            if p.startswith('/api/') and self._api_blocked(p):
                return
            if p == '/api/version':
                return self._json(200, {'name': APP_NAME, 'version': APP_VERSION})
            if p == '/api/update-check':
                return self._json(200, update_check())
            if p == '/api/projects':
                return self._json(200, {'root': ROOT, 'projects': list_projects()})
            if p == '/api/sessions':
                d = project_dir(proj)
                if not d:
                    return self._json(400, {'error': 'bad project'})
                cfg = read_config(d)
                tracks, order = resolve_tracks(cfg)
                sessions = constrain_tracks(read_sessions(d, cfg), order)
                return self._json(200, {'tracks': tracks, 'order': order,
                                        'config': cfg, 'sessions': sessions})
            if p == '/api/state':
                d = project_dir(proj)
                if not d:
                    return self._json(400, {'error': 'bad project'})
                state, serr = read_state(d)
                if serr:           # say so loudly - never hand back an empty backlog we didn't read
                    return self._json(409, state_error_body(d, serr))
                sync_deferred(d)   # keep DEFERRED.md current with external state.json edits
                return self._json(200, state)
            if p == '/api/state/patch':
                # write-only door; answer the same 405 the Node twin does rather than a 404
                return self._json(405, {'error': 'method not allowed'})
            if p == '/api/docs':
                d = project_dir(proj)
                if not d:
                    return self._json(400, {'error': 'bad project'})
                cfg = read_config(d)
                return self._json(200, read_docs(d, cfg, read_sessions(d, cfg)))
            if p == '/api/poll':
                d = project_dir(proj)
                if not d:
                    return self._json(400, {'error': 'bad project'})
                sync_deferred(d)   # regenerate DEFERRED.md within one poll of any state.json change
                return self._json(200, fingerprint(d, read_config(d)))
            if p == '/api/record':
                return self._serve_record(proj, q.get('file', [''])[0])
            if p == '/api/doc':
                return self._serve_doc(proj, q.get('path', [''])[0])
            return self._text(404, 'not found')
        except Exception as e:
            self._json(500, {'error': str(e)})

    def _origin_ok(self):
        """CSRF guard for state-changing requests: accept a write only if its
        browser Origin/Referer is this same localhost server. Browsers always
        attach Origin on cross-site writes and a page cannot forge it, so this
        blocks a malicious site (or a DNS-rebind) from POSTing to our localhost
        port. Non-browser clients (no Origin and no Referer) are allowed - they
        aren't a CSRF vector."""
        origin = self.headers.get('Origin') or self.headers.get('Referer')
        if not origin:
            return True
        try:
            u = urlparse(origin)
        except Exception:
            return False
        host = (u.hostname or '').lower()
        # localhost always; in host mode also this machine's own (tailnet/LAN) address,
        # so a token-authenticated remote browser's same-origin write is accepted.
        allowed = host in ('localhost', '127.0.0.1', '::1') or (HOST_MODE and host in HOST_ALLOW)
        if not allowed:
            return False
        return u.port is None or u.port == self.server.server_address[1]

    def do_PUT(self):
        u = urlparse(self.path)
        if self._api_blocked(u.path):          # host mode: Host allowlist + token (no-op on localhost)
            return
        if u.path == '/api/apply-update':
            # Trigger the updater (board "Update & restart" button). LOOPBACK-ONLY in
            # host mode - a remote device can never make the host download/apply/restart.
            # Runs apply_update INLINE (no child process to orphan when the app restarts);
            # signature-gated + fail-closed, so only a properly signed release applies.
            if self._host_only():
                return
            if not self._origin_ok():
                return self._json(403, {'error': 'cross-origin write rejected'})
            res = apply_update('')
            return self._json(200 if res.get('applied') else 400, res)
        if u.path == '/api/new-project':
            if self._host_only():              # scaffolding is loopback-only in host mode
                return
            if not self._origin_ok():
                return self._json(403, {'error': 'cross-origin write rejected'})
            try:
                ln = int(self.headers.get('Content-Length') or 0)
                raw = self.rfile.read(ln) if ln else b''
                body = json.loads(raw.decode('utf-8') or '{}')
            except Exception:
                return self._json(400, {'error': 'bad json'})
            res = new_project(body.get('name'))
            return self._json(200 if res.get('ok') else 400, res)
        if u.path == '/api/set-host-mode':
            # Toggle sharing on/off from the board (loopback-only) so the user never
            # hand-edits settings.json. Takes effect on the next restart (a restart is
            # what binds/unbinds the network) - the board triggers that via the host.
            if self._host_only():
                return
            if not self._origin_ok():
                return self._json(403, {'error': 'cross-origin write rejected'})
            try:
                ln = int(self.headers.get('Content-Length') or 0)
                body = json.loads(self.rfile.read(ln).decode('utf-8') or '{}') if ln else {}
            except Exception:
                return self._json(400, {'error': 'bad json'})
            on = bool(body.get('on'))
            cfg = _read_settings()
            cfg['hostMode'] = on
            if on and not (isinstance(cfg.get('accessToken'), str) and cfg.get('accessToken', '').strip()):
                cfg['accessToken'] = secrets.token_urlsafe(32)
            ok = _write_settings(cfg)
            return self._json(200 if ok else 500, {'ok': ok, 'hostMode': on, 'restartRequired': True})
        if u.path == '/api/state/patch':
            # The narrow write door: one card at a time, merged into what's on disk right
            # now. Same origin guard as every other write - and note a non-browser caller
            # (no Origin/Referer) is already allowed by it, so a local script needs no
            # special-casing and the guard is not weakened to let one in.
            if not self._origin_ok():
                return self._json(403, {'error': 'cross-origin write rejected'})
            d = tracked_project_dir(parse_qs(u.query).get('project', [None])[0])
            if not d:      # must already be a real project - never invent one from a typo
                return self._json(400, {'error': 'bad project'})
            try:
                ln = int(self.headers.get('Content-Length') or 0)
                if ln > 5_000_000:
                    return self._json(400, {'error': 'body too large'})
                body = json.loads(self.rfile.read(ln).decode('utf-8') or '{}') if ln else {}
            except Exception:
                return self._json(400, {'error': 'bad json'})
            ops = body.get('ops') if isinstance(body, dict) and 'ops' in body else body
            try:
                tracks, order = resolve_tracks(read_config(d))
                res, perr, code = apply_state_patch(d, ops, tracks, order)
            except Exception as e:
                return self._json(500, {'error': str(e)})
            if perr:   # nothing was written - say why, and never pretend it landed
                return self._json(code, {'error': 'patch-rejected', 'detail': perr})
            return self._json(200, res)
        if u.path != '/api/state':
            return self._text(404, 'not found')
        if not self._origin_ok():
            return self._json(403, {'error': 'cross-origin write rejected'})
        d = project_dir(parse_qs(u.query).get('project', [None])[0])
        if not d:
            return self._json(400, {'error': 'bad project'})
        try:
            ln = int(self.headers.get('Content-Length') or 0)
            if ln > 5_000_000:
                return self._json(400, {'error': 'body too large'})
            raw = self.rfile.read(ln) if ln else b''
            incoming = json.loads(raw.decode('utf-8') or '{}')
        except Exception:
            return self._json(400, {'error': 'bad json'})
        try:
            cur, serr = read_state(d)
            if serr:   # refuse to overwrite a backlog we couldn't read - the board may be showing
                       # nothing at all, and saving that would make the damage permanent
                return self._json(409, state_error_body(d, serr))
            # THE STALE-SAVE GUARD. This endpoint replaces the WHOLE backlog, so a client that
            # built its copy before someone else wrote would silently erase that write. A client
            # that quotes the rev it loaded gets told instead: 409, plus the current state, so it
            # can merge its own edits onto it and try again.
            # A client that sends NO rev is still allowed through - an older board must keep
            # working against a newer engine, and refusing it would break saving outright rather
            # than protect anything. The rev is opt-in on the client and enforced once offered.
            want = incoming.get('rev') if isinstance(incoming, dict) else None
            if want and want != cur.get('rev'):
                return self._json(409, {
                    'error': 'state-stale',
                    'detail': 'the backlog changed on disk since you loaded it',
                    'rev': cur.get('rev'), 'yourRev': want, 'state': cur})
            tracks, order = resolve_tracks(read_config(d))
            return self._json(200, {'ok': True, 'state': write_state(d, incoming, tracks, order)})
        except Exception as e:
            return self._json(500, {'error': str(e)})

    do_POST = do_PUT


def open_browser(url):
    try:
        webbrowser.open(url)
    except Exception:
        pass


def main():
    # CLI: `py server.py --apply-update [<manifest-url-or-path>]` runs the updater and
    # exits WITHOUT serving (a separate process from the running app, matching the future
    # "spawn updater, then restart" flow). Source defaults to the configured update feed.
    if sys.argv[1:2] == ['--apply-update']:
        src = sys.argv[2] if len(sys.argv) > 2 else ''
        res = apply_update(src)
        print(json.dumps(res, indent=2))
        sys.exit(0 if res.get('applied') else 1)

    # CLI: `py server.py --patch <project> [ops.json]` (omit the file to read stdin) applies a
    # one-card patch and exits without serving. This is the door for when Stasys ISN'T RUNNING
    # (card #23) - and it deliberately calls the SAME apply_state_patch the HTTP endpoint calls,
    # so there is one implementation of "merge this change into the backlog" rather than two
    # that can drift. Exit 0 = written, 1 = rejected (nothing written), 2 = bad invocation.
    if sys.argv[1:2] == ['--patch']:
        pid = sys.argv[2] if len(sys.argv) > 2 else ''
        d = tracked_project_dir(pid)
        if not d:
            print(json.dumps({'ok': False, 'error': 'bad project %r (looking under %s)' % (pid, ROOT)}, indent=2))
            sys.exit(2)
        src = sys.argv[3] if len(sys.argv) > 3 else ''
        if src:
            try:
                with open(src, 'r', encoding='utf-8') as f:
                    raw = f.read()
            except Exception as e:
                print(json.dumps({'ok': False, 'error': "couldn't read %r (%s)" % (src, e.__class__.__name__)}, indent=2))
                sys.exit(2)
        else:
            raw = sys.stdin.read()
        try:
            body = json.loads(raw or '{}')
        except ValueError as e:
            print(json.dumps({'ok': False, 'error': 'bad json (%s)' % e}, indent=2))
            sys.exit(2)
        ops = body.get('ops') if isinstance(body, dict) and 'ops' in body else body
        tracks, order = resolve_tracks(read_config(d))
        res, perr, _code = apply_state_patch(d, ops, tracks, order)
        if perr:
            print(json.dumps({'ok': False, 'error': perr}, indent=2))
            sys.exit(1)
        print(json.dumps({'ok': True, 'applied': res['applied']}, indent=2))
        sys.exit(0)

    # Clear out any app-shell image a previous update renamed aside; by now the process
    # that held it has exited, so this is where the old .exe/.dll actually goes away.
    sweep_stale_updates()

    # Host mode binds the network so other devices (reached privately via Tailscale)
    # can share this board; off by default it stays localhost-only.
    bind_ip = '0.0.0.0' if HOST_MODE else '127.0.0.1'
    httpd = None
    port = None
    for candidate in PORTS:
        try:
            httpd = ThreadingHTTPServer((bind_ip, candidate), Handler)
            port = candidate
            break
        except OSError:
            httpd = None
    if httpd is None:
        print('No free port in ' + ', '.join(str(p) for p in PORTS))
        sys.exit(1)
    url = 'http://localhost:%d' % port
    print()
    print('  Project Tracker is running:  ' + url)
    print('  Serving projects from:       ' + ROOT)
    if HOST_MODE:
        print()
        print('  HOST MODE ON - this board is shared on the network (token-protected).')
        if TAILSCALE_IP:
            print('  Connect from another device:  http://%s:%d/?token=%s' % (TAILSCALE_IP, port, ACCESS_TOKEN))
        else:
            print('  No Tailscale address found - bound to 0.0.0.0 (all interfaces);')
            print('  rely on your firewall. Token: ' + ACCESS_TOKEN)
    print('  Leave this window open. Close it (or press Ctrl+C) to stop.')
    print()
    if not os.environ.get('STASYS_NO_BROWSER'):   # the app launcher opens its own window instead
        threading.Timer(0.6, open_browser, args=(url,)).start()
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print('\nStopping...')
        httpd.shutdown()


if __name__ == '__main__':
    main()
